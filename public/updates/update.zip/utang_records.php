<?php
require_once __DIR__ . '/layout.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'mark_paid' && isAdmin()) {
        $utangId = intval($_POST['utang_id'] ?? 0);
        if ($utangId > 0) {
            $stmt = $pdo->prepare('UPDATE utang SET status = "Paid" WHERE id = :id');
            $stmt->execute(['id' => $utangId]);
            flash('Utang marked as paid.', 'success');
        }
    }
    header('Location: utang_records.php');
    exit;
}

$utangRecords = $pdo->query('SELECT u.*, p.product_name FROM utang u JOIN products p ON u.product_id = p.id ORDER BY u.date_created DESC')->fetchAll();
$flash = consumeFlash();
page_header('Utang Records', 'utang');
?>
<div class="page-header">
    <h2>Utang Records</h2>
    <p>Track outstanding customer balances and settle payments.</p>
</div>
<?php if ($flash): ?>
    <div class="alert alert-<?= sanitize($flash['type']) ?> mb-3" role="alert">
        <?= sanitize($flash['message']) ?>
    </div>
<?php endif; ?>
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Due Date</th>
                    <th>Status</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($utangRecords)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">No utang records yet.</td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($utangRecords as $utang): ?>
                    <tr>
                        <td><?= sanitize($utang['customer_name']) ?></td>
                        <td><?= sanitize($utang['product_name']) ?></td>
                        <td><?= intval($utang['qty']) ?></td>
                        <td>₱ <?= number_format($utang['total'], 2) ?></td>
                        <td><?= sanitize($utang['due_date']) ?></td>
                        <td><span class="badge <?= $utang['status'] === 'Paid' ? 'bg-success' : 'bg-warning text-dark' ?>"><?= sanitize($utang['status']) ?></span></td>
                        <td class="text-end">
                            <?php if ($utang['status'] === 'Unpaid' && isAdmin()): ?>
                                <form method="post" class="d-inline-block">
                                    <input type="hidden" name="action" value="mark_paid">
                                    <input type="hidden" name="utang_id" value="<?= intval($utang['id']) ?>">
                                    <button type="submit" class="btn btn-sm btn-success">Mark Paid</button>
                                </form>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php page_footer();
