<div class="page-header">
    <h2>System Settings <span class="badge bg-warning" style="font-size: 0.5em; vertical-align: middle;">BETA</span></h2>
    <p>Customize your StoreTap experience with themes and preferences.</p>
    <div style="display: inline-flex; align-items: center; gap: 8px; font-family: sans-serif;">
    
    <div id="clock-display-mode" style="display: flex; align-items: center; gap: 6px;">
        <span id="real-time-clock" style="font-weight: 500; font-size: 0.8rem; color: #4b5563;"></span>
        <button onclick="toggleClockEdit(true)" style="background: none; border: none; cursor: pointer; padding: 2px; color: #6b7280; display: flex; align-items: center;" title="Edit Time">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 15a3 3 0 100-6 3 3 0 000 6z"></path><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z"></path></svg>
        </button>
    </div>

    <div id="clock-edit-mode" style="display: none; align-items: center; gap: 6px;">
        <input type="datetime-local" id="clock-input" style="padding: 2px 6px; border: 1px solid #d1d5db; border-radius: 4px; font-size: 14px; color: #4b5563;">
        <button onclick="saveNewTime()" style="padding: 2px 8px; background: #3b82f6; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 13px;">Save</button>
        <button onclick="toggleClockEdit(false)" style="padding: 2px 8px; background: transparent; color: #6b7280; border: 1px solid #d1d5db; border-radius: 4px; cursor: pointer; font-size: 13px;">Cancel</button>
    </div>

</div>
</div>

<div class="row g-4">
    <!-- Theme Selection -->
    <div class="col-12 col-lg-8">
        <div class="card">
            <div class="card-body p-4">
                <h5 class="mb-3 fw-bold d-flex align-items-center gap-2">
                    <span>🎨</span> Choose Your Theme
                </h5>
                <p class="text-secondary mb-4">Select a theme that matches your store's personality. All themes are included with your StoreTap system.</p>
                
                <form method="post" id="themeForm">
                    <input type="hidden" name="action" value="change_theme">
                    <input type="hidden" name="theme" id="selectedTheme" value="<?= sanitize($currentTheme) ?>">
                    
                    <div class="row g-3">
                        <?php foreach ($availableThemes as $key => $theme): ?>
                        <?php if ($theme['premium'] && !$hasPremiumThemes) continue; ?>
                        <div class="col-6 col-md-4">
                            <div class="theme-card <?= $currentTheme === $key ? 'active' : '' ?>" 
                                 data-theme="<?= sanitize($key) ?>"
                                 onclick="selectTheme('<?= sanitize($key) ?>')">
                                
                                <!-- Theme Preview -->
                                <div class="theme-preview theme-<?= sanitize($key) ?>">
                                    <div class="preview-header"></div>
                                    <div class="preview-body">
                                        <div class="preview-card"></div>
                                        <div class="preview-button"></div>
                                    </div>
                                </div>
                                
                                <!-- Theme Info -->
                                <div class="theme-info">
                                    <div class="d-flex align-items-center gap-2 mb-1">
                                        <span class="theme-name"><?= sanitize($theme['name']) ?></span>
                                        <?php if ($theme['premium']): ?>
                                            <span class="badge bg-warning" style="font-size: 0.6rem;">PREMIUM</span>
                                        <?php endif; ?>
                                    </div>
                                    <small class="theme-desc"><?= sanitize($theme['description']) ?></small>
                                </div>
                                
                                <!-- Selected Indicator -->
                                <div class="selected-indicator">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <circle cx="10" cy="10" r="10" fill="currentColor"/>
                                        <path d="M6 10L9 13L14 7" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">
                            Apply Theme
                        </button>
                        <button type="button" class="btn btn-outline-secondary ms-2" onclick="clearAllCache()">
                            🗑️ Clear Cache
                        </button>
                        <span id="themeStatus" class="ms-3 text-success" style="display: none;">
                            ✓ Changes will apply immediately
                        </span>
                    </div>
                </form>
            </div>
        </div>
    </div>
    

    <div class="col-12 col-lg-4">
        <!-- System Update Card -->
        <?php if ($isAdmin): ?>
        <div class="card mb-3">
            <div class="card-body p-4 text-center">
                <h5 class="mb-3 fw-bold">System Update</h5>
                <p class="small text-secondary mb-3">
                    Current Version: <span class="badge bg-primary"><?= defined('APP_VERSION') ? APP_VERSION : 'Unknown' ?></span>
                </p>
                <button type="button" class="btn btn-outline-primary w-100 fw-bold" onclick="checkUpdate()">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="me-1" style="margin-top: -3px;">
                        <path d="M21 2v6h-6"></path>
                        <path d="M21 13a9 9 0 11-3-7.7L21 8"></path>
                    </svg>
                    Check for Updates
                </button>
            </div>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body p-4">
                <h5 class="mb-3 fw-bold">Current Settings</h5>
                
                <div class="mb-3">
                    <small class="text-secondary d-block">Active Theme</small>
                    <span class="fw-semibold"><?= sanitize($availableThemes[$currentTheme]['name']) ?></span>
                </div>
                    
                <div class="mb-3">
                    <small class="text-secondary d-block">User</small>
                    <span class="fw-semibold"><?= sanitize($currentUser) ?></span>
                    <span class="badge bg-secondary ms-1"><?= $isAdmin ? 'Admin' : 'Staff' ?></span>
                </div>
                
                <div class="mb-3">
                    <small class="text-secondary d-block">Session</small>
                    <span class="fw-semibold"><?= session_id() ? substr(session_id(), 0, 8) . '...' : 'N/A' ?></span>
                </div>
                
                <div class="mb-3">
                    <small class="text-secondary d-block">Local Storage</small>
                    <div class="d-flex align-items-center gap-2">
                        <span class="fw-semibold" id="storageSize">--</span>
                        <div class="progress flex-fill" style="height: 6px; max-width: 100px;">
                            <div id="storageBar" class="progress-bar" role="progressbar" style="width: 0%"></div>
                        </div>
                    </div>
                </div>
                
                <div class="mb-3">
                    <small class="text-secondary d-block">Sync Status</small>
                    <span class="fw-semibold" id="syncStatus">Loading...</span>
                </div>
                
                <hr class="my-3">
                
                <h6 class="fw-bold mb-2">About Themes</h6>
                <p class="small text-secondary mb-0">
                    StoreTap includes 10 professionally designed themes to match your store's brand. 
                    Themes change colors, accents, and visual styling throughout the application.
                </p>
            </div>
        </div>
        
        <!-- Quick Tips -->
        <div class="card mt-3">
            <div class="card-body p-4">
                <h6 class="fw-bold mb-2">💡 Quick Tips</h6>
                <ul class="small text-secondary mb-0 ps-3">
                    <li class="mb-1">Themes apply instantly after saving</li>
                    <li class="mb-1">Each user can have their own theme preference</li>
                    <li class="mb-1">Premium themes are included at no extra cost</li>
                    <li>Try different themes to find your perfect match</li>
                </ul>
            </div>
        </div>
        
        <!-- Patch Notes -->
        <div class="card mt-3">
            <div class="card-body p-4">
                <h6 class="fw-bold mb-3 d-flex align-items-center gap-2">
                    <span>📋</span> Patch Notes <span class="badge bg-info" style="font-size: 0.6em;">v2.1.0</span>
                </h6>
                <div class="small">
                    <div class="mb-3">
                        <strong class="d-block mb-1" style="color: var(--accent);">💰 Sales Module</strong>
                        <ul class="text-secondary ps-3 mb-0" style="line-height: 1.6;">
                            <li>New Sales page with listed records</li>
                            <li>Custom pricing per sale with notes</li>
                            <li>Edit sale price functionality (admin)</li>
                            <li>Role-based visibility (staff/admin)</li>
                            <li>Mobile-friendly card layout</li>
                            <li>Improved touch targets and spacing</li>
                        </ul>
                    </div>
                    <div class="mb-3">
                        <strong class="d-block mb-1" style="color: var(--accent);">↩️ Dashboard & Undo Sales</strong>
                        <ul class="text-secondary ps-3 mb-0" style="line-height: 1.6;">
                            <li>Undo Last Sale feature</li>
                            <li>Restores stock automatically</li>
                            <li>Transaction-safe operations</li>
                            <li>Quick product cards with stock info</li>
                            <li>Cash & Utang quick actions</li>
                        </ul>
                    </div>
                    <div class="mb-3">
                        <strong class="d-block mb-1" style="color: var(--accent);">� Utang Management</strong>
                        <ul class="text-secondary ps-3 mb-0" style="line-height: 1.6;">
                            <li>Complete utang records listing</li>
                            <li>Mark as paid functionality</li>
                            <li>Partial payment tracking</li>
                            <li>Payment history per utang</li>
                            <li>Remaining balance calculations</li>
                        </ul>
                    </div>
                    <div class="mb-3">
                        <strong class="d-block mb-1" style="color: var(--accent);">🏪 Inventory System</strong>
                        <ul class="text-secondary ps-3 mb-0" style="line-height: 1.6;">
                            <li>Check & Adjust buttons</li>
                            <li>Original stock tracking</li>
                            <li>Stock adjustment with reasons</li>
                            <li>Inventory history logging</li>
                            <li>Low stock warnings</li>
                        </ul>
                    </div>
                    <div class="mb-3">
                        <strong class="d-block mb-1" style="color: var(--accent);">📊 Reports & Analytics</strong>
                        <ul class="text-secondary ps-3 mb-0" style="line-height: 1.6;">
                            <li>Sales & utang period filtering</li>
                            <li>Cash sales summary</li>
                            <li>Utang collection tracking</li>
                            <li>Inventory checks (admin only)</li>
                            <li>Export-ready tables</li>
                        </ul>
                    </div>
                    <div class="mb-3">
                        <strong class="d-block mb-1" style="color: var(--accent);">👥 Users Management</strong>
                        <ul class="text-secondary ps-3 mb-0" style="line-height: 1.6;">
                            <li>Real-time online users (admin)</li>
                            <li>Active session monitoring</li>
                            <li>Create/edit/delete users</li>
                            <li>Role assignment (admin/staff)</li>
                            <li>Permission-based features</li>
                        </ul>
                    </div>
                    <div class="mb-3">
                        <strong class="d-block mb-1" style="color: var(--accent);">🎨 Theme System (BETA)</strong>
                        <ul class="text-secondary ps-3 mb-0" style="line-height: 1.6;">
                            <li>10 premium themes</li>
                            <li>Midnight theme with soft contrast</li>
                            <li>Per-user theme preferences</li>
                            <li>Consistent UI across all pages</li>
                            <li>Mobile-optimized layouts</li>
                        </ul>
                    </div>
                    <div class="mb-0">
                        <strong class="d-block mb-1" style="color: var(--accent);">🔧 Bug Fixes & Polish</strong>
                        <ul class="text-secondary ps-3 mb-0" style="line-height: 1.6;">
                            <li>Fixed undo sale SQL errors</li>
                            <li>All tables visible in dark mode</li>
                            <li>Permission handling improvements</li>
                            <li>UI/UX refinements throughout</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Theme Card Styles */
.theme-card {
    border: 2px solid var(--border);
    border-radius: 1rem;
    padding: 1rem;
    cursor: pointer;
    transition: all 0.2s ease;
    position: relative;
    background: var(--card-bg);
}

.theme-card:hover {
    border-color: var(--accent);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.theme-card.active {
    border-color: var(--accent);
    box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.1);
}

.theme-preview {
    border-radius: 0.5rem;
    overflow: hidden;
    margin-bottom: 0.75rem;
    height: 80px;
}

.preview-header {
    height: 20px;
}

.preview-body {
    padding: 8px;
    height: 60px;
}

.preview-card {
    height: 20px;
    border-radius: 3px;
    margin-bottom: 6px;
    opacity: 0.8;
}

.preview-button {
    height: 12px;
    width: 40px;
    border-radius: 3px;
}

.theme-info {
    text-align: center;
}

.theme-name {
    font-weight: 600;
    font-size: 0.875rem;
}

.theme-desc {
    color: var(--text-secondary);
    display: block;
    line-height: 1.3;
}

/* Ensure text readability across all themes */
.theme-info .theme-name {
    color: var(--text-primary) !important;
}

.theme-info .theme-desc {
    color: var(--text-secondary) !important;
    font-weight: 500;
}

/* Card headers and labels */
.card h5, .card h6 {
    color: var(--text-primary) !important;
}

.card .text-secondary {
    color: var(--text-secondary) !important;
    font-weight: 500;
}

/* Patch notes styling */
.patch-item strong {
    color: var(--text-primary) !important;
}

.patch-item ul {
    color: var(--text-secondary) !important;
}

.selected-indicator {
    position: absolute;
    top: 0.5rem;
    right: 0.5rem;
    color: var(--accent);
    opacity: 0;
    transition: opacity 0.2s ease;
}

.theme-card.active .selected-indicator {
    opacity: 1;
}

/* Mobile Comfort Improvements */
@media (max-width: 767.98px) {
    .theme-card {
        padding: 0.75rem !important;
    }
    .theme-preview {
        height: 60px !important;
    }
    .preview-header {
        height: 15px !important;
    }
    .preview-body {
        height: 45px !important;
        padding: 6px !important;
    }
    .preview-card {
        height: 15px !important;
        margin-bottom: 4px !important;
    }
    .preview-button {
        height: 10px !important;
        width: 30px !important;
    }
    .theme-name {
        font-size: 0.75rem !important;
    }
    .theme-desc {
        font-size: 0.65rem !important;
    }
    .badge {
        font-size: 0.5rem !important;
    }
    .card-body {
        padding: 1rem !important;
    }
    .page-header {
        padding: 0.75rem 0 !important;
    }
    .page-header h2 {
        font-size: 1.25rem !important;
    }
    .page-header p {
        font-size: 0.875rem !important;
    }
}

/* Theme Preview Styles - Each theme's preview colors (HIGH SPECIFICITY) */
.theme-preview.theme-default .preview-header { background: #111827 !important; }
.theme-preview.theme-default .preview-body { background: #fafafa !important; }
.theme-preview.theme-default .preview-card { background: #e5e7eb !important; }
.theme-preview.theme-default .preview-button { background: #111827 !important; }

.theme-preview.theme-pink .preview-header { background: #be185d !important; }
.theme-preview.theme-pink .preview-body { background: #fdf2f8 !important; }
.theme-preview.theme-pink .preview-card { background: #fbcfe8 !important; }
.theme-preview.theme-pink .preview-button { background: #db2777 !important; }

.theme-preview.theme-ocean .preview-header { background: #1e40af !important; }
.theme-preview.theme-ocean .preview-body { background: #eff6ff !important; }
.theme-preview.theme-ocean .preview-card { background: #bfdbfe !important; }
.theme-preview.theme-ocean .preview-button { background: #3b82f6 !important; }

.theme-preview.theme-forest .preview-header { background: #166534 !important; }
.theme-preview.theme-forest .preview-body { background: #f0fdf4 !important; }
.theme-preview.theme-forest .preview-card { background: #bbf7d0 !important; }
.theme-preview.theme-forest .preview-button { background: #22c55e !important; }

.theme-preview.theme-sunset .preview-header { background: #c2410c !important; }
.theme-preview.theme-sunset .preview-body { background: #fff7ed !important; }
.theme-preview.theme-sunset .preview-card { background: #fed7aa !important; }
.theme-preview.theme-sunset .preview-button { background: #f97316 !important; }

.theme-preview.theme-royal .preview-header { background: #7c3aed !important; }
.theme-preview.theme-royal .preview-body { background: #f5f3ff !important; }
.theme-preview.theme-royal .preview-card { background: #ddd6fe !important; }
.theme-preview.theme-royal .preview-button { background: #8b5cf6 !important; }

.theme-preview.theme-dark .preview-header { background: #111827 !important; }
.theme-preview.theme-dark .preview-body { background: #1f2937 !important; }
.theme-preview.theme-dark .preview-card { background: #374151 !important; }
.theme-preview.theme-dark .preview-button { background: #4b5563 !important; }

.theme-preview.theme-coffee .preview-header { background: #78350f !important; }
.theme-preview.theme-coffee .preview-body { background: #fffbeb !important; }
.theme-preview.theme-coffee .preview-card { background: #fde68a !important; }
.theme-preview.theme-coffee .preview-button { background: #d97706 !important; }

.theme-preview.theme-berry .preview-header { background: #9f1239 !important; }
.theme-preview.theme-berry .preview-body { background: #fff1f2 !important; }
.theme-preview.theme-berry .preview-card { background: #fecdd3 !important; }
.theme-preview.theme-berry .preview-button { background: #e11d48 !important; }

.theme-preview.theme-mint .preview-header { background: #0f766e !important; }
.theme-preview.theme-mint .preview-body { background: #f0fdfa !important; }
.theme-preview.theme-mint .preview-card { background: #ccfbf1 !important; }
.theme-preview.theme-mint .preview-button { background: #14b8a6 !important; }
</style>

<script>
// Force reload page without cache when theme changes
function forceReload() {
    // Clear browser cache for this site
    if ('caches' in window) {
        caches.keys().then(function(cacheNames) {
            cacheNames.forEach(function(cacheName) {
                caches.delete(cacheName);
            });
        });
    }
    // Reload with cache bypass
    window.location.reload(true);
}

// Override form submission to add cache-busting
function selectTheme(themeKey) {
    // Update hidden input
    document.getElementById('selectedTheme').value = themeKey;
    
    // Update visual selection
    document.querySelectorAll('.theme-card').forEach(card => {
        card.classList.remove('active');
    });
    document.querySelector(`[data-theme="${themeKey}"]`).classList.add('active');
    
    // Show status message
    document.getElementById('themeStatus').style.display = 'inline';
}

// Clear all browser cache and storage
function clearAllCache() {
    // Clear offline storage first
    if (window.OfflineStorage) {
        OfflineStorage.clearAll();
    }
    
    // Clear all localStorage
    localStorage.clear();
    
    // Clear sessionStorage
    sessionStorage.clear();
    
    // Clear caches
    if ('caches' in window) {
        caches.keys().then(function(cacheNames) {
            cacheNames.forEach(function(cacheName) {
                caches.delete(cacheName);
            });
        });
    }
    
    // Clear service workers
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then(function(registrations) {
            registrations.forEach(function(registration) {
                registration.unregister();
            });
        });
    }
    
    // Reload without cache
    window.location.reload(true);
}

// Update storage display on settings page
function updateSettingsStorage() {
    if (!window.OfflineStorage) return;
    
    const info = OfflineStorage.updateStorageUsage();
    
    // Update storage size text
    const sizeEl = document.getElementById('storageSize');
    if (sizeEl) {
        sizeEl.textContent = info.formatted;
    }
    
    // Update progress bar
    const barEl = document.getElementById('storageBar');
    if (barEl) {
        barEl.style.width = info.percentage + '%';
        barEl.className = 'progress-bar ' + (info.percentage > 80 ? 'bg-danger' : 'bg-success');
    }
    
    // Update sync status
    const statusEl = document.getElementById('syncStatus');
    if (statusEl) {
        const status = OfflineStorage.getSyncStatus();
        if (!status.isOnline) {
            statusEl.innerHTML = '<span class="badge bg-warning">⚠ Offline</span>';
        } else if (status.pendingSales > 0 || status.pendingUtang > 0) {
            statusEl.innerHTML = '<span class="badge bg-info">⏳ ' + (status.pendingSales + status.pendingUtang) + ' pending</span>';
        } else {
            const lastSync = status.lastSync ? status.lastSync.toLocaleTimeString() : 'Never';
            statusEl.innerHTML = '<span class="badge bg-success">✓ Synced ' + lastSync + '</span>';
        }
    }
}

// Update storage display on load
document.addEventListener('DOMContentLoaded', function() {
    // Wait for OfflineStorage to init
    setTimeout(updateSettingsStorage, 100);
    
    // Listen for storage updates
    window.addEventListener('storageUsageUpdate', function(e) {
        const data = e.detail;
        const sizeEl = document.getElementById('storageSize');
        const barEl = document.getElementById('storageBar');
        
        if (sizeEl) sizeEl.textContent = data.formatted;
        if (barEl) {
            barEl.style.width = data.percentage + '%';
            barEl.className = 'progress-bar ' + (data.percentage > 80 ? 'bg-danger' : 'bg-success');
        }
    });
    
    // Update sync status every 5 seconds
    setInterval(updateSettingsStorage, 5000);
});
// This variable stores the difference between actual time and user's edited time
    // Load the saved offset from PHP session (convert seconds to milliseconds)
    let manualTimeOffset = <?= ($_SESSION['manual_time_offset'] ?? 0) * 1000 ?>; 
    let clockInterval;

    function updateClock() {
        // Apply the offset so the clock keeps ticking from the new time
        const now = new Date(Date.now() + manualTimeOffset);

        // 1. Format the Time (e.g., "2:23pm")
        let hours = now.getHours();
        let minutes = now.getMinutes();
        const ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? '0' + minutes : minutes;
        const timeString = `${hours}:${minutes}${ampm}`;

        // 2. Format the Date (e.g., "april 24,2026")
        const monthNames = [
            "january", "february", "march", "april", "may", "june",
            "july", "august", "september", "october", "november", "december"
        ];
        const month = monthNames[now.getMonth()];
        const day = now.getDate();
        const year = now.getFullYear();
        const dateString = `${month} ${day},${year}`;

        // 3. Display
        document.getElementById('real-time-clock').textContent = `${timeString}, ${dateString}`;
    }

    // Toggle between viewing the clock and editing the clock
    function toggleClockEdit(showEdit) {
        const displayMode = document.getElementById('clock-display-mode');
        const editMode = document.getElementById('clock-edit-mode');
        const input = document.getElementById('clock-input');

        if (showEdit) {
            // Get current displayed time to populate the input field
            const currentTickingTime = new Date(Date.now() + manualTimeOffset);
            
            // Format for datetime-local input (YYYY-MM-DDTHH:mm)
            const tzOffset = currentTickingTime.getTimezoneOffset() * 60000; // local timezone offset
            const localISOTime = (new Date(currentTickingTime.getTime() - tzOffset)).toISOString().slice(0, 16);
            
            input.value = localISOTime;
            
            displayMode.style.display = 'none';
            editMode.style.display = 'flex';
        } else {
            displayMode.style.display = 'flex';
            editMode.style.display = 'none';
        }
    }

    // Save the new time and calculate the offset
    function saveNewTime() {
        const inputVal = document.getElementById('clock-input').value;
        if (inputVal) {
            const newDate = new Date(inputVal);
            // Calculate how far off the new time is from the actual computer time
            manualTimeOffset = newDate.getTime() - Date.now();
            
            // Save to server session
            saveTimeOffsetToServer(manualTimeOffset);
            
            // Force an immediate update, then switch back to display mode
            updateClock();
        }
        toggleClockEdit(false);
    }
    
    // Send the time offset to server to save in session
    function saveTimeOffsetToServer(offset) {
        const formData = new FormData();
        formData.append('action', 'save_time_offset');
        formData.append('offset', Math.floor(offset / 1000)); // Convert to seconds for PHP
        
        fetch('index.php?page=settings', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Time offset saved:', data.offset, 'seconds');
            }
        })
        .catch(error => {
            console.error('Error saving time offset:', error);
        });
    }
    
    // Reset to real time
    function resetToRealTime() {
        manualTimeOffset = 0;
        saveTimeOffsetToServer(0);
        updateClock();
    }

    // Initialize
    updateClock();
    clockInterval = setInterval(updateClock, 1000);
</script>

<!-- OTA Update Modal -->
<div class="modal fade" id="updateModal" tabindex="-1" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">System Update Available!</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" id="closeUpdateModalBtn"></button>
            </div>
            <div class="modal-body">
                <div id="updateInitialView">
                    <p class="mb-2">A new version of StoreTap is ready to install.</p>
                    <div class="d-flex justify-content-between mb-3 text-secondary small">
                        <span>Current: <span id="lblCurrentVer" class="fw-bold"></span></span>
                        <span>Latest: <span id="lblLatestVer" class="fw-bold text-success"></span></span>
                    </div>
                    
                    <div class="card bg-light border-0 mb-4">
                        <div class="card-body p-3">
                            <h6 class="fw-bold mb-2">What's New:</h6>
                            <p id="lblChangelog" class="mb-0 small text-secondary" style="white-space: pre-wrap;"></p>
                        </div>
                    </div>
                    
                    <button class="btn btn-primary w-100 fw-bold" onclick="startUpdateProcess()">Install Update Now</button>
                </div>
                
                <div id="updateProgressView" style="display: none;">
                    <h6 id="updateStatusText" class="text-center fw-bold mb-3">Downloading Update...</h6>
                    <div class="progress mb-2" style="height: 12px;">
                        <div id="updateProgressBar" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%"></div>
                    </div>
                    <p id="updateDetailText" class="text-center small text-secondary">Please do not close this window.</p>
                </div>
                
                <div id="updateSuccessView" style="display: none;" class="text-center">
                    <div class="mb-3 text-success">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                    </div>
                    <h5 class="fw-bold mb-2">Update Complete!</h5>
                    <p class="text-secondary mb-4">StoreTap has been updated successfully.</p>
                    <button class="btn btn-success w-100 fw-bold" onclick="window.location.reload(true)">Reload System</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    let updateDownloadUrl = '';
    let updateModalInstance = null;

    function getUpdateModal() {
        if (!updateModalInstance) {
            updateModalInstance = new bootstrap.Modal(document.getElementById('updateModal'));
        }
        return updateModalInstance;
    }

    function checkUpdate() {
        const btn = event.currentTarget;
        const originalHtml = btn.innerHTML;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Checking...';
        btn.disabled = true;

        fetch('index.php?page=update_check')
            .then(res => res.json())
            .then(data => {
                btn.innerHTML = originalHtml;
                btn.disabled = false;
                
                if (data.status === 'success') {
                    if (data.has_update) {
                        document.getElementById('lblCurrentVer').innerText = data.current_version;
                        document.getElementById('lblLatestVer').innerText = data.latest_version;
                        document.getElementById('lblChangelog').innerText = data.changelog;
                        updateDownloadUrl = data.download_url;
                        
                        // Reset views
                        document.getElementById('updateInitialView').style.display = 'block';
                        document.getElementById('updateProgressView').style.display = 'none';
                        document.getElementById('updateSuccessView').style.display = 'none';
                        document.getElementById('closeUpdateModalBtn').style.display = 'block';
                        
                        getUpdateModal().show();
                    } else {
                        alert('Your system is up to date! (Version: ' + data.current_version + ')');
                    }
                } else {
                    alert('Error checking for updates: ' + data.message);
                }
            })
            .catch(err => {
                btn.innerHTML = originalHtml;
                btn.disabled = false;
                alert('Network error while checking for updates.');
                console.error(err);
            });
    }

    function startUpdateProcess() {
        document.getElementById('updateInitialView').style.display = 'none';
        document.getElementById('updateProgressView').style.display = 'block';
        document.getElementById('closeUpdateModalBtn').style.display = 'none';
        
        updateProgress(10, 'Preparing download...');
        
        // Step 1: Download
        const formData = new FormData();
        formData.append('download_url', updateDownloadUrl);
        
        fetch('index.php?page=update_download', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                updateProgress(50, 'Extracting files...');
                extractUpdate();
            } else {
                showUpdateError(data.message);
            }
        })
        .catch(err => showUpdateError('Download failed. Network error.'));
    }

    function extractUpdate() {
        fetch('index.php?page=update_extract')
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    updateProgress(100, 'Finishing up...');
                    setTimeout(() => {
                        document.getElementById('updateProgressView').style.display = 'none';
                        document.getElementById('updateSuccessView').style.display = 'block';
                    }, 500);
                } else {
                    showUpdateError(data.message);
                }
            })
            .catch(err => showUpdateError('Extraction failed. Network error.'));
    }

    function updateProgress(percent, text) {
        document.getElementById('updateProgressBar').style.width = percent + '%';
        document.getElementById('updateStatusText').innerText = text;
    }
    
    function showUpdateError(msg) {
        document.getElementById('updateStatusText').innerText = 'Update Failed';
        document.getElementById('updateStatusText').classList.add('text-danger');
        document.getElementById('updateDetailText').innerText = msg;
        document.getElementById('updateProgressBar').classList.add('bg-danger');
        document.getElementById('closeUpdateModalBtn').style.display = 'block';
    }
</script>
