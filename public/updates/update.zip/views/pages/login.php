<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title>Login - StoreTap</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --bg-color: #fafafa;
            --card-bg: #ffffff;
            --text-primary: #1a1a1a;
            --text-secondary: #6b7280;
            --accent: #111827;
            --accent-light: #374151;
            --border: #e5e7eb;
        }
        
        * { -webkit-tap-highlight-color: transparent; }
        
        body {
            background: var(--bg-color);
            color: var(--text-primary);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }
        
        .login-container {
            width: 100%;
            max-width: 360px;
        }
        
        .logo {
            font-size: 1.5rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            margin-bottom: 0.5rem;
            text-align: center;
        }
        
        .tagline {
            color: var(--text-secondary);
            font-size: 0.875rem;
            text-align: center;
            margin-bottom: 2rem;
        }
        
        .card {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 1rem;
            padding: 1.5rem;
        }
        
        .form-label {
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 0.375rem;
        }
        
        .form-control {
            border: 1px solid var(--border);
            border-radius: 0.5rem;
            padding: 0.875rem 1rem;
            font-size: 1rem;
            min-height: 48px;
        }
        
        .form-control:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(17, 24, 39, 0.05);
        }
        
        .btn {
            font-weight: 600;
            border-radius: 0.5rem;
            padding: 0.875rem;
            min-height: 48px;
            border: none;
        }
        
        .btn-primary {
            background: var(--accent);
            color: white;
        }
        
        .btn-primary:hover { background: var(--accent-light); }
        .btn-primary:active { transform: scale(0.98); }
        
        .alert {
            border: none;
            border-radius: 0.75rem;
            padding: 0.875rem 1rem;
            font-size: 0.875rem;
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
        }
        
        .hint {
            color: var(--text-secondary);
            font-size: 0.8125rem;
            text-align: center;
            margin-top: 1.5rem;
        }
        
        .hint strong { color: var(--text-primary); }
    </style>
</head>
<body>
<?php if ($error === 'CONFLICT'): ?>
    <div class="modal fade" id="conflictModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0" style="border-radius: 1rem; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
                <div class="modal-header bg-danger text-white border-0 py-3">
                    <h5 class="modal-title fw-bold"><i class="bi bi-exclamation-triangle-fill me-2"></i>Access Denied</h5>
                </div>
                <div class="modal-body p-4 text-center">
                    <h5 class="fw-bold mb-3">Account Currently In Use</h5>
                    <p class="text-secondary mb-0">Someone is already logged into this account. Only one device can use an account at a time. Please contact the admin or the person currently using this account to log out.</p>
                </div>
                <div class="modal-footer border-0 p-4 pt-0 justify-content-center">
                    <button type="button" class="btn btn-outline-danger px-4" data-bs-dismiss="modal">I Understand</button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<div class="login-container">
    <div class="logo">StoreTap</div>
    <p class="tagline">Simple sales & utang tracking</p>
    
    <div class="card">
        <?php if ($error && $error !== 'CONFLICT'): ?>
            <div class="alert mb-3"><?= sanitize($error) ?></div>
        <?php endif; ?>
        <form method="post" novalidate>
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" value="<?= sanitize($_POST['username'] ?? '') ?>" required autocomplete="username">
            </div>
            <div class="mb-4">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required autocomplete="current-password">
            </div>
            <button type="submit" class="btn btn-primary w-100">Sign In</button>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?php if ($error === 'CONFLICT'): ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var myModal = new bootstrap.Modal(document.getElementById('conflictModal'));
        myModal.show();
    });
</script>
<?php endif; ?>
</body>
</html>
