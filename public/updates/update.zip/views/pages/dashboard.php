<!-- Stats Row -->
<div class="row g-2 g-md-3 mb-2">
    <div class="col-4">
        <div class="card stat-card">
            <div class="stat-label">Sales</div>
            <div class="stat-value" id="statSales"><?= intval($statsData['total_items'] ?? 0) ?></div>
        </div>
    </div>
    <div class="col-4">
        <div class="card stat-card">
            <div class="stat-label">Income</div>
            <div class="stat-value" id="statIncome">₱<?= number_format($statsData['total_income'] ?? 0, 0) ?></div>
        </div>
    </div>
    <div class="col-4">
        <div class="card stat-card">
            <div class="stat-label">Utang</div>
            <div class="stat-value" id="statUtang"><?= intval($utangData) ?></div>
        </div>
    </div>
</div>



<!-- Recent Activity & Undo Section -->
<?php if (!empty($recentSales)): ?>
<div class="row mb-3">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <small class="text-muted">Recent activity available for undo</small>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-sm btn-outline-primary" id="fastSaleBtn" onclick="toggleFastSaleMode()">
                    🛒 Fast Sale
                </button>
                <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="modal" data-bs-target="#undoModal">
                    ↩️ Undo Last Sale
                </button>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="row mb-3">
    <div class="col-12">
        <div class="d-flex justify-content-end">
            <button type="button" class="btn btn-sm btn-outline-primary" id="fastSaleBtn" onclick="toggleFastSaleMode()">
                🛒 Fast Sale
            </button>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Cart Indicator -->
<div id="cartIndicator" class="row mb-3" style="display: none;">
    <div class="col-12">
        <div class="alert alert-info d-flex justify-content-between align-items-center">
            <span><strong>Fast Sale Mode:</strong> <span id="cartCount">0</span> items in cart</span>
            <div>
                <button type="button" class="btn btn-sm btn-outline-secondary me-2" onclick="clearCart()">Clear</button>
                <button type="button" class="btn btn-sm btn-success" onclick="openCheckoutModal()">
                    Checkout ₱<span id="cartTotal">0</span>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Products Header -->
<div class="page-header d-flex justify-content-between align-items-center">
    <h2>Products</h2>
    <?php if ($lowStockCount > 0): ?>
        <span class="badge bg-danger"><?= intval($lowStockCount) ?> low stock</span>
    <?php endif; ?>
</div>

<!-- Products Grid -->
<?php if (empty($products)): ?>
    <div class="col-12 text-center py-5">
        <div class="empty-state-container p-5 rounded-4 d-flex flex-column align-items-center justify-content-center" style="background: var(--bg-color, #ffffff); border: 2px dashed var(--border, #dee2e6); min-height: 350px;">
            <div class="mb-3" style="font-size: 4rem; opacity: 0.8;">📦</div>
            <h3 class="fw-bold mb-3">No Products Yet</h3>
            <p class="text-muted mb-4 mx-auto" style="max-width: 500px; font-size: 1.05rem;">
                Your dashboard is looking a bit empty. Start by adding your first product to track sales and manage your inventory.
            </p>
            <a href="index.php?page=product_manage" class="btn btn-primary btn-lg px-4 rounded-pill shadow-sm">
                ➕ Add Your First Product
            </a>
        </div>
    </div>
<?php else: ?>
    <div class="row g-2 g-md-3">
        <?php foreach ($products as $product): ?>
            <div class="col-12 col-sm-6 col-lg-4">
                <div class="card product-card h-100">
                    <div class="product-image-wrapper mb-3">
                        <?php if ($product['image']): ?>
                            <img src="<?= sanitize($product['image']) ?>" alt="<?= sanitize($product['product_name']) ?>" class="product-image">
                        <?php else: ?>
                            <div class="product-image placeholder">No image</div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="card-title mb-0"><?= sanitize($product['product_name']) ?></h5>
                            <div class="d-flex gap-1">
                                <span class="badge bg-success cart-indicator d-none" id="cart-indicator-<?= intval($product['id']) ?>" style="font-size: 0.65rem;">
                                    In Cart: <span class="cart-qty">0</span>
                                </span>
                                <?php if ($product['stock_qty'] <= 5): ?>
                                    <span class="badge <?= $product['stock_qty'] <= 0 ? 'bg-danger' : 'bg-warning' ?>" style="font-size: 0.65rem;">
                                        <?= $product['stock_qty'] <= 0 ? 'OUT' : 'LOW' ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="price mb-1">₱ <?= number_format($product['price'], 2) ?></div>
                        <div class="stock mb-3"><?= intval($product['stock_qty']) ?> in stock</div>
                        
                        <div class="mt-auto d-flex gap-2">
                            <form method="post" class="flex-fill normal-sale-form">
                                <input type="hidden" name="action" value="sale">
                                <input type="hidden" name="product_id" value="<?= intval($product['id']) ?>">
                                <button type="submit" class="btn btn-success action-btn w-100" <?= $product['stock_qty'] <= 0 ? 'disabled' : '' ?>>
                                    Cash Sale
                                </button>
                            </form>
                            <button type="button" class="btn btn-outline-primary action-btn fast-sale-btn d-none"
                                onclick="addToCart(<?= intval($product['id']) ?>, '<?= htmlspecialchars($product['product_name'], ENT_QUOTES) ?>', <?= floatval($product['price']) ?>, <?= intval($product['stock_qty']) ?>)"
                                <?= $product['stock_qty'] <= 0 ? 'disabled' : '' ?>>
                                Add to Cart
                            </button>
                            <button type="button" class="btn btn-outline-primary action-btn normal-utang-btn"
                                data-bs-toggle="modal" data-bs-target="#utangModal"
                                data-product-id="<?= intval($product['id']) ?>"
                                data-product-name="<?= sanitize($product['product_name']) ?>"
                                id="utang-btn-<?= intval($product['id']) ?>"
                                <?= $product['stock_qty'] <= 0 ? 'disabled' : '' ?>>
                                Record Utang
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<div class="modal fade" id="utangModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <form method="post">
                <input type="hidden" name="action" value="utang">
                <input type="hidden" name="product_id" id="utangProductId" value="">
                <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                    <h5 class="modal-title fw-bold">Record Utang</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="padding: 1.25rem;">
                    <div class="mb-3">
                        <label class="form-label">Product</label>
                        <input type="text" id="utangProductName" class="form-control" disabled style="background: var(--bg-color);">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Customer Name</label>
                        <input type="text" name="customer_name" id="utangCustomerName" class="form-control" required autocomplete="off">
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Due Date</label>
                        <input type="date" name="due_date" id="utangDueDate" class="form-control" required>
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                    <button type="button" class="btn btn-outline-primary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Utang</button>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>

<!-- Undo Modal -->
<div class="modal fade" id="undoModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                <h5 class="modal-title fw-bold">↩️ Undo Last Sale</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="padding: 1.25rem; max-height: 50vh; overflow-y: auto;">
                <p class="text-muted mb-3">
                    <?php if (isAdmin()): ?>
                        Select a sale to remove. This will restore stock and delete the record.
                    <?php else: ?>
                        Select your recent sale to remove. This will restore stock and delete the record.
                    <?php endif; ?>
                </p>
                <?php
                $currentUserName = ($_SESSION['user']['username'] ?? 'system');
                $isAdmin = isAdmin();
                $visibleSales = array_filter($recentSales, function($sale) use ($currentUserName, $isAdmin) {
                    return $isAdmin || ($sale['created_by'] === $currentUserName);
                });
                ?>
                <?php if (empty($visibleSales)): ?>
                    <div class="text-center text-muted py-4">No sales available to undo.</div>
                <?php else: ?>
                    <?php foreach ($visibleSales as $sale): ?>
                        <div class="card mb-2" style="border: 1px solid var(--border);">
                            <div class="card-body p-3 d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="fw-bold"><?= sanitize($sale['product_name']) ?></div>
                                    <small class="text-muted">
                                        ₱<?= number_format($sale['total'], 2) ?> • <?= date('M d, H:i', strtotime($sale['date_created'])) ?>
                                        <?php if ($isAdmin && $sale['created_by']): ?>
                                            <span class="badge bg-info" style="font-size: 0.7em;"><?= sanitize($sale['created_by']) ?></span>
                                        <?php endif; ?>
                                    </small>
                                </div>
                                <form method="post" class="m-0">
                                    <input type="hidden" name="action" value="undo_sale">
                                    <input type="hidden" name="sale_id" value="<?= intval($sale['id']) ?>">
                                    <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Remove this sale? This will restore stock and delete the record.')">
                                        Remove
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Fast Sale Checkout Modal -->
<div class="modal fade" id="checkoutModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                <h5 class="modal-title fw-bold">🛒 Fast Sale Checkout</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" id="fastSaleForm">
                <div class="modal-body" style="padding: 1.25rem; max-height: 50vh; overflow-y: auto;">
                    <div id="cartItemsList" class="mb-3"></div>
                    <div class="border-top pt-3">
                        <div class="d-flex justify-content-between mb-2">
                            <strong>Total:</strong>
                            <strong>₱<span id="checkoutTotal">0</span></strong>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Payment Amount (₱)</label>
                            <input type="number" name="payment_amount" id="paymentAmount" class="form-control" min="0" step="0.01" required oninput="calculateChange()">
                        </div>
                        <div class="d-flex justify-content-between fs-5" id="changeDisplay" style="display: none !important;">
                            <span>Change:</span>
                            <span class="text-success fw-bold">₱<span id="changeAmount">0</span></span>
                        </div>
                    </div>
                    <input type="hidden" name="action" value="fast_sale">
                    <input type="hidden" name="cart_data" id="cartDataInput">
                </div>
                <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                    <button type="button" class="btn btn-outline-primary" data-bs-dismiss="modal">Continue Shopping</button>
                    <button type="submit" class="btn btn-success" id="completeSaleBtn" disabled>Complete Sale</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const utangModal = document.getElementById('utangModal');
    utangModal.addEventListener('show.bs.modal', event => {
        const button = event.relatedTarget;
        document.getElementById('utangProductId').value = button.getAttribute('data-product-id');
        document.getElementById('utangProductName').value = button.getAttribute('data-product-name');
    });

    // Fast Sale Cart System
    let cart = [];
    let fastSaleMode = false;

    function toggleFastSaleMode() {
        fastSaleMode = !fastSaleMode;
        const btn = document.getElementById('fastSaleBtn');
        const cartIndicator = document.getElementById('cartIndicator');
        const fastSaleBtns = document.querySelectorAll('.fast-sale-btn');
        const normalSaleForms = document.querySelectorAll('.normal-sale-form');
        const normalUtangBtns = document.querySelectorAll('.normal-utang-btn');

        if (fastSaleMode) {
            btn.classList.remove('btn-outline-primary');
            btn.classList.add('btn-primary');
            btn.textContent = '🛒 Exit Fast Sale';
            cartIndicator.style.display = 'block';
            fastSaleBtns.forEach(b => b.classList.remove('d-none'));
            normalSaleForms.forEach(f => f.classList.add('d-none'));
            normalUtangBtns.forEach(b => b.classList.add('d-none'));
        } else {
            btn.classList.add('btn-outline-primary');
            btn.classList.remove('btn-primary');
            btn.textContent = '🛒 Fast Sale';
            cartIndicator.style.display = 'none';
            fastSaleBtns.forEach(b => b.classList.add('d-none'));
            normalSaleForms.forEach(f => f.classList.remove('d-none'));
            normalUtangBtns.forEach(b => b.classList.remove('d-none'));
            // Hide all cart indicators when exiting fast sale mode
            document.querySelectorAll('.cart-indicator').forEach(ind => {
                ind.classList.add('d-none');
                ind.querySelector('.cart-qty').textContent = '0';
            });
            clearCart();
        }
    }

    function addToCart(productId, productName, price, stockQty) {
        const existingItem = cart.find(item => item.productId === productId);
        if (existingItem) {
            if (existingItem.qty < stockQty) {
                existingItem.qty++;
            } else {
                alert('Maximum stock reached for this product!');
                return;
            }
        } else {
            cart.push({ productId, productName, price, qty: 1 });
        }
        updateCartDisplay();
        updateProductCartIndicator(productId);
    }

    function removeFromCart(index) {
        const item = cart[index];
        const productId = item ? item.productId : null;
        cart.splice(index, 1);
        updateCartDisplay();
        if (productId) {
            updateProductCartIndicator(productId);
        }
    }

    function clearCart() {
        const productIds = cart.map(item => item.productId);
        cart = [];
        updateCartDisplay();
        productIds.forEach(productId => updateProductCartIndicator(productId));
    }

    function updateProductCartIndicator(productId) {
        const indicator = document.getElementById('cart-indicator-' + productId);
        if (!indicator) return;
        
        const item = cart.find(item => item.productId === productId);
        if (item && item.qty > 0) {
            indicator.querySelector('.cart-qty').textContent = item.qty;
            indicator.classList.remove('d-none');
        } else {
            indicator.classList.add('d-none');
            indicator.querySelector('.cart-qty').textContent = '0';
        }
    }

    function updateCartDisplay() {
        const count = cart.reduce((sum, item) => sum + item.qty, 0);
        const total = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
        document.getElementById('cartCount').textContent = count;
        document.getElementById('cartTotal').textContent = total.toLocaleString('en-PH', {minimumFractionDigits: 0, maximumFractionDigits: 0});
        
        // Update all product cart indicators
        cart.forEach(item => updateProductCartIndicator(item.productId));
    }

    function openCheckoutModal() {
        if (cart.length === 0) {
            alert('Your cart is empty!');
            return;
        }
        const total = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
        document.getElementById('checkoutTotal').textContent = total.toLocaleString('en-PH', {minimumFractionDigits: 2, maximumFractionDigits: 2});
        
        // Build cart items list
        let itemsHtml = '';
        cart.forEach((item, index) => {
            itemsHtml += `
                <div class="d-flex justify-content-between align-items-center mb-2 p-2" style="background: var(--bg-color); border-radius: 0.5rem;">
                    <div>
                        <div class="fw-bold">${item.productName}</div>
                        <small class="text-muted">₱${item.price.toFixed(2)} × ${item.qty}</small>
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <span class="fw-bold">₱${(item.price * item.qty).toFixed(2)}</span>
                        <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeFromCart(${index}); openCheckoutModal();">×</button>
                    </div>
                </div>
            `;
        });
        document.getElementById('cartItemsList').innerHTML = itemsHtml;
        
        // Reset payment
        document.getElementById('paymentAmount').value = '';
        document.getElementById('changeDisplay').style.display = 'none';
        document.getElementById('completeSaleBtn').disabled = true;
        
        // Store cart data in hidden input
        document.getElementById('cartDataInput').value = JSON.stringify(cart);
        
        const modal = new bootstrap.Modal(document.getElementById('checkoutModal'));
        modal.show();
    }

    function calculateChange() {
        const total = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
        const payment = parseFloat(document.getElementById('paymentAmount').value) || 0;
        const change = payment - total;
        
        document.getElementById('changeAmount').textContent = change.toFixed(2);
        document.getElementById('changeDisplay').style.display = change >= 0 ? 'flex !important' : 'none';
        document.getElementById('completeSaleBtn').disabled = change < 0;
    }

    // After any form submit (sale, utang, fast sale), flag that a sync is needed.
    // When the page reloads, offlineStorage.js will auto-sync on init().
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', () => {
            localStorage.setItem('storetap_needs_sync', '1');
        });
    });

</script>
