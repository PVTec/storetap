<div class="page-header">
    <h2>Manage Users</h2>
    <p>Create and manage staff and admin access.</p>
</div>

<!-- Online Users Section (Admin Only) -->
<?php if (isAdmin()): ?>
<div class="row g-3 mb-4">
    <div class="col-12">
        <div class="card p-3" style="border-left: 4px solid #10b981;">
            <div class="d-flex align-items-center gap-3">
                <div class="position-relative">
                    <i class="bi bi-people-fill fs-2 text-success"></i>
                    <span class="position-absolute top-0 start-100 translate-middle p-1 bg-success border border-light rounded-circle" style="width: 12px; height: 12px;"></span>
                </div>
                <div>
                    <h5 class="mb-1 fw-bold">Online Now</h5>
                    <?php 
                        $displayUsers = array_filter($onlineUsers, function($u) { return strtolower($u) !== 'admin'; });
                    ?>
                    <?php if (empty($displayUsers)): ?>
                        <p class="mb-0 text-secondary">No staff currently online</p>
                    <?php else: ?>
                        <div class="d-flex flex-wrap gap-2 mt-2">
                            <?php foreach ($displayUsers as $username): ?>
                                <div class="d-flex align-items-center bg-light rounded-pill px-3 py-1 border border-success" style="box-shadow: 0 2px 4px rgba(16, 185, 129, 0.1);">
                                    <div class="spinner-grow text-success me-2" role="status" style="width: 10px; height: 10px;">
                                        <span class="visually-hidden">Online</span>
                                    </div>
                                    <span class="fw-bold" style="color: var(--text-primary);"><?= sanitize(ucfirst($username)) ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card p-4">
            <h5 class="mb-3 fw-bold"><?= $editUser ? 'Edit User' : 'Create User' ?></h5>
            <form method="post">
                <input type="hidden" name="user_id" value="<?= intval($editUser['id'] ?? 0) ?>">
                <input type="hidden" name="action" value="<?= $editUser ? 'update' : 'create' ?>">
                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" value="<?= sanitize($editUser['username'] ?? '') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password <?= $editUser ? '(leave blank to keep)' : '' ?></label>
                    <input type="password" name="password" class="form-control" <?= $editUser ? '' : 'required' ?> autocomplete="new-password">
                </div>
                <div class="mb-3">
                    <label class="form-label">Role</label>
                    <select name="role" class="form-select" required>
                        <option value="staff" <?= ($editUser['role'] ?? '') === 'staff' ? 'selected' : '' ?>>Staff</option>
                        <option value="admin" <?= ($editUser['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary"><?= $editUser ? 'Update' : 'Create' ?></button>
                <?php if ($editUser): ?>
                    <a href="index.php?page=manage_users" class="btn btn-outline-primary ms-2">Cancel</a>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="card p-3">
            <h5 class="mb-3 fw-bold">User Accounts</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Role</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= sanitize($user['username']) ?></td>
                                <td><?= ucfirst(sanitize($user['role'])) ?></td>
                                <td class="text-end">
                                    <a href="index.php?page=manage_users&edit=<?= intval($user['id']) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                    <?php if ($user['id'] !== currentUser()['id']): ?>
                                        <form method="post" class="d-inline-block" onsubmit="return confirm('Delete this user?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="user_id" value="<?= intval($user['id']) ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
