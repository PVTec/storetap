<?php

// Prepare license status string
$isExpired = strtotime($currentLicense['expires_at']) < getSystemTimestamp();
$statusClass = $isExpired ? 'bg-danger' : 'bg-success';
$statusText = $isExpired ? 'Expired' : 'Active';
$flash = consumeFlash();
?>

<?php if ($flash): ?>
    <div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show" role="alert">
        <?= sanitize($flash['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>License Management</h2>
</div>

<div class="row g-4">
    <div class="col-md-4">
        <div class="card shadow-sm h-100">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Current License Status</h5>
            </div>
            <div class="card-body">
                <p><strong>License Key:</strong> <span class="text-break"><?= sanitize($currentLicense['license_key'] ?? 'None') ?></span></p>
                <p><strong>Type:</strong> <span class="badge <?= $currentLicense['license_type'] === 'dev' ? 'bg-info' : 'bg-secondary' ?> text-uppercase"><?= sanitize($currentLicense['license_type'] ?? 'Free') ?></span></p>
                <p><strong>Status:</strong> <span class="badge <?= $statusClass ?>"><?= $statusText ?></span></p>
                <p><strong>Expires At:</strong> <?= date('F j, Y, g:i a', strtotime($currentLicense['expires_at'])) ?></p>
                
                <hr>
                
                <h6 class="fw-bold">Features Included:</h6>
                <ul class="list-unstyled">
                    <li>
                        <?php if ($currentLicense['offline_dashboard']): ?>
                            <span class="text-success">✅</span> Offline Dashboard
                        <?php else: ?>
                            <span class="text-danger">❌</span> Offline Dashboard
                        <?php endif; ?>
                    </li>
                    <li>
                        <?php if ($currentLicense['premium_themes']): ?>
                            <span class="text-success">✅</span> Premium Themes
                        <?php else: ?>
                            <span class="text-danger">❌</span> Premium Themes
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-light">
                <h5 class="mb-0">Activate System License</h5>
            </div>
            <div class="card-body">
                <p class="text-muted small mb-3">This page is for activating the StoreTap system on your local machine. Please enter the License Key that you obtained from our centralized StoreTap Licensing Website.</p>
                
                <div class="alert alert-warning border-warning" role="alert">
                    <h6 class="alert-heading fw-bold">⚠️ Important License Information</h6>
                    <p class="small mb-2">Each license key can only be activated <strong>once</strong>. If you replace your current license with a new one, your old license will be discarded and <strong>cannot be used again</strong> on this or any other StoreTap site.</p>
                    <hr class="my-2">
                    <p class="small mb-0 text-dark"><strong>💡 Suggestion:</strong> We highly recommend waiting for your current license to fully expire before activating a new one.</p>
                </div>

                <form action="index.php?page=license" method="POST">
                    <input type="hidden" name="action" value="activate">
                    <div class="input-group">
                        <input type="text" name="license_key" class="form-control form-control-lg" placeholder="e.g. PRO-ABCD-1234" required>
                        <button type="submit" class="btn btn-primary btn-lg">Activate</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- License Tiers Info -->
        <h5 class="mb-3">Available License Tiers</h5>
        <div class="row g-3">
            <div class="col-sm-4">
                <div class="card border-0 bg-white shadow-sm h-100 p-3 text-center">
                    <h5 class="fw-bold text-secondary">Basic</h5>
                    <h4 class="mb-3">₱150</h4>
                    <ul class="list-unstyled small text-start mx-auto" style="max-width: 150px;">
                        <li>✅ 1 Month Duration</li>
                        <li>❌ No Offline Dashboard</li>
                        <li>❌ No Premium Themes</li>
                    </ul>
                    <?php if (in_array($currentLicense['license_type'], ['free', 'basic']) && !empty($currentLicense['is_expired'])): ?>
                        <p class="text-danger small mt-auto mb-0 fw-bold">Status: Used & Expired</p>
                    <?php else: ?>
                        <a href="https://storetap-central.vercel.app/pricing" target="_blank" class="btn btn-sm btn-outline-secondary mt-3 mt-auto w-100">Buy Basic License</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card border-primary border-2 h-100 p-3 text-center position-relative">
                    <span class="position-absolute top-0 start-50 translate-middle badge rounded-pill bg-primary">Popular</span>
                    <h5 class="fw-bold text-primary mt-2">Standard</h5>
                    <h4 class="mb-3">₱500</h4>
                    <ul class="list-unstyled small text-start mx-auto" style="max-width: 150px;">
                        <li>✅ 3 Months Duration</li>
                        <li>❌ No Offline Dashboard</li>
                        <li>✅ Premium Themes</li>
                    </ul>
                    <?php if ($currentLicense['license_type'] === 'standard' && !empty($currentLicense['is_expired'])): ?>
                        <p class="text-danger small mt-auto mb-0 fw-bold">Status: Used & Expired</p>
                    <?php else: ?>
                        <a href="https://storetap-central.vercel.app/pricing" target="_blank" class="btn btn-sm btn-primary mt-3 mt-auto w-100">Buy License</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card border-0 text-white h-100 p-3 text-center" style="background: linear-gradient(135deg, #fdd034 0%, #f37335 33%, #d52d8b 66%, #8a2387 100%);">
                    <h5 class="fw-bold text-white mb-1">Pro</h5>
                    <h4 class="mb-3">₱1500</h4>
                    <ul class="list-unstyled small text-start mx-auto" style="max-width: 150px;">
                        <li>✅ 5 Months Duration</li>
                        <li>✅ Offline Dashboard</li>
                        <li>✅ Premium Themes</li>
                    </ul>
                    <?php if ($currentLicense['license_type'] === 'pro' && !empty($currentLicense['is_expired'])): ?>
                        <p class="text-light small mt-auto mb-0 fw-bold">Status: Used & Expired</p>
                    <?php else: ?>
                        <a href="https://storetap-central.vercel.app/pricing" target="_blank" class="btn btn-sm btn-light mt-3 mt-auto w-100 fw-bold text-dark">Buy License</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
