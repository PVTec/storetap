<div class="page-header d-flex justify-content-between align-items-center mb-3">
    <div>
        <h2 class="mb-1">📶 Offline Dashboard</h2>
        <div class="text-muted d-flex align-items-center flex-wrap gap-2">
            <span>Record sales even without internet.</span>
            <button class="btn btn-sm btn-outline-primary fw-bold" data-bs-toggle="modal" data-bs-target="#pendingTransactionsModal">
                Pending Transactions <span class="badge bg-primary rounded-pill ms-1" id="pendingCountBadgeHeader">0</span>
            </button>
        </div>
    </div>
    <div class="text-end">
        <span id="syncStatus" class="badge bg-secondary mb-1">⏳ Checking status...</span>
        <div id="storageIndicator" class="small text-muted">Storage: --</div>
    </div>
</div>

<div class="alert alert-info" id="offlineAlert" style="display: none;">
    <strong>You are currently offline.</strong> Sales and Utang recorded here will be saved on your device and automatically synced to the server when you reconnect.
</div>

<!-- Online Alert (Feature Disabled) -->
<div class="alert alert-warning" id="onlineAlert" style="display: none;">
    <h4 class="alert-heading">⚠️ Offline Mode Disabled</h4>
    <p>You currently have an active internet connection. To avoid duplicate data and conflicts, the Offline Dashboard is disabled.</p>
    <hr>
    <p class="mb-0 text-muted small">This feature only activates when you have no connection or your WiFi/Data is turned off. Your main dashboard is fully functional.</p>
</div>

<!-- Main Offline Interface Wrapper -->
<div id="offlineInterface" style="display: none;">

<!-- Offline Cart Indicator -->
<div id="offlineCartIndicator" class="row mb-3" style="display: none;">
    <div class="col-12">
        <div class="alert alert-primary d-flex justify-content-between align-items-center m-0">
            <span><strong>Offline Cart:</strong> <span id="cartCount">0</span> items</span>
            <div>
                <button type="button" class="btn btn-sm btn-outline-secondary me-2" onclick="clearCart()">Clear</button>
                <button type="button" class="btn btn-sm btn-success" onclick="openCheckoutModal()">
                    Checkout ₱<span id="cartTotal">0</span>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Products Container (Rendered by JS) -->
<div class="row g-2 g-md-3" id="productsGrid">
    <div class="col-12 text-center py-5">
        <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
        <p class="mt-2 text-muted">Loading products...</p>
    </div>
</div>

<!-- Offline Utang Modal -->
<div class="modal fade" id="utangModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                <h5 class="modal-title fw-bold">Record Offline Utang</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="padding: 1.25rem;">
                <input type="hidden" id="utangProductId" value="">
                <div class="mb-3">
                    <label class="form-label">Product</label>
                    <input type="text" id="utangProductName" class="form-control" disabled style="background: var(--bg-color);">
                </div>
                <div class="mb-3">
                    <label class="form-label">Customer Name</label>
                    <input type="text" id="utangCustomerName" class="form-control" required autocomplete="off">
                </div>
                <div class="mb-0">
                    <label class="form-label">Due Date</label>
                    <input type="date" id="utangDueDate" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                <button type="button" class="btn btn-outline-primary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" onclick="submitOfflineUtang()">Save Utang (Offline)</button>
            </div>
        </div>
    </div>
</div>

<!-- Offline Checkout Modal -->
<div class="modal fade" id="checkoutModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                <h5 class="modal-title fw-bold">🛒 Offline Checkout</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="padding: 1.25rem; max-height: 50vh; overflow-y: auto;">
                <div id="cartItemsList" class="mb-3"></div>
                <div class="border-top pt-3">
                    <div class="d-flex justify-content-between mb-2">
                        <strong>Total:</strong>
                        <strong>₱<span id="checkoutTotal">0</span></strong>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Payment Amount (₱)</label>
                        <input type="number" id="paymentAmount" class="form-control" min="0" step="0.01" required oninput="calculateChange()">
                    </div>
                    <div class="d-flex justify-content-between fs-5" id="changeDisplay" style="display: none !important;">
                        <span>Change:</span>
                        <span class="text-success fw-bold">₱<span id="changeAmount">0</span></span>
                    </div>
                </div>
            </div>
            <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                <button type="button" class="btn btn-outline-primary" data-bs-dismiss="modal">Continue Shopping</button>
                <button type="button" class="btn btn-success" id="completeSaleBtn" disabled onclick="submitOfflineSale()">Complete Sale (Offline)</button>
            </div>
        </div>
    </div>
</div>

<!-- Pending Transactions Modal -->
<div class="modal fade" id="pendingTransactionsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <div class="modal-header bg-light" style="border-bottom: 1px solid var(--border); border-radius: 1rem 1rem 0 0; padding: 1.25rem;">
                <h5 class="modal-title fw-bold">Pending Offline Transactions</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">
                <div id="noPendingMessage" class="text-center p-5 text-muted" style="display: none;">
                    <span style="font-size: 3rem;">📦</span>
                    <p class="mt-3 fs-5">No pending offline transactions.</p>
                </div>
                <div class="table-responsive" id="pendingTransactionsTableWrapper">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th class="ps-3">Time</th>
                                <th>Type</th>
                                <th>Details</th>
                                <th>Total</th>
                                <th class="pe-3">Action</th>
                            </tr>
                        </thead>
                        <tbody id="pendingTransactionsList">
                            <!-- JS rendered rows -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

</div> <!-- /#offlineInterface -->

<script>
// Pass PHP data to JS so it can update localStorage when online
const serverProducts = <?= json_encode($products) ?>;

let cart = [];

document.addEventListener('DOMContentLoaded', () => {
    if (!window.OfflineStorage) {
        console.error("OfflineStorage JS module is missing!");
        document.getElementById('productsGrid').innerHTML = '<div class="alert alert-danger col-12">Failed to load offline storage system. Please refresh the page while online.</div>';
        return;
    }

    // Always ensure localStorage has the freshest server products when we load the page online
    if (serverProducts && serverProducts.length > 0) {
        if (navigator.onLine) {
            OfflineStorage.storeProducts(serverProducts);
        } else {
            const existing = window.OfflineStorage.getProducts();
            if (!existing || existing.length === 0) {
                OfflineStorage.storeProducts(serverProducts);
            }
        }
    }
    
    // Check initial network status
    updateNetworkStatus();

    window.addEventListener('offline', updateNetworkStatus);
    window.addEventListener('online', updateNetworkStatus);

    // Event Listeners for UI
    window.addEventListener('storageUsageUpdate', function(e) {
        const data = e.detail;
        const indicator = document.getElementById('storageIndicator');
        if (indicator) {
            indicator.textContent = 'Storage: ' + data.formatted;
            indicator.style.color = data.percentage > 80 ? '#dc3545' : '';
        }
    });
    
    window.addEventListener('syncComplete', function(e) {
        showSyncStatus();
        renderPendingTransactions(); // Refresh the list if items synced
    });

    const utangModalEl = document.getElementById('utangModal');
    if (utangModalEl) {
        utangModalEl.addEventListener('show.bs.modal', event => {
            const button = event.relatedTarget;
            document.getElementById('utangProductId').value = button.getAttribute('data-product-id');
            document.getElementById('utangProductName').value = button.getAttribute('data-product-name');
            document.getElementById('utangCustomerName').value = '';
            document.getElementById('utangDueDate').value = '';
        });
    }

    // Initialize UI
    renderProducts();
    renderPendingTransactions();
    OfflineStorage.updateStorageUsage();
    showSyncStatus();
    setInterval(showSyncStatus, 5000);
    setInterval(renderPendingTransactions, 5000); // Poll pending updates
});

function updateNetworkStatus() {
    const isOnline = navigator.onLine;
    const offlineAlert = document.getElementById('offlineAlert');
    const onlineAlert = document.getElementById('onlineAlert');
    const offlineInterface = document.getElementById('offlineInterface');
    
    if (isOnline) {
        // Online: Disable feature
        offlineAlert.style.display = 'none';
        onlineAlert.style.display = 'block';
        offlineInterface.style.display = 'none';
    } else {
        // Offline: Enable feature
        offlineAlert.style.display = 'block';
        onlineAlert.style.display = 'none';
        offlineInterface.style.display = 'block';
    }
}

function renderProducts() {
    const grid = document.getElementById('productsGrid');
    const products = window.OfflineStorage ? window.OfflineStorage.getProducts() : null;

    if (!products || products.length === 0) {
        grid.innerHTML = '<div class="col-12 text-center text-muted py-4">No products available. Please connect to the internet to load products.</div>';
        return;
    }

    let html = '';
    products.forEach(p => {
        const outOfStock = parseInt(p.stock_qty) <= 0;
        const stockBadge = outOfStock ? 
            `<span class="badge bg-danger" style="font-size: 0.65rem;">OUT</span>` : 
            (parseInt(p.stock_qty) <= 5 ? `<span class="badge bg-warning" style="font-size: 0.65rem;">LOW</span>` : '');
            
        const imageHtml = p.image ? 
            `<img src="${p.image}" class="product-image">` : 
            `<div class="product-image placeholder">No image</div>`;

        html += `
        <div class="col-12 col-sm-6 col-lg-4">
            <div class="card product-card h-100">
                <div class="product-image-wrapper mb-3">
                    ${imageHtml}
                </div>
                <div class="card-body d-flex flex-column">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h5 class="card-title mb-0">${p.product_name}</h5>
                        <div class="d-flex gap-1">
                            <span class="badge bg-success cart-indicator d-none" id="cart-indicator-${p.id}" style="font-size: 0.65rem;">
                                In Cart: <span class="cart-qty">0</span>
                            </span>
                            ${stockBadge}
                        </div>
                    </div>
                    <div class="price mb-1">₱ ${parseFloat(p.price).toFixed(2)}</div>
                    <div class="stock mb-3">${p.stock_qty} in stock</div>
                    
                    <div class="mt-auto d-flex gap-2">
                        <button type="button" class="btn btn-outline-primary action-btn w-100"
                            onclick="addToCart(${p.id}, '${p.product_name.replace(/'/g, "\\'")}', ${p.price}, ${p.stock_qty})"
                            ${outOfStock ? 'disabled' : ''}>
                            Add to Cart
                        </button>
                        <button type="button" class="btn btn-outline-secondary action-btn"
                            data-bs-toggle="modal" data-bs-target="#utangModal"
                            data-product-id="${p.id}"
                            data-product-name="${p.product_name.replace(/'/g, "\\'")}"
                            ${outOfStock ? 'disabled' : ''}>
                            Utang
                        </button>
                    </div>
                </div>
            </div>
        </div>`;
    });

    grid.innerHTML = html;
    
    // Re-apply cart indicators if cart has items
    cart.forEach(item => updateProductCartIndicator(item.productId));
}

function addToCart(productId, productName, price, stockQty) {
    const existingItem = cart.find(item => item.productId === productId);
    if (existingItem) {
        if (existingItem.qty < stockQty) {
            existingItem.qty++;
        } else {
            alert('Maximum stock reached for this product!');
            return;
        }
    } else {
        cart.push({ productId, productName, price: parseFloat(price), qty: 1 });
    }
    document.getElementById('offlineCartIndicator').style.display = 'block';
    updateCartDisplay();
}

function removeFromCart(index) {
    const item = cart[index];
    const productId = item ? item.productId : null;
    cart.splice(index, 1);
    updateCartDisplay();
    if (productId) {
        updateProductCartIndicator(productId);
    }
    if (cart.length === 0) {
        document.getElementById('offlineCartIndicator').style.display = 'none';
        const modal = bootstrap.Modal.getInstance(document.getElementById('checkoutModal'));
        if (modal) modal.hide();
    } else {
        openCheckoutModal(); // Refresh modal
    }
}

function clearCart() {
    const productIds = cart.map(item => item.productId);
    cart = [];
    document.getElementById('offlineCartIndicator').style.display = 'none';
    updateCartDisplay();
    productIds.forEach(productId => updateProductCartIndicator(productId));
}

function updateProductCartIndicator(productId) {
    const indicator = document.getElementById('cart-indicator-' + productId);
    if (!indicator) return;
    
    const item = cart.find(item => item.productId === productId);
    if (item && item.qty > 0) {
        indicator.querySelector('.cart-qty').textContent = item.qty;
        indicator.classList.remove('d-none');
    } else {
        indicator.classList.add('d-none');
        indicator.querySelector('.cart-qty').textContent = '0';
    }
}

function updateCartDisplay() {
    const count = cart.reduce((sum, item) => sum + item.qty, 0);
    const total = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    document.getElementById('cartCount').textContent = count;
    document.getElementById('cartTotal').textContent = total.toLocaleString('en-PH', {minimumFractionDigits: 0, maximumFractionDigits: 0});
    cart.forEach(item => updateProductCartIndicator(item.productId));
}

function openCheckoutModal() {
    if (cart.length === 0) return;
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    document.getElementById('checkoutTotal').textContent = total.toLocaleString('en-PH', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    
    let itemsHtml = '';
    cart.forEach((item, index) => {
        itemsHtml += `
            <div class="d-flex justify-content-between align-items-center mb-2 p-2" style="background: var(--bg-color); border-radius: 0.5rem;">
                <div>
                    <div class="fw-bold">${item.productName}</div>
                    <small class="text-muted">₱${item.price.toFixed(2)} × ${item.qty}</small>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="fw-bold">₱${(item.price * item.qty).toFixed(2)}</span>
                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeFromCart(${index})">×</button>
                </div>
            </div>
        `;
    });
    document.getElementById('cartItemsList').innerHTML = itemsHtml;
    
    document.getElementById('paymentAmount').value = '';
    document.getElementById('changeDisplay').style.display = 'none';
    document.getElementById('completeSaleBtn').disabled = true;
    
    const modal = bootstrap.Modal.getInstance(document.getElementById('checkoutModal')) || new bootstrap.Modal(document.getElementById('checkoutModal'));
    modal.show();
}

function calculateChange() {
    const total = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    const payment = parseFloat(document.getElementById('paymentAmount').value) || 0;
    const change = payment - total;
    
    document.getElementById('changeAmount').textContent = change.toFixed(2);
    document.getElementById('changeDisplay').style.display = change >= 0 ? 'flex !important' : 'none';
    document.getElementById('completeSaleBtn').disabled = change < 0;
}

function submitOfflineSale() {
    if (!window.OfflineStorage) return;

    const btn = document.getElementById('completeSaleBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Processing...';

    // Queue each item in the cart
    cart.forEach(item => {
        OfflineStorage.instantSale({
            productId: item.productId,
            productName: item.productName,
            price: item.price,
            qty: item.qty,
            total: item.price * item.qty,
            timestamp: Date.now()
        });
    });

    // Update local stock immediately for better offline UX
    const products = OfflineStorage.getProducts();
    if (products) {
        cart.forEach(item => {
            const p = products.find(p => p.id == item.productId);
            if (p) p.stock_qty = parseInt(p.stock_qty) - item.qty;
        });
        OfflineStorage.storeProducts(products);
        renderProducts(); // Re-render grid to show updated stock
    }

    setTimeout(() => {
        clearCart();
        const modal = bootstrap.Modal.getInstance(document.getElementById('checkoutModal'));
        if (modal) modal.hide();
        
        btn.disabled = false;
        btn.innerHTML = 'Complete Sale (Offline)';
        
        // Show success toast
        if (typeof showToast === 'function') {
            showToast('Sale saved locally! Will sync when online.', 'success');
        } else {
            alert('Sale saved locally! Will sync when online.');
        }
        
        showSyncStatus();
        renderPendingTransactions();
    }, 500);
}

function submitOfflineUtang() {
    if (!window.OfflineStorage) return;

    const customerName = document.getElementById('utangCustomerName').value.trim();
    const dueDate = document.getElementById('utangDueDate').value;
    const productId = document.getElementById('utangProductId').value;
    const productName = document.getElementById('utangProductName').value;
    
    if (!customerName || !dueDate) {
        alert("Please fill in all fields.");
        return;
    }

    // Get price from local products
    const products = OfflineStorage.getProducts();
    let price = 0;
    if (products) {
        const p = products.find(p => p.id == productId);
        if (p) {
            price = p.price;
            p.stock_qty = parseInt(p.stock_qty) - 1; // deduct stock locally
        }
        OfflineStorage.storeProducts(products);
    }

    OfflineStorage.instantUtang({
        productId: productId,
        productName: productName,
        customerName: customerName,
        dueDate: dueDate,
        price: price,
        qty: 1,
        total: price,
        timestamp: Date.now()
    });

    renderProducts();

    const modal = bootstrap.Modal.getInstance(document.getElementById('utangModal'));
    if (modal) modal.hide();

    if (typeof showToast === 'function') {
        showToast('Utang saved locally! Will sync when online.', 'success');
    } else {
        alert('Utang saved locally! Will sync when online.');
    }
    
    showSyncStatus();
    renderPendingTransactions();
}

function showSyncStatus() {
    if (!window.OfflineStorage) return;
    
    const status = OfflineStorage.getSyncStatus();
    const statusEl = document.getElementById('syncStatus');
    
    if (statusEl && status) {
        const totalPending = (status.pendingSales || 0) + (status.pendingUtang || 0);
        
        if (!OfflineStorage.isOnline()) {
            statusEl.textContent = '⚠ Offline - ' + totalPending + ' pending';
            statusEl.className = 'badge bg-warning';
        } else if (totalPending > 0) {
            statusEl.textContent = '⏳ Syncing ' + totalPending + ' items...';
            statusEl.className = 'badge bg-info';
        } else {
            const lastSync = status.lastSync ? new Date(status.lastSync).toLocaleTimeString() : 'Never';
            statusEl.textContent = '✓ Synced ' + lastSync;
            statusEl.className = 'badge bg-success';
        }
    }
}

function renderPendingTransactions() {
    if (!window.OfflineStorage) return;
    
    const sales = OfflineStorage.getSalesQueue() || [];
    const utang = OfflineStorage.getUtangQueue() || [];
    
    const totalPending = sales.length + utang.length;
    const badgeHeader = document.getElementById('pendingCountBadgeHeader');
    const tableWrapper = document.getElementById('pendingTransactionsTableWrapper');
    const noMsg = document.getElementById('noPendingMessage');
    const list = document.getElementById('pendingTransactionsList');
    
    if (badgeHeader) badgeHeader.textContent = totalPending;
    
    if (totalPending === 0) {
        if (tableWrapper) tableWrapper.style.display = 'none';
        if (noMsg) noMsg.style.display = 'block';
        return;
    }
    
    if (tableWrapper) tableWrapper.style.display = 'block';
    if (noMsg) noMsg.style.display = 'none';
    
    // Combine and sort by timestamp (newest first)
    let allPending = [
        ...sales.map(s => ({...s, type: 'Sale'})),
        ...utang.map(u => ({...u, type: 'Utang'}))
    ];
    allPending.sort((a, b) => b.timestamp - a.timestamp);
    
    let html = '';
    allPending.forEach(item => {
        const time = new Date(item.timestamp).toLocaleTimeString();
        let details = item.productName;
        if (item.type === 'Sale') {
            details += ` (x${item.qty})`;
        } else {
            details += ` <br><small class="text-muted">To: ${item.customerName}</small>`;
        }
        
        const typeBadge = item.type === 'Sale' 
            ? `<span class="badge bg-success">Sale</span>` 
            : `<span class="badge bg-warning text-dark">Utang</span>`;
            
        const removeAction = item.type === 'Sale'
            ? `<button class="btn btn-sm btn-outline-danger" onclick="confirmRemoveOfflineSale('${item.id}')">Remove</button>`
            : `<button class="btn btn-sm btn-outline-danger" onclick="confirmRemoveOfflineUtang('${item.id}')">Remove</button>`;
            
        html += `
        <tr>
            <td><small>${time}</small></td>
            <td>${typeBadge}</td>
            <td>${details}</td>
            <td class="fw-bold">₱${parseFloat(item.total).toFixed(2)}</td>
            <td>${removeAction}</td>
        </tr>`;
    });
    
    list.innerHTML = html;
}

function confirmRemoveOfflineSale(id) {
    if (confirm('Are you sure you want to remove this offline sale? It will NOT be synced.')) {
        if (OfflineStorage.removeOfflineSale(id)) {
            if (typeof showToast === 'function') showToast('Offline sale removed', 'success');
            renderPendingTransactions();
            renderProducts(); // Restore stock in UI
            showSyncStatus();
        }
    }
}

function confirmRemoveOfflineUtang(id) {
    if (confirm('Are you sure you want to remove this offline utang? It will NOT be synced.')) {
        if (OfflineStorage.removeOfflineUtang(id)) {
            if (typeof showToast === 'function') showToast('Offline utang removed', 'success');
            renderPendingTransactions();
            renderProducts(); // Restore stock in UI
            showSyncStatus();
        }
    }
}
</script>
