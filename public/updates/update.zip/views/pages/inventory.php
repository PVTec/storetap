<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <div>
        <h2>Inventory</h2>
        <p>View stock levels and low stock warnings.</p>
    </div>
    <div class="d-flex gap-2 align-items-center">
        <span class="badge bg-primary"><?= intval($inventoryStats['total_products']) ?> products</span>
        <span class="badge bg-secondary"><?= intval($inventoryStats['current_stock']) ?> current stock</span>
        <?php if (isAdmin()): ?>
            <button type="button" class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#inventoryHistoryModal">
                📋 History
            </button>
            <form method="post" class="m-0 p-0">
                <input type="hidden" name="action" value="clear_inventory">
                <button type="submit" class="btn btn-sm btn-outline-secondary" onclick="return confirm('Clear all inventory data? This cannot be undone.')">Clear</button>
            </form>
        <?php endif; ?>
    </div>
</div>

<div class="row g-3">
    <div class="col-12 col-lg-4">
        <div class="card stat-card">
            <div class="stat-label mb-2">Inventory Summary</div>
            <div class="d-flex justify-content-between align-items-center py-2" style="border-bottom: 1px solid var(--border);">
                <span class="text-secondary">Total Products</span>
                <span class="fw-semibold"><?= intval($inventoryStats['total_products']) ?></span>
            </div>
            <div class="d-flex justify-content-between align-items-center py-2" style="border-bottom: 1px solid var(--border);">
                <span class="text-secondary">Total Units Added</span>
                <span class="fw-semibold"><?= intval($inventoryStats['total_units_ever'] ?? 0) ?></span>
            </div>
            <div class="d-flex justify-content-between align-items-center py-2" style="border-bottom: 1px solid var(--border);">
                <span class="text-secondary">Current Stock</span>
                <span class="fw-semibold"><?= intval($inventoryStats['current_stock']) ?></span>
            </div>
            <div class="d-flex justify-content-between align-items-center py-2" style="border-bottom: 1px solid var(--border);">
                <span class="text-secondary">Expected Income</span>
                <span class="fw-semibold">₱<?= number_format($inventoryStats['expected_income'] ?? 0, 2) ?></span>
            </div>
            <div class="d-flex justify-content-between align-items-center py-2">
                <span class="text-secondary">Low Stock Items</span>
                <span class="fw-semibold <?= $lowStockCount > 0 ? 'text-warning' : '' ?>"><?= $lowStockCount ?></span>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-8">
        <div class="card p-3">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Original Stock</th>
                            <th>Current Stock</th>
                            <th>Status</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($products)): ?>
                            <tr><td colspan="6" class="text-center text-secondary py-4">No products available.</td></tr>
                        <?php endif; ?>
                        <?php
                        // $today is passed from controller using getSystemTime()
                        foreach ($products as $product):
                            $lastCheck = $lastChecks[$product['id']] ?? null;
                            $isCheckedToday = $lastCheck && date('Y-m-d', strtotime($lastCheck['date_created'])) === $today;
                        ?>
                            <tr class="<?= $isCheckedToday ? 'table-success' : '' ?>">
                                <td>
                                    <?= sanitize($product['product_name']) ?>
                                    <?php if ($lastCheck): ?>
                                        <small class="text-muted d-block">
                                            Last check: <?= date('M d, H:i', strtotime($lastCheck['date_created'])) ?> by <?= sanitize($lastCheck['checked_by']) ?>
                                            <?php if ($isCheckedToday): ?>
                                                <span class="badge bg-success ms-1" style="font-size: 0.6em;">TODAY</span>
                                            <?php endif; ?>
                                        </small>
                                    <?php endif; ?>
                                </td>
                                <td>₱<?= number_format($product['price'], 2) ?></td>
                                <td><?= intval($product['initial_stock'] ?? $product['stock_qty']) ?></td>
                                <td><?= intval($product['stock_qty']) ?></td>
                                <td>
                                    <?php if ($product['stock_qty'] <= 0): ?>
                                        <span class="badge bg-danger">Out</span>
                                    <?php elseif ($product['stock_qty'] <= 5): ?>
                                        <span class="badge bg-warning">Low</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">OK</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end">
                                    <div class="btn-group" role="group">
                                        <!-- Check Button - Always enabled, shows visual feedback when checked today -->
                                        <form method="post" class="d-inline">
                                            <input type="hidden" name="action" value="check_inventory">
                                            <input type="hidden" name="product_id" value="<?= intval($product['id']) ?>">
                                            <input type="hidden" name="actual_qty" value="<?= intval($product['stock_qty']) ?>">
                                            <input type="hidden" name="check_notes" value="Stock verified correct">
                                            <button type="submit" class="btn btn-sm <?= $isCheckedToday ? 'btn-success' : 'btn-outline-success' ?>" onclick="return confirm('Confirm that <?= intval($product['stock_qty']) ?> <?= sanitize($product['product_name']) ?> is correct?')">
                                                ✓ <?= $isCheckedToday ? 'Checked' : 'Check' ?>
                                            </button>
                                        </form>
                                        <!-- Adjust Button - Open modal to adjust stock -->
                                        <button type="button" class="btn btn-sm btn-outline-warning"
                                            data-bs-toggle="modal" data-bs-target="#adjustInventoryModal"
                                            data-product-id="<?= intval($product['id']) ?>"
                                            data-product-name="<?= sanitize($product['product_name']) ?>"
                                            data-current-qty="<?= intval($product['stock_qty']) ?>">
                                            ⚙ Adjust
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Adjust Inventory Modal -->
<div class="modal fade" id="adjustInventoryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <form method="post">
                <input type="hidden" name="action" value="check_inventory">
                <input type="hidden" name="product_id" id="adjustProductId" value="">
                <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                    <h5 class="modal-title fw-bold">Adjust Inventory</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="padding: 1.25rem;">
                    <div class="mb-3">
                        <label class="form-label">Product</label>
                        <input type="text" id="adjustProductName" class="form-control" disabled style="background: var(--bg-color);">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Current System Stock</label>
                        <input type="number" id="adjustCurrentQty" class="form-control" disabled style="background: var(--bg-color);">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Actual Stock Count <span class="text-danger">*</span></label>
                        <input type="number" name="actual_qty" id="adjustActualQty" class="form-control" min="0" required>
                        <small class="text-muted">Enter the actual quantity you counted (e.g., missing items, damaged goods).</small>
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Reason for Adjustment <span class="text-danger">*</span></label>
                        <textarea name="check_notes" class="form-control" rows="2" placeholder="e.g., 3 items damaged, 2 items missing, stock correction..." required></textarea>
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                    <button type="button" class="btn btn-outline-primary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">Adjust Stock</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Inventory History Modal -->
<div class="modal fade" id="inventoryHistoryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                <h5 class="modal-title fw-bold">📋 Inventory Check History</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="padding: 1.25rem; max-height: 60vh; overflow-y: auto;">
                <?php
                $allChecks = $allInventoryChecks ?? [];
                // $today is passed from controller using getSystemTime()
                ?>
                <?php if (empty($allChecks)): ?>
                    <div class="text-center text-secondary py-4">No inventory checks recorded yet.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Product</th>
                                    <th>Checked By</th>
                                    <th>Expected</th>
                                    <th>Actual</th>
                                    <th>Diff</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($allChecks as $check):
                                    $isToday = date('Y-m-d', strtotime($check['date_created'])) === $today;
                                    $hasDiscrepancy = $check['missing_qty'] != 0;
                                ?>
                                    <tr class="<?= $isToday ? 'table-success' : '' ?>">
                                        <td>
                                            <?= date('M d', strtotime($check['date_created'])) ?>
                                            <small class="text-muted d-block"><?= date('H:i', strtotime($check['date_created'])) ?></small>
                                            <?php if ($isToday): ?>
                                                <span class="badge bg-success" style="font-size: 0.6em;">TODAY</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= sanitize($check['product_name']) ?></td>
                                        <td><span class="badge bg-info"><?= sanitize($check['checked_by']) ?></span></td>
                                        <td><?= intval($check['expected_qty']) ?></td>
                                        <td><?= intval($check['actual_qty']) ?></td>
                                        <td>
                                            <?php if ($check['missing_qty'] > 0): ?>
                                                <span class="badge bg-danger">-<?= intval($check['missing_qty']) ?></span>
                                            <?php elseif ($check['missing_qty'] < 0): ?>
                                                <span class="badge bg-primary">+<?= abs(intval($check['missing_qty'])) ?></span>
                                            <?php else: ?>
                                                <span class="badge bg-success">0</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($check['notes']): ?>
                                                <small class="text-muted" style="white-space: pre-line;"><?= nl2br(sanitize($check['notes'])) ?></small>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    // Adjust Inventory Modal Handler
    const adjustInventoryModal = document.getElementById('adjustInventoryModal');
    adjustInventoryModal.addEventListener('show.bs.modal', event => {
        const button = event.relatedTarget;
        const productId = button.getAttribute('data-product-id');
        const productName = button.getAttribute('data-product-name');
        const currentQty = button.getAttribute('data-current-qty');

        document.getElementById('adjustProductId').value = productId;
        document.getElementById('adjustProductName').value = productName;
        document.getElementById('adjustCurrentQty').value = currentQty;
        document.getElementById('adjustActualQty').value = currentQty;
    });
</script>
