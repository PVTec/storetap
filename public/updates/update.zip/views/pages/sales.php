<div class="page-header d-flex justify-content-between align-items-center">
    <div>
        <h2>Sales</h2>
        <p class="mb-0"><?= $isAdmin ? 'View and manage all sales transactions.' : 'View and manage your today\'s sales only.' ?></p>
    </div>
    <?php if ($isAdmin): ?>
    <form method="get" class="d-flex gap-2">
        <input type="hidden" name="page" value="sales">
        <input type="date" name="date" value="<?= sanitize($filterDate) ?>" class="form-control">
        <button type="submit" class="btn btn-primary">Filter</button>
        <?php if ($filterDate): ?>
        <a href="index.php?page=sales" class="btn btn-outline-secondary">Clear</a>
        <?php endif; ?>
    </form>
    <?php endif; ?>
</div>

<!-- Mobile Sales Cards -->
<div class="d-md-none">
    <?php if (empty($sales)): ?>
        <div class="text-center text-secondary py-4">
            <?= $isAdmin ? 'No sales records found.' : 'No sales records for today.' ?>
        </div>
    <?php endif; ?>
    <?php foreach ($sales as $sale): ?>
        <?php
        $saleDate = date('Y-m-d', strtotime($sale['date_created']));
        $isToday = $saleDate === $today;
        $isOwnSale = $sale['created_by'] === $currentUser;
        $canEdit = $isAdmin || ($isOwnSale && $isToday);
        ?>
        <div class="card mb-3" style="border: 1px solid var(--border); border-radius: 12px;">
            <div class="card-body p-3">
                <!-- Product Name & Qty Badge -->
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div class="fw-bold fs-6" style="line-height: 1.3;"><?= sanitize($sale['product_name']) ?></div>
                    <span class="badge bg-primary" style="font-size: 0.9rem; padding: 0.5em 0.75em;"><?= intval($sale['qty']) ?> qty</span>
                </div>
                
                <!-- Price & Date Row -->
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-success fw-bold fs-5">₱<?= number_format($sale['total'], 2) ?></span>
                    <span class="text-muted" style="font-size: 0.9rem;"><?= date('M d, g:i A', strtotime($sale['date_created'])) ?></span>
                </div>
                
                <!-- Cashier Info -->
                <?php if ($isAdmin): ?>
                    <div class="text-muted mb-3" style="font-size: 0.9rem;">
                        <i class="bi bi-person-circle"></i> <?= sanitize($sale['created_by'] ?? 'system') ?>
                    </div>
                <?php endif; ?>
                
                <!-- Notes -->
                <?php if ($sale['notes']): ?>
                    <div class="p-3 rounded mb-3" style="background: var(--bg-color); font-size: 0.95rem; border-left: 3px solid var(--accent);">
                        <div class="text-muted mb-1" style="font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.5px;">Note</div>
                        <?= nl2br(sanitize($sale['notes'])) ?>
                    </div>
                <?php endif; ?>
                
                <!-- Action Buttons -->
                <?php if ($canEdit): ?>
                    <div class="d-flex gap-2 mt-2">
                        <button type="button" class="btn btn-outline-primary flex-grow-1 py-2"
                            data-bs-toggle="modal" data-bs-target="#editSaleModal"
                            data-sale-id="<?= intval($sale['id']) ?>"
                            data-product-name="<?= sanitize($sale['product_name']) ?>"
                            data-current-qty="<?= intval($sale['qty']) ?>"
                            data-price="<?= floatval($sale['original_price'] ?? $sale['price']) ?>">
                            Edit Price
                        </button>
                        <form method="post" class="m-0" onsubmit="return confirm('Delete this sale? Stock will be restored.');">
                            <input type="hidden" name="action" value="delete_sale">
                            <input type="hidden" name="sale_id" value="<?= intval($sale['id']) ?>">
                            <button type="submit" class="btn btn-outline-danger py-2 px-3">Delete</button>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="mt-2 p-2 rounded text-center" style="background: var(--bg-color); font-size: 0.875rem;">
                        <span class="text-muted">
                            <?php if (!$isToday): ?>
                                <i class="bi bi-lock"></i> Locked (not today)
                            <?php elseif (!$isOwnSale): ?>
                                <i class="bi bi-lock"></i> Locked (not yours)
                            <?php endif; ?>
                        </span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Desktop Sales Table -->
<div class="d-none d-md-block card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Qty</th>
                        <th>Total</th>
                        <th>Date</th>
                        <th>Cashier</th>
                        <th>Notes</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($sales)): ?>
                        <tr>
                            <td colspan="7" class="text-center text-secondary py-4">
                                <?= $isAdmin ? 'No sales records found.' : 'No sales records for today.' ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php foreach ($sales as $sale): ?>
                        <?php
                        $saleDate = date('Y-m-d', strtotime($sale['date_created']));
                        $isToday = $saleDate === $today;
                        $isOwnSale = $sale['created_by'] === $currentUser;
                        $canEdit = $isAdmin || ($isOwnSale && $isToday);
                        ?>
                        <tr>
                            <td>
                                <div class="fw-semibold"><?= sanitize($sale['product_name']) ?></div>
                            </td>
                            <td><?= intval($sale['qty']) ?></td>
                            <td class="text-success fw-semibold">₱<?= number_format($sale['total'], 2) ?></td>
                            <td>
                                <?= date('M d, Y', strtotime($sale['date_created'])) ?>
                                <small class="text-muted d-block"><?= date('g:i A', strtotime($sale['date_created'])) ?></small>
                                <?php if ($sale['date_updated']): ?>
                                    <small class="text-muted d-block">Updated <?= date('M d H:i', strtotime($sale['date_updated'])) ?></small>
                                <?php endif; ?>
                            </td>
                            <td><?= sanitize($sale['created_by'] ?? 'system') ?></td>
                            <td>
                                <?php if ($sale['notes']): ?>
                                    <div class="p-2 rounded" style="background: var(--bg-color); max-width: 250px; font-size: 0.875rem;">
                                        <?= nl2br(sanitize($sale['notes'])) ?>
                                    </div>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <?php if ($canEdit): ?>
                                    <div class="d-flex gap-1 justify-content-end">
                                        <button type="button" class="btn btn-sm btn-outline-primary"
                                            data-bs-toggle="modal" data-bs-target="#editSaleModal"
                                            data-sale-id="<?= intval($sale['id']) ?>"
                                            data-product-name="<?= sanitize($sale['product_name']) ?>"
                                            data-current-qty="<?= intval($sale['qty']) ?>"
                                            data-price="<?= floatval($sale['original_price'] ?? $sale['price']) ?>">
                                            Edit Price
                                        </button>
                                        <form method="post" class="m-0" onsubmit="return confirm('Delete this sale? Stock will be restored.');">
                                            <input type="hidden" name="action" value="delete_sale">
                                            <input type="hidden" name="sale_id" value="<?= intval($sale['id']) ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    </div>
                                <?php else: ?>
                                    <span class="text-muted small">
                                        <?php if (!$isToday): ?>
                                            Locked (not today)
                                        <?php elseif (!$isOwnSale): ?>
                                            Locked (not yours)
                                        <?php endif; ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Edit Sale Modal -->
<div class="modal fade" id="editSaleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <form method="post">
                <input type="hidden" name="action" value="edit_sale">
                <input type="hidden" name="sale_id" id="editSaleId" value="">
                <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                    <h5 class="modal-title fw-bold">Edit Sale</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="padding: 1.25rem;">
                    <div class="mb-3">
                        <label class="form-label">Product</label>
                        <input type="text" id="editProductName" class="form-control" disabled style="background: var(--bg-color);">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Original Price</label>
                        <input type="text" id="editOriginalPrice" class="form-control" disabled style="background: var(--bg-color);">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Custom Price <span class="text-danger">*</span></label>
                        <input type="number" name="custom_price" id="editCustomPrice" class="form-control" min="0" step="0.01" required>
                        <small class="text-muted">Enter the selling price for this customer (e.g., original 200, sell for 150)</small>
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Note <span class="text-danger">*</span></label>
                        <textarea name="note" class="form-control" rows="2" placeholder="Reason for price change (e.g., special discount, damaged item, loyal customer)" required></textarea>
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                    <button type="button" class="btn btn-outline-primary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Edit Sale Modal Handler
    const editSaleModal = document.getElementById('editSaleModal');
    editSaleModal.addEventListener('show.bs.modal', event => {
        const button = event.relatedTarget;
        const saleId = button.getAttribute('data-sale-id');
        const productName = button.getAttribute('data-product-name');
        const currentQty = button.getAttribute('data-current-qty');
        const price = button.getAttribute('data-price');

        document.getElementById('editSaleId').value = saleId;
        document.getElementById('editProductName').value = productName;
        document.getElementById('editOriginalPrice').value = '₱' + parseFloat(price).toFixed(2);
        document.getElementById('editCustomPrice').value = price;
    });
</script>
