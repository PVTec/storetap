<div class="page-header">
    <h2>Manage Products</h2>
    <p>Add, edit, or remove store products.</p>
</div>

<div class="row g-3">
    <div class="col-lg-5">
        <div class="card p-4">
            <h5 class="mb-3 fw-bold"><?= $editProduct ? 'Edit Product' : 'Add Product' ?></h5>
            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="product_id" value="<?= intval($editProduct['id'] ?? 0) ?>">
                <input type="hidden" name="action" value="<?= $editProduct ? 'update' : 'create' ?>">
                <div class="mb-3">
                    <label class="form-label">Product Name</label>
                    <input type="text" name="product_name" class="form-control" value="<?= sanitize($editProduct['product_name'] ?? '') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Price</label>
                    <input type="number" name="price" step="0.01" min="0" class="form-control" value="<?= sanitize($editProduct['price'] ?? '0.00') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Stock Quantity</label>
                    <input type="number" name="stock_qty" min="0" class="form-control" value="<?= sanitize($editProduct['stock_qty'] ?? '0') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Product Image (Optional)</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                    <?php if ($editProduct && $editProduct['image']): ?>
                        <small class="text-muted">Current: <img src="<?= sanitize($editProduct['image']) ?>" alt="Current image" style="max-width: 50px; max-height: 50px;"></small>
                    <?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary"><?= $editProduct ? 'Update' : 'Add' ?></button>
                <?php if ($editProduct): ?>
                    <a href="index.php?page=product_manage" class="btn btn-outline-primary ms-2">Cancel</a>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="card p-3">
            <h5 class="mb-3 fw-bold">Product List</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($products)): ?>
                            <tr>
                                <td colspan="5" class="text-center py-5">
                                    <div class="empty-state-container p-4 rounded-3 d-flex flex-column align-items-center justify-content-center" style="background: var(--bg-color, #ffffff); border: 2px dashed var(--border, #dee2e6); min-height: 250px;">
                                        <div class="mb-3" style="font-size: 3.5rem; opacity: 0.8;">📦</div>
                                        <h4 class="fw-bold mb-2">No Products Added Yet</h4>
                                        <p class="text-muted mb-0 mx-auto" style="max-width: 350px;">
                                            Your product list is empty. Use the form on the left to add your first product.
                                        </p>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td>
                                        <?php if ($product['image']): ?>
                                            <img src="<?= sanitize($product['image']) ?>" alt="Product image" style="max-width: 50px; max-height: 50px;">
                                        <?php else: ?>
                                            No image
                                        <?php endif; ?>
                                    </td>
                                    <td><?= sanitize($product['product_name']) ?></td>
                                    <td>₱<?= number_format($product['price'], 2) ?></td>
                                    <td><?= intval($product['stock_qty']) ?></td>
                                    <td class="text-end">
                                        <a href="index.php?page=product_manage&edit=<?= intval($product['id']) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                        <form method="post" class="d-inline-block" onsubmit="return confirm('Delete this product?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="product_id" value="<?= intval($product['id']) ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if (isset($totalPages) && $totalPages > 1): ?>
    <div class="row mt-3">
        <div class="col-12 d-flex justify-content-between align-items-center">
            <div class="text-secondary">
                Showing <?= min(($currentPage - 1) * $limit + 1, $totalProducts) ?> to <?= min($currentPage * $limit, $totalProducts) ?> of <?= $totalProducts ?> products
            </div>
            <nav aria-label="Product list pagination">
                <ul class="pagination mb-0">
                    <li class="page-item <?= $currentPage <= 1 ? 'disabled' : '' ?>">
                        <a class="page-link" href="index.php?page=product_manage&page_num=<?= max(1, $currentPage - 1) ?><?= isset($_GET['edit']) ? '&edit=' . intval($_GET['edit']) : '' ?>">Previous</a>
                    </li>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= $i === $currentPage ? 'active' : '' ?>">
                            <a class="page-link" href="index.php?page=product_manage&page_num=<?= $i ?><?= isset($_GET['edit']) ? '&edit=' . intval($_GET['edit']) : '' ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= $currentPage >= $totalPages ? 'disabled' : '' ?>">
                        <a class="page-link" href="index.php?page=product_manage&page_num=<?= min($totalPages, $currentPage + 1) ?><?= isset($_GET['edit']) ? '&edit=' . intval($_GET['edit']) : '' ?>">Next</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
<?php endif; ?>

<script>
// Flag that offline cache needs re-sync after product add/edit
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', () => {
        localStorage.setItem('storetap_needs_sync', '1');
    });
});
</script>
