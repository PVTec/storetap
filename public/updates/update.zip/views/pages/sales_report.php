<div class="page-header">
    <h2>Reports</h2>
    <p>View sales and utang history by period.</p>
</div>

<div class="row g-3 mb-4">
    <div class="col-12">
        <form method="get" class="row g-2 align-items-end">
            <input type="hidden" name="page" value="sales_report">
            <div class="col-auto">
                <label class="form-label">Period</label>
                <select name="period" class="form-select">
                    <option value="today" <?= ($period ?? 'today') === 'today' ? 'selected' : '' ?>>Today</option>
                    <option value="yesterday" <?= ($period ?? '') === 'yesterday' ? 'selected' : '' ?>>Yesterday</option>
                    <option value="last_7_days" <?= ($period ?? '') === 'last_7_days' ? 'selected' : '' ?>>Last 7 Days</option>
                    <option value="this_month" <?= ($period ?? '') === 'this_month' ? 'selected' : '' ?>>This Month</option>
                    <option value="custom" <?= ($period ?? '') === 'custom' ? 'selected' : '' ?>>Custom Range</option>
                </select>
            </div>
            <div class="col-auto">
                <label class="form-label">Start</label>
                <input type="date" name="start_date" value="<?= sanitize($startDate ?? '') ?>" class="form-control">
            </div>
            <div class="col-auto">
                <label class="form-label">End</label>
                <input type="date" name="end_date" value="<?= sanitize($endDate ?? '') ?>" class="form-control">
            </div>
            <div class="col-auto">
                <button type="submit" class="btn btn-primary w-100">Apply</button>
            </div>
        </form>
    </div>
</div>

<div class="row g-2 g-md-3 mb-4">
    <div class="col-12">
        <div class="card p-3 mb-3">
            <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                <div>
                    <div class="text-secondary mb-1">Showing</div>
                    <div class="h5 mb-0"><?= sanitize($periodLabel ?? 'Today') ?></div>
                </div>
                <div class="text-end">
                    <div class="text-secondary">Range</div>
                    <div class="fw-semibold"><?= sanitize(($startDate ?? $today)) ?> to <?= sanitize(($endDate ?? $today)) ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-2 g-md-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card stat-card">
            <div class="stat-label">Items Sold</div>
            <div class="stat-value"><?= intval($salesSummary['total_items'] ?? 0) ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card stat-card">
            <div class="stat-label">Cash Income</div>
            <div class="stat-value">₱<?= number_format($salesSummary['total_income'] ?? 0, 0) ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card stat-card">
            <div class="stat-label">Utang Added</div>
            <div class="stat-value"><?= count($periodUtang) ?></div>
        </div>
    </div>
    <?php if (isAdmin()): ?>
    <div class="col-6 col-md-3">
        <div class="card stat-card">
            <div class="stat-label">Inventory Checks</div>
            <div class="stat-value"><?= count($inventoryChecks ?? []) ?></div>
        </div>
    </div>
    <?php endif; ?>
</div>

<div class="row g-3">
    <div class="col-12 col-lg-6">
        <div class="card p-3">
            <h5 class="mb-3 fw-bold">Cash Sales</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Qty</th>
                            <th>Total</th>
                            <th>Time</th>
                            <th>Cashier</th>
                            <?php if (isAdmin()): ?><th class="text-end">Actions</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($periodSales)): ?>
                            <tr><td colspan="<?= isAdmin() ? 6 : 5 ?>" class="text-center text-secondary py-4">No sales in this period.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($periodSales as $sale): ?>
                            <tr>
                                <td><?= sanitize($sale['product_name']) ?></td>
                                <td><?= intval($sale['qty']) ?></td>
                                <td>₱<?= number_format($sale['total'], 2) ?></td>
                                <td><?= date('H:i', strtotime($sale['date_created'])) ?></td>
                                <td><?= sanitize($sale['created_by'] ?? 'system') ?></td>
                                <?php if (isAdmin()): ?>
                                <td class="text-end">
                                    <button type="button" class="btn btn-sm btn-outline-primary"
                                        data-bs-toggle="modal" data-bs-target="#editSaleModal"
                                        data-sale-id="<?= intval($sale['id']) ?>"
                                        data-product-name="<?= sanitize($sale['product_name']) ?>"
                                        data-current-qty="<?= intval($sale['qty']) ?>"
                                        data-price="<?= floatval($sale['price']) ?>"
                                        data-notes="<?= sanitize($sale['notes'] ?? '') ?>">
                                        Edit
                                    </button>
                                    <form method="post" action="index.php?page=sales" class="d-inline-block" onsubmit="return confirm('Delete this sale? Stock will be restored.');">
                                        <input type="hidden" name="action" value="delete_sale">
                                        <input type="hidden" name="sale_id" value="<?= intval($sale['id']) ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-6">
        <div class="card p-3">
            <h5 class="mb-3 fw-bold">Utang</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Customer</th>
                            <th>Product</th>
                            <th>Total</th>
                            <th>Paid</th>
                            <th>Balance</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($periodUtang)): ?>
                            <tr><td colspan="6" class="text-center text-secondary py-4">No utang in this period.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($periodUtang as $utang):
                            $paidAmount = $utang['total'] - $utang['remaining_balance'];
                            $isPaid = $utang['status'] === 'Paid';
                            $isPartial = $paidAmount > 0 && $utang['remaining_balance'] > 0;
                        ?>
                            <tr class="<?= $isPaid ? 'table-success' : ($isPartial ? 'table-warning' : '') ?>">
                                <td><?= sanitize($utang['customer_name']) ?></td>
                                <td><?= sanitize($utang['product_name']) ?></td>
                                <td>₱<?= number_format($utang['total'], 2) ?></td>
                                <td>
                                    <?php if ($paidAmount > 0): ?>
                                        <span class="text-success">₱<?= number_format($paidAmount, 2) ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($utang['remaining_balance'] > 0): ?>
                                        <span class="fw-bold text-danger">₱<?= number_format($utang['remaining_balance'], 2) ?></span>
                                    <?php else: ?>
                                        <span class="text-success">Paid</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($isPaid): ?>
                                        <span class="badge bg-success">✓ Paid</span>
                                    <?php elseif ($isPartial): ?>
                                        <span class="badge bg-warning">Partial</span>
                                        <small class="d-block text-muted">₱<?= number_format($utang['remaining_balance'], 2) ?> left</small>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Unpaid</span>
                                    <?php endif; ?>
                                    <small class="d-block text-muted mt-1">by <?= sanitize($utang['created_by'] ?? 'system') ?></small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if (isAdmin()): ?>
<!-- Inventory Checks Section -->
<div class="row g-3 mt-2">
    <div class="col-12">
        <div class="card p-3">
            <h5 class="mb-3 fw-bold">Inventory Checks</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Expected</th>
                            <th>Actual</th>
                            <th>Missing</th>
                            <th>Checked By</th>
                            <th>Date</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($inventoryChecks)): ?>
                            <tr><td colspan="7" class="text-center text-secondary py-4">No inventory checks in this period.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($inventoryChecks as $check): ?>
                            <tr class="<?= $check['missing_qty'] > 0 ? 'table-warning' : '' ?>">
                                <td><?= sanitize($check['product_name']) ?></td>
                                <td><?= intval($check['expected_qty']) ?></td>
                                <td><?= intval($check['actual_qty']) ?></td>
                                <td>
                                    <?php if ($check['missing_qty'] > 0): ?>
                                        <span class="badge bg-danger"><?= intval($check['missing_qty']) ?></span>
                                    <?php elseif ($check['missing_qty'] < 0): ?>
                                        <span class="badge bg-info">+<?= abs(intval($check['missing_qty'])) ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-success">0</span>
                                    <?php endif; ?>
                                </td>
                                <td><?= sanitize($check['checked_by']) ?></td>
                                <td><?= date('M d H:i', strtotime($check['date_created'])) ?></td>
                                <td><small class="text-muted"><?= sanitize($check['notes'] ?? '-') ?></small></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (isAdmin()): ?>
<!-- Edit Sale Modal -->
<div class="modal fade" id="editSaleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <form method="post" action="index.php?page=sales">
                <input type="hidden" name="action" value="edit_sale">
                <input type="hidden" name="sale_id" id="editSaleId" value="">
                <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                    <h5 class="modal-title fw-bold">Edit Sale Price</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="padding: 1.25rem;">
                    <div class="mb-3">
                        <label class="form-label">Product</label>
                        <input type="text" id="editProductName" class="form-control" disabled style="background: var(--bg-color);">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Original Price</label>
                        <input type="text" id="editOriginalPrice" class="form-control" disabled style="background: var(--bg-color);">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Custom Price <span class="text-danger">*</span></label>
                        <input type="number" name="custom_price" id="editCustomPrice" class="form-control" min="0" step="0.01" required>
                        <small class="text-muted">Enter the selling price for this customer (e.g., original 200, sell for 150)</small>
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Note <span class="text-danger">*</span></label>
                        <textarea name="note" id="editNote" class="form-control" rows="2" placeholder="Reason for price change (e.g., special discount, damaged item, loyal customer)" required></textarea>
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                    <button type="button" class="btn btn-outline-primary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Edit Sale Modal Handler
    const editSaleModal = document.getElementById('editSaleModal');
    if (editSaleModal) {
        editSaleModal.addEventListener('show.bs.modal', event => {
            const button = event.relatedTarget;
            const saleId = button.getAttribute('data-sale-id');
            const productName = button.getAttribute('data-product-name');
            const currentQty = button.getAttribute('data-current-qty');
            const price = button.getAttribute('data-price');
            const notes = button.getAttribute('data-notes');

            document.getElementById('editSaleId').value = saleId;
            document.getElementById('editProductName').value = productName;
            document.getElementById('editOriginalPrice').value = '₱' + parseFloat(price).toFixed(2);
            document.getElementById('editCustomPrice').value = price;
        });
    }
</script>

<div class="row mt-3">
    <div class="col-12 text-end">
        <form method="post" class="d-inline-block mb-0">
            <input type="hidden" name="action" value="clear_sales">
            <button type="submit" class="btn btn-outline-secondary" onclick="return confirm('Clear all sales and utang history? This cannot be undone.')">Clear Sales</button>
        </form>
    </div>
</div>
<?php endif; ?>
