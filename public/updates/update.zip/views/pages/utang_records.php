<div class="page-header">
    <h2>Utang Records</h2>
    <p>Track outstanding customer balances, add payments, and view payment history.</p>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                <tr>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Remaining</th>
                    <th>Due</th>
                    <th>Status</th>
                    <th>Cashier</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($utangRecords)): ?>
                    <tr>
                        <td colspan="9" class="text-center text-secondary py-4">No utang records yet.</td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($utangRecords as $utang):
                    $isPaid = $utang['status'] === 'Paid';
                    $isPartial = $utang['status'] === 'Partial';
                    $remaining = floatval($utang['remaining_balance']);
                ?>
                    <tr>
                        <td><?= sanitize($utang['customer_name']) ?></td>
                        <td><?= sanitize($utang['product_name']) ?></td>
                        <td><?= intval($utang['qty']) ?></td>
                        <td>₱<?= number_format($utang['total'], 2) ?></td>
                        <td>
                            <?php if ($isPaid): ?>
                                <span class="text-success">₱0.00</span>
                            <?php else: ?>
                                <span class="fw-bold <?= $isPartial ? 'text-warning' : 'text-danger' ?>">₱<?= number_format($remaining, 2) ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?= sanitize($utang['due_date']) ?></td>
                        <td>
                            <?php if ($isPaid): ?>
                                <span class="badge bg-success">Paid</span>
                            <?php elseif ($isPartial): ?>
                                <span class="badge bg-info">Partial</span>
                            <?php else: ?>
                                <span class="badge bg-warning">Unpaid</span>
                            <?php endif; ?>
                        </td>
                        <td><?= sanitize($utang['created_by'] ?? 'system') ?></td>
                        <td class="text-end">
                            <a href="index.php?page=utang_records&view_payments=<?= intval($utang['id']) ?>" class="btn btn-sm btn-outline-info">View Payments</a>
                            <?php if (!$isPaid && isLoggedIn()): ?>
                                <button type="button" class="btn btn-sm btn-success"
                                    data-bs-toggle="modal" data-bs-target="#paymentModal"
                                    data-utang-id="<?= intval($utang['id']) ?>"
                                    data-customer-name="<?= sanitize($utang['customer_name']) ?>"
                                    data-remaining="<?= $remaining ?>">
                                    Add Payment
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
</div>

<!-- Payment History Modal -->
<?php if ($viewUtangId > 0 && $viewUtang): ?>
<div class="modal fade show" id="paymentHistoryModal" tabindex="-1" aria-modal="true" style="display: block;">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                <div>
                    <h5 class="modal-title fw-bold">Payment History</h5>
                    <p class="mb-0 text-muted"><?= sanitize($viewUtang['customer_name']) ?> - <?= sanitize($viewUtang['product_name']) ?></p>
                </div>
                <a href="index.php?page=utang_records" class="btn-close"></a>
            </div>
            <div class="modal-body" style="padding: 1.25rem;">
                <div class="row mb-3">
                    <div class="col-6">
                        <small class="text-muted">Original Amount</small>
                        <div class="h5">₱<?= number_format($viewUtang['total'], 2) ?></div>
                    </div>
                    <div class="col-6 text-end">
                        <small class="text-muted">Remaining Balance</small>
                        <div class="h5 <?= $viewUtang['status'] === 'Paid' ? 'text-success' : 'text-danger' ?>">₱<?= number_format($viewUtang['remaining_balance'], 2) ?></div>
                    </div>
                </div>

                <?php if (empty($paymentHistory)): ?>
                    <div class="text-center text-secondary py-4">No payments recorded yet.</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Amount Paid</th>
                                    <th>Remaining After</th>
                                    <th>Recorded By</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($paymentHistory as $payment): ?>
                                    <tr>
                                        <td><?= date('M d, Y H:i', strtotime($payment['date_created'])) ?></td>
                                        <td class="text-success">₱<?= number_format($payment['amount_paid'], 2) ?></td>
                                        <td>₱<?= number_format($payment['remaining_balance'], 2) ?></td>
                                        <td><?= sanitize($payment['paid_by'] ?? 'system') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
            <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                <a href="index.php?page=utang_records" class="btn btn-primary">Close</a>
            </div>
        </div>
    </div>
</div>
<div class="modal-backdrop fade show"></div>
<?php endif; ?>

<!-- Add Payment Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <form method="post">
                <input type="hidden" name="action" value="add_payment">
                <input type="hidden" name="utang_id" id="paymentUtangId" value="">
                <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                    <h5 class="modal-title fw-bold">Add Payment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" style="padding: 1.25rem;">
                    <div class="mb-3">
                        <label class="form-label">Customer</label>
                        <input type="text" id="paymentCustomerName" class="form-control" disabled style="background: var(--bg-color);">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Remaining Balance</label>
                        <input type="text" id="paymentRemaining" class="form-control" disabled style="background: var(--bg-color);">
                    </div>
                    <div class="mb-0">
                        <label class="form-label">Payment Amount</label>
                        <input type="number" name="payment_amount" id="paymentAmount" class="form-control" min="1" step="0.01" required>
                        <small class="text-muted">Enter amount received. If full balance is paid, utang will be marked as Paid.</small>
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                    <button type="button" class="btn btn-outline-primary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-success">Record Payment</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Payment Modal Handler
    const paymentModal = document.getElementById('paymentModal');
    paymentModal.addEventListener('show.bs.modal', event => {
        const button = event.relatedTarget;
        const utangId = button.getAttribute('data-utang-id');
        const customerName = button.getAttribute('data-customer-name');
        const remaining = button.getAttribute('data-remaining');

        document.getElementById('paymentUtangId').value = utangId;
        document.getElementById('paymentCustomerName').value = customerName;
        document.getElementById('paymentRemaining').value = '₱' + parseFloat(remaining).toLocaleString('en-PH', {minimumFractionDigits: 2, maximumFractionDigits: 2});
        document.getElementById('paymentAmount').max = remaining;
    });
</script>
