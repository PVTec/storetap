<?php
// views/pages/inventory_history.php - Admin inventory check management
?>
<div class="page-header d-flex justify-content-between align-items-center flex-wrap gap-2">
    <div>
        <h2>Inventory Check History</h2>
        <p>View and manage all inventory checks - who checked, when, and notes.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="index.php?page=inventory" class="btn btn-outline-primary">
            ← Back to Inventory
        </a>
    </div>
</div>

<!-- Summary Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card stat-card">
            <div class="stat-label">Total Checks</div>
            <div class="stat-value"><?= count($inventoryChecks) ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card stat-card">
            <div class="stat-label">Checked Today</div>
            <div class="stat-value"><?= count(array_filter($inventoryChecks, fn($c) => date('Y-m-d', strtotime($c['date_created'])) === $today)) ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card stat-card">
            <div class="stat-label">Discrepancies</div>
            <div class="stat-value"><?= count(array_filter($inventoryChecks, fn($c) => $c['missing_qty'] != 0)) ?></div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card stat-card">
            <div class="stat-label">Unique Checkers</div>
            <div class="stat-value"><?= count(array_unique(array_column($inventoryChecks, 'checked_by'))) ?></div>
        </div>
    </div>
</div>

<!-- Filter Section -->
<div class="card mb-4">
    <div class="card-body">
        <form method="get" class="row g-2 align-items-end">
            <input type="hidden" name="page" value="inventory_history">
            <div class="col-md-3">
                <label class="form-label">Filter by Product</label>
                <select name="product_id" class="form-select">
                    <option value="">All Products</option>
                    <?php foreach ($products as $product): ?>
                        <option value="<?= intval($product['id']) ?>" <?= ($filterProductId ?? '') == $product['id'] ? 'selected' : '' ?>>
                            <?= sanitize($product['product_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Filter by User</label>
                <select name="checked_by" class="form-select">
                    <option value="">All Users</option>
                    <?php foreach ($checkers as $checker): ?>
                        <option value="<?= sanitize($checker) ?>" <?= ($filterChecker ?? '') === $checker ? 'selected' : '' ?>>
                            <?= sanitize($checker) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">From</label>
                <input type="date" name="date_from" value="<?= sanitize($dateFrom ?? '') ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <label class="form-label">To</label>
                <input type="date" name="date_to" value="<?= sanitize($dateTo ?? '') ?>" class="form-control">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
        </form>
    </div>
</div>

<!-- Inventory Checks Table -->
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Product</th>
                        <th>Checked By</th>
                        <th>Expected</th>
                        <th>Actual</th>
                        <th>Diff</th>
                        <th>Notes</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($filteredChecks)): ?>
                        <tr>
                            <td colspan="8" class="text-center text-secondary py-4">
                                No inventory checks found for the selected filters.
                            </td>
                        </tr>
                    <?php endif; ?>
                    <?php foreach ($filteredChecks as $check): ?>
                        <?php
                        $isToday = date('Y-m-d', strtotime($check['date_created'])) === $today;
                        $hasDiscrepancy = $check['missing_qty'] != 0;
                        ?>
                        <tr class="<?= $hasDiscrepancy ? 'table-warning' : '' ?> <?= $isToday ? 'table-success' : '' ?>">
                            <td>
                                <?= date('M d, Y', strtotime($check['date_created'])) ?>
                                <small class="text-muted d-block"><?= date('H:i:s', strtotime($check['date_created'])) ?></small>
                                <?php if ($isToday): ?>
                                    <span class="badge bg-success" style="font-size: 0.6em;">TODAY</span>
                                <?php endif; ?>
                            </td>
                            <td><?= sanitize($check['product_name']) ?></td>
                            <td>
                                <span class="badge bg-info"><?= sanitize($check['checked_by']) ?></span>
                            </td>
                            <td><?= intval($check['expected_qty']) ?></td>
                            <td><?= intval($check['actual_qty']) ?></td>
                            <td>
                                <?php if ($check['missing_qty'] > 0): ?>
                                    <span class="badge bg-danger">-<?= intval($check['missing_qty']) ?></span>
                                <?php elseif ($check['missing_qty'] < 0): ?>
                                    <span class="badge bg-primary">+<?= abs(intval($check['missing_qty'])) ?></span>
                                <?php else: ?>
                                    <span class="badge bg-success">0</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($check['notes']): ?>
                                    <small class="text-muted" style="white-space: pre-line; max-width: 200px; display: block;">
                                        <?= nl2br(sanitize($check['notes'])) ?>
                                    </small>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-outline-primary"
                                    data-bs-toggle="modal" data-bs-target="#viewCheckModal"
                                    data-check-id="<?= intval($check['id']) ?>"
                                    data-product-name="<?= sanitize($check['product_name']) ?>"
                                    data-checked-by="<?= sanitize($check['checked_by']) ?>"
                                    data-date="<?= date('M d, Y H:i:s', strtotime($check['date_created'])) ?>"
                                    data-expected="<?= intval($check['expected_qty']) ?>"
                                    data-actual="<?= intval($check['actual_qty']) ?>"
                                    data-missing="<?= intval($check['missing_qty']) ?>"
                                    data-notes="<?= sanitize($check['notes'] ?? '') ?>">
                                    View
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- View Check Detail Modal -->
<div class="modal fade" id="viewCheckModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border: 1px solid var(--border); border-radius: 1rem;">
            <div class="modal-header" style="border-bottom: 1px solid var(--border); padding: 1.25rem;">
                <h5 class="modal-title fw-bold">Inventory Check Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" style="padding: 1.25rem;">
                <div class="mb-3">
                    <label class="form-label fw-bold">Product</label>
                    <div id="viewProductName" class="form-control" style="background: var(--bg-color);">-</div>
                </div>
                <div class="row mb-3">
                    <div class="col-6">
                        <label class="form-label fw-bold">Checked By</label>
                        <div id="viewCheckedBy" class="form-control" style="background: var(--bg-color);">-</div>
                    </div>
                    <div class="col-6">
                        <label class="form-label fw-bold">Date & Time</label>
                        <div id="viewDate" class="form-control" style="background: var(--bg-color);">-</div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-4">
                        <label class="form-label fw-bold">Expected</label>
                        <div id="viewExpected" class="form-control text-center" style="background: var(--bg-color);">-</div>
                    </div>
                    <div class="col-4">
                        <label class="form-label fw-bold">Actual</label>
                        <div id="viewActual" class="form-control text-center" style="background: var(--bg-color);">-</div>
                    </div>
                    <div class="col-4">
                        <label class="form-label fw-bold">Difference</label>
                        <div id="viewMissing" class="form-control text-center" style="background: var(--bg-color);">-</div>
                    </div>
                </div>
                <div class="mb-0">
                    <label class="form-label fw-bold">Notes</label>
                    <div id="viewNotes" class="form-control" style="background: var(--bg-color); min-height: 80px; white-space: pre-line;">-</div>
                </div>
            </div>
            <div class="modal-footer" style="border-top: 1px solid var(--border); padding: 1.25rem;">
                <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    // View Check Modal Handler
    const viewCheckModal = document.getElementById('viewCheckModal');
    viewCheckModal.addEventListener('show.bs.modal', event => {
        const button = event.relatedTarget;
        document.getElementById('viewProductName').textContent = button.getAttribute('data-product-name');
        document.getElementById('viewCheckedBy').textContent = button.getAttribute('data-checked-by');
        document.getElementById('viewDate').textContent = button.getAttribute('data-date');
        document.getElementById('viewExpected').textContent = button.getAttribute('data-expected');
        document.getElementById('viewActual').textContent = button.getAttribute('data-actual');

        const missing = parseInt(button.getAttribute('data-missing'));
        const missingEl = document.getElementById('viewMissing');
        if (missing > 0) {
            missingEl.textContent = '-' + missing;
            missingEl.style.color = 'var(--danger, #dc2626)';
        } else if (missing < 0) {
            missingEl.textContent = '+' + Math.abs(missing);
            missingEl.style.color = 'var(--primary, #0d6efd)';
        } else {
            missingEl.textContent = '0';
            missingEl.style.color = 'var(--success, #059669)';
        }

        const notes = button.getAttribute('data-notes');
        document.getElementById('viewNotes').textContent = notes || 'No notes provided.';
    });
</script>
