<?php
$user = currentUser();
require_once __DIR__ . '/../../controllers/LicenseController.php';
global $pdo;
$license = LicenseController::getCurrentLicense($pdo);
$hasOfflineDashboard = !empty($license['offline_dashboard']) && empty($license['is_expired']);

$navItems = [
    ['label' => 'Dashboard', 'href' => 'index.php?page=dashboard', 'key' => 'dashboard', 'roles' => ['admin', 'staff'], 'icon' => '📊'],
];
if ($hasOfflineDashboard) {
    $navItems[] = ['label' => 'Offline Mode', 'href' => 'index.php?page=offline_dashboard', 'key' => 'offline_dashboard', 'roles' => ['admin', 'staff'], 'icon' => '📶'];
}
$navItems = array_merge($navItems, [
    ['label' => 'Sales', 'href' => 'index.php?page=sales', 'key' => 'sales', 'roles' => ['admin', 'staff'], 'icon' => '💰'],
    ['label' => 'Products', 'href' => 'index.php?page=product_manage', 'key' => 'products', 'roles' => ['admin'], 'icon' => '📦'],
    ['label' => 'Utang', 'href' => 'index.php?page=utang_records', 'key' => 'utang', 'roles' => ['admin', 'staff'], 'icon' => '📝'],
    ['label' => 'Inventory', 'href' => 'index.php?page=inventory', 'key' => 'inventory', 'roles' => ['admin', 'staff'], 'icon' => '🏪'],
    ['label' => 'Reports', 'href' => 'index.php?page=sales_report', 'key' => 'reports', 'roles' => ['admin', 'staff'], 'icon' => '📈'],
    ['label' => 'Users', 'href' => 'index.php?page=manage_users', 'key' => 'users', 'roles' => ['admin'], 'icon' => '👤'],
    ['label' => 'Settings', 'href' => 'index.php?page=settings', 'key' => 'settings', 'roles' => ['admin', 'staff'], 'icon' => '⚙️', 'beta' => true],
    ['label' => 'License', 'href' => 'index.php?page=license', 'key' => 'license', 'roles' => ['admin'], 'icon' => '🔑'],
    ['label' => 'Tutorial Guide', 'href' => '#', 'onclick' => 'startTutorial()', 'key' => 'tutorial', 'roles' => ['admin', 'staff'], 'icon' => '💡'],
]);
$currentPage = $_GET['page'] ?? 'dashboard';
?>
<!-- Mobile Sidebar Header -->
<div class="sidebar-header">
    <span class="navbar-brand d-flex align-items-center gap-2">
        StoreTap
        <?php if (!empty($license['license_type']) && empty($license['is_expired'])): 
            if ($license['license_type'] === 'dev'): ?>
            <span class="badge rounded-pill text-white" style="background: linear-gradient(135deg, #00f2fe 0%, #4facfe 50%, #00f2fe 100%); font-size: 0.55em; letter-spacing: 2px; padding: 0.4em 0.8em; font-weight: 900; box-shadow: 0 0 10px rgba(0, 242, 254, 0.8), 0 0 20px rgba(79, 172, 254, 0.5); border: 1px solid rgba(255,255,255,0.4); text-shadow: 0 1px 2px rgba(0,0,0,0.5);">TEST</span>
        <?php elseif ($license['license_type'] === 'pro'): ?>
            <span class="badge rounded-pill text-white" style="background: linear-gradient(135deg, #fdd034 0%, #f37335 33%, #d52d8b 66%, #8a2387 100%); font-size: 0.5em; letter-spacing: 1px; padding: 0.35em 0.65em; font-weight: 700; box-shadow: 0 2px 4px rgba(213, 45, 139, 0.3); border: 1px solid rgba(255,255,255,0.2);">PRO</span>
        <?php elseif (in_array($license['license_type'], ['free', 'basic'])): ?>
            <span class="badge rounded-pill bg-secondary text-white" style="font-size: 0.5em; letter-spacing: 1px; padding: 0.35em 0.65em; font-weight: 700;">BASIC</span>
        <?php endif; ?>
            <span class="license-countdown badge rounded-pill bg-danger shadow-sm text-white" style="display: none; font-size: 0.5em; letter-spacing: 1px; padding: 0.35em 0.65em; font-weight: 700; border: 1px solid rgba(255,255,255,0.2);"></span>
        <?php endif; ?>
    </span>
    <button class="sidebar-close" onclick="closeSidebar()" aria-label="Close">&times;</button>
</div>

<ul class="navbar-nav me-auto">
    <?php foreach ($navItems as $item): ?>
        <?php if (in_array($user['role'], $item['roles'], true)): ?>
            <li class="nav-item">
                <a href="<?= $item['href'] ?><?= strpos($item['href'], 'index.php') !== false ? '&v='.time() : '' ?>" 
                   <?= isset($item['onclick']) ? 'onclick="' . $item['onclick'] . '; return false;"' : '' ?>
                   class="nav-link <?= $currentPage === $item['key'] ? 'active' : '' ?>">
                    <span class="nav-icon"><?= $item['icon'] ?></span>
                    <span class="nav-label"><?= sanitize($item['label']) ?></span>
                    <?php if (isset($item['beta']) && $item['beta']): ?>
                        <span class="badge bg-warning ms-1" style="font-size: 0.6em;">BETA</span>
                    <?php endif; ?>
                </a>
            </li>
        <?php endif; ?>
    <?php endforeach; ?>
</ul>

<div class="desktop-user-info d-flex align-items-center gap-3">
    <span class="text-secondary small"><?= sanitize($user['username']) ?></span>
    <a class="btn btn-sm btn-outline-primary" href="index.php?page=logout&v=<?= time() ?>">Logout</a>
</div>
