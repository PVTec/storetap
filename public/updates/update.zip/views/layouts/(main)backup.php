<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="theme-color" content="#0d6efd">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="StoreTap">
    <!-- Anti-cache meta tags for free hosting -->
    <meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="Mon, 26 Jul 1997 05:00:00 GMT">
    <link rel="manifest" href="/manifest.json?v=<?= APP_VERSION ?>">
    <link rel="apple-touch-icon" href="/assets/icon.svg?v=<?= APP_VERSION ?>">
    <link rel="icon" href="/assets/icon.svg" type="image/svg+xml">
    <title><?= sanitize($title ?? 'StoreTap') ?> - StoreTap</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/driver.js@1.0.1/dist/driver.css"/>
    <style>
        :root {
            --bg-color: #fafafa;
            --card-bg: #ffffff;
            --text-primary: #1a1a1a;
            --text-secondary: #6b7280;
            --accent: #111827;
            --accent-light: #374151;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --border: #e5e7eb;
        }
        
        * { -webkit-tap-highlight-color: transparent; }
        
        body {
            background: var(--bg-color);
            color: var(--text-primary);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.5;
            padding-bottom: 80px;
        }
        
        /* Navbar - Minimal */
        .navbar {
            background: var(--card-bg) !important;
            border-bottom: 1px solid var(--border);
            padding: 0.75rem 0;
        }
        
        .navbar-brand {
            color: var(--text-primary) !important;
            font-weight: 700;
            font-size: 1.25rem;
            letter-spacing: -0.02em;
        }
        
        .navbar-toggler {
            border: none;
            padding: 0.5rem;
        }
        
        .navbar-toggler:focus { box-shadow: none; }
        
        .nav-link {
            color: var(--text-secondary) !important;
            font-weight: 500;
            padding: 0.75rem 1rem !important;
            border-radius: 0.5rem;
            margin: 0.125rem 0;
            transition: all 0.15s ease;
        }
        
        .nav-link:hover {
            color: var(--text-primary) !important;
            background: var(--bg-color);
        }
        
        .nav-link.active {
            color: var(--accent) !important;
            background: var(--bg-color);
        }
        
        /* Mobile Sidebar Nav */
        @media (max-width: 991px) {
            body { padding-bottom: 0; }
            
            .navbar-collapse {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                width: 280px;
                background: var(--card-bg);
                border-right: 1px solid var(--border);
                padding: 1rem;
                z-index: 1050;
                box-shadow: 4px 0 20px rgba(0,0,0,0.1);
                transform: translateX(-100%);
                transition: transform 0.3s ease;
                display: block !important;
                height: 100vh;
                overflow-y: auto;
            }
            
            .navbar-collapse.show {
                transform: translateX(0);
            }
            
            .navbar-nav {
                flex-direction: column !important;
                padding-top: 1rem;
            }
            
            .nav-item {
                width: 100%;
            }
            
            .nav-link {
                display: flex;
                align-items: center;
                gap: 0.75rem;
                padding: 0.875rem 1rem !important;
                font-size: 1rem;
                font-weight: 500;
                border-radius: 0.5rem;
                margin-bottom: 0.25rem;
            }
            
            .nav-link .nav-icon { 
                font-size: 1.25rem; 
                line-height: 1;
                width: 1.5rem;
                text-align: center;
            }
            
            .desktop-user-info { 
                display: flex !important; 
                flex-direction: column;
                padding: 1rem;
                border-top: 1px solid var(--border);
                margin-top: 1rem;
            }
            
            /* Overlay backdrop */
            .sidebar-backdrop {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0,0,0,0.5);
                z-index: 1040;
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
            }
            
            .sidebar-backdrop.show {
                opacity: 1;
                visibility: visible;
            }
            
            .navbar-toggler {
                display: block !important;
                z-index: 1060 !important;
                position: relative;
            }
            
            .navbar-toggler-icon {
                pointer-events: none;
            }
            
            .sidebar-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding-bottom: 1rem;
                border-bottom: 1px solid var(--border);
            }
            
            .sidebar-close {
                background: none;
                border: none;
                font-size: 1.5rem;
                padding: 0.25rem;
                cursor: pointer;
                z-index: 1060;
            }
            
            /* Ensure navbar brand doesn't overlap with toggler */
            .navbar-brand {
                max-width: calc(100% - 60px);
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
            }
        }
        
        @media (min-width: 992px) {
            .nav-link .nav-icon { display: none; }
            .desktop-user-info { display: flex !important; align-items: center; }
            .navbar-collapse { display: flex !important; justify-content: space-between; width: 100%; }
            .navbar-toggler { display: none; }
            .sidebar-backdrop { display: none; }
            .sidebar-header { display: none; }
            .sidebar-close { display: none; }
            
            /* Nav items adjustment to feel spacious and clean */
            .nav-link {
                padding: 0.4rem 0.55rem !important;
                font-size: 0.85rem;
                white-space: nowrap;
                margin: 0;
            }
            
            /* Center the nav links */
            .navbar-nav {
                margin: 0 auto !important;
                gap: 0.15rem;
            }
            
            /* Desktop User Info Formatting */
            .desktop-user-info .text-secondary {
                font-weight: 600;
                margin-right: 15px;
            }
            .desktop-user-info .btn-outline-primary {
                padding: 0.25rem 0.8rem;
                font-size: 0.85rem;
            }

            /* Fix User Info visibility on Colored Gradient Themes (Exclude default and dark) */
            body[class*="theme-"]:not(.theme-dark):not(.theme-default) .desktop-user-info .text-secondary {
                color: rgba(255,255,255,0.9) !important;
            }
            body[class*="theme-"]:not(.theme-dark):not(.theme-default) .desktop-user-info .btn-outline-primary {
                border-color: rgba(255,255,255,0.6) !important;
                color: white !important;
                background: transparent !important;
            }
            body[class*="theme-"]:not(.theme-dark):not(.theme-default) .desktop-user-info .btn-outline-primary:hover {
                background: rgba(255,255,255,0.2) !important;
                border-color: white !important;
            }
        }
        
        /* Cards - Minimal */
        .card {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: 0.75rem;
            box-shadow: none;
            transition: transform 0.15s ease, box-shadow 0.15s ease;
        }
        
        .card:active { transform: scale(0.98); }
        
        @media (min-width: 992px) {
            .card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        }
        
        /* Stats Cards */
        .stat-card { padding: 1.25rem; }
        .stat-card .stat-value {
            font-size: 1.875rem;
            font-weight: 700;
            color: var(--text-primary);
            letter-spacing: -0.02em;
        }
        .stat-card .stat-label {
            font-size: 0.875rem;
            color: var(--text-secondary);
            font-weight: 500;
        }
        
        /* Buttons - Minimal */
        .btn {
            font-weight: 500;
            border-radius: 0.5rem;
            padding: 0.625rem 1rem;
            border: none;
            transition: all 0.15s ease;
            min-height: 44px;
        }
        
        .btn:active { transform: scale(0.97); }
        
        .btn-primary {
            background: var(--accent);
            color: white;
        }
        .btn-primary:hover { background: var(--accent-light); }
        
        .btn-success {
            background: var(--success);
            color: white;
        }
        
        .btn-outline-primary {
            border: 1px solid var(--border);
            background: transparent;
            color: var(--text-primary);
        }
        .btn-outline-primary:hover {
            background: var(--bg-color);
            border-color: var(--text-secondary);
        }
        
        .btn-outline-danger {
            border: 1px solid var(--border);
            background: transparent;
            color: var(--danger);
        }
        
        /* Product Cards */
        .product-card { padding: 1rem; }
        .product-card .product-image-wrapper {
            width: 100%;
            height: 150px;
            overflow: hidden;
            border-radius: 0.75rem;
            background: #f4f5f7;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .product-card .product-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .product-card .product-image.placeholder {
            color: var(--text-secondary);
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            font-weight: 600;
            padding: 0 0.75rem;
            text-align: center;
        }
        .product-card .card-title {
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        .product-card .price {
            font-size: 1.125rem;
            font-weight: 700;
            color: var(--text-primary);
        }
        .product-card .stock {
            font-size: 0.875rem;
            color: var(--text-secondary);
        }
        
        /* Action Buttons */
        .action-btn {
            width: 100%;
            padding: 0.75rem;
            font-size: 0.875rem;
            font-weight: 600;
            white-space: nowrap;
        }
        
        /* Tables */
        .table {
            font-size: 0.875rem;
            margin-bottom: 0;
        }
        
        .table thead th {
            font-weight: 600;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--border);
            padding: 0.75rem;
            background: transparent;
        }
        
        .table td {
            padding: 1rem 0.75rem;
            border-bottom: 1px solid var(--border);
            vertical-align: middle;
        }
        
        .table tbody tr:last-child td { border-bottom: none; }
        
        /* Badges */
        .badge {
            font-weight: 500;
            padding: 0.375rem 0.625rem;
            border-radius: 0.375rem;
        }
        
        .bg-success { background: rgba(16, 185, 129, 0.1) !important; color: var(--success) !important; }
        .bg-warning { background: rgba(245, 158, 11, 0.1) !important; color: var(--warning) !important; }
        .bg-danger { background: rgba(239, 68, 68, 0.1) !important; color: var(--danger) !important; }
        .bg-primary { background: rgba(17, 24, 39, 0.1) !important; color: var(--accent) !important; }
        .bg-secondary { background: rgba(107, 114, 128, 0.1) !important; color: var(--text-secondary) !important; }
        
        /* Forms */
        .form-control, .form-select {
            border: 1px solid var(--border);
            border-radius: 0.5rem;
            padding: 0.625rem 0.875rem;
            font-size: 1rem;
            min-height: 44px;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(17, 24, 39, 0.05);
        }
        
        .form-label {
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--text-secondary);
            margin-bottom: 0.375rem;
        }
        
        /* Alerts */
        .alert {
            border: none;
            border-radius: 0.75rem;
            padding: 1rem 1.25rem;
        }
        
        .alert-success { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .alert-danger { background: rgba(239, 68, 68, 0.1); color: var(--danger); }
        
        /* Page Header */
        .page-header {
            margin-bottom: 1.5rem;
        }
        
        .page-header h1, .page-header h2 {
            font-size: 1.5rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            margin-bottom: 0.25rem;
        }
        
        .page-header p {
            color: var(--text-secondary);
            margin-bottom: 0;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .stat-card { margin-bottom: 0.75rem; }
            .product-grid { grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 0.75rem; }
        }

        /* Mobile Optimizations */
        @media (max-width: 576px) {
            .container { padding: 0 1rem; }
            .stat-card .stat-value { font-size: 1.5rem; }
            .page-header h1, .page-header h2 { font-size: 1.25rem; }
            .btn { padding: 0.75rem 1rem; }
            .table { font-size: 0.8125rem; }
            .table td, .table th { padding: 0.75rem 0.5rem; }
        }
        
        /* Desktop */
        @media (min-width: 992px) {
            .card { border-radius: 1rem; }
        }

        /* ============================================
           THEME SYSTEM - PREMIUM STORE THEMES
           ============================================ */

        /* Theme: Premium Pink */
        body.theme-pink {
            --bg-color: #fdf2f8;
            --card-bg: #ffffff;
            --text-primary: #831843;
            --text-secondary: #a8557c;
            --accent: #be185d;
            --accent-light: #db2777;
            --success: #059669;
            --warning: #d97706;
            --danger: #dc2626;
            --border: #fbcfe8;
        }
        body.theme-pink .navbar { background: linear-gradient(135deg, #be185d 0%, #db2777 100%) !important; }
        body.theme-pink .navbar-brand,
        body.theme-pink .nav-link { color: white !important; }
        body.theme-pink .nav-link:hover,
        body.theme-pink .nav-link.active { background: rgba(255, 255, 255, 0.15) !important; color: white !important; }
        body.theme-pink .navbar-toggler-icon { filter: invert(1); }
        @media (max-width: 991px) {
            body.theme-pink .navbar-collapse { background: #ffffff !important; }
            body.theme-pink .navbar-collapse .nav-link { color: var(--text-primary) !important; background: transparent !important; }
            body.theme-pink .navbar-collapse .nav-link:hover { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-pink .navbar-collapse .nav-link.active { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-pink .sidebar-header { background: #ffffff !important; border-bottom-color: var(--border); }
            body.theme-pink .sidebar-header .navbar-brand { color: var(--accent) !important; }
            body.theme-pink .sidebar-close { color: var(--text-secondary) !important; }
            body.theme-pink .sidebar-close:hover { color: var(--accent) !important; }
        }

        /* Theme: Ocean Blue */
        body.theme-ocean {
            --bg-color: #eff6ff;
            --card-bg: #ffffff;
            --text-primary: #1e3a8a;
            --text-secondary: #5c7aea;
            --accent: #1e40af;
            --accent-light: #3b82f6;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --border: #bfdbfe;
        }
        body.theme-ocean .navbar { background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%) !important; }
        body.theme-ocean .navbar-brand,
        body.theme-ocean .nav-link { color: white !important; }
        body.theme-ocean .nav-link:hover,
        body.theme-ocean .nav-link.active { background: rgba(255, 255, 255, 0.15) !important; color: white !important; }
        body.theme-ocean .navbar-toggler-icon { filter: invert(1); }
        @media (max-width: 991px) {
            body.theme-ocean .navbar-collapse { background: #ffffff !important; }
            body.theme-ocean .navbar-collapse .nav-link { color: var(--text-primary) !important; background: transparent !important; }
            body.theme-ocean .navbar-collapse .nav-link:hover { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-ocean .navbar-collapse .nav-link.active { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-ocean .sidebar-header { background: #ffffff !important; border-bottom-color: var(--border); }
            body.theme-ocean .sidebar-header .navbar-brand { color: var(--accent) !important; }
            body.theme-ocean .sidebar-close { color: var(--text-secondary) !important; }
            body.theme-ocean .sidebar-close:hover { color: var(--accent) !important; }
        }

        /* Theme: Forest Green */
        body.theme-forest {
            --bg-color: #f0fdf4;
            --card-bg: #ffffff;
            --text-primary: #14532d;
            --text-secondary: #4a9c5d;
            --accent: #166534;
            --accent-light: #22c55e;
            --success: #16a34a;
            --warning: #ca8a04;
            --danger: #dc2626;
            --border: #bbf7d0;
        }
        body.theme-forest .navbar { background: linear-gradient(135deg, #166534 0%, #22c55e 100%) !important; }
        body.theme-forest .navbar-brand,
        body.theme-forest .nav-link { color: white !important; }
        body.theme-forest .nav-link:hover,
        body.theme-forest .nav-link.active { background: rgba(255, 255, 255, 0.15) !important; color: white !important; }
        body.theme-forest .navbar-toggler-icon { filter: invert(1); }
        @media (max-width: 991px) {
            body.theme-forest .navbar-collapse { background: #ffffff !important; }
            body.theme-forest .navbar-collapse .nav-link { color: var(--text-primary) !important; background: transparent !important; }
            body.theme-forest .navbar-collapse .nav-link:hover { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-forest .navbar-collapse .nav-link.active { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-forest .sidebar-header { background: #ffffff !important; border-bottom-color: var(--border); }
            body.theme-forest .sidebar-header .navbar-brand { color: var(--accent) !important; }
            body.theme-forest .sidebar-close { color: var(--text-secondary) !important; }
            body.theme-forest .sidebar-close:hover { color: var(--accent) !important; }
        }

        /* Theme: Sunset Orange */
        body.theme-sunset {
            --bg-color: #fff7ed;
            --card-bg: #ffffff;
            --text-primary: #9a3412;
            --text-secondary: #c2785a;
            --accent: #c2410c;
            --accent-light: #f97316;
            --success: #16a34a;
            --warning: #ea580c;
            --danger: #dc2626;
            --border: #fed7aa;
        }
        body.theme-sunset .navbar { background: linear-gradient(135deg, #c2410c 0%, #f97316 100%) !important; }
        body.theme-sunset .navbar-brand,
        body.theme-sunset .nav-link { color: white !important; }
        body.theme-sunset .nav-link:hover,
        body.theme-sunset .nav-link.active { background: rgba(255, 255, 255, 0.15) !important; color: white !important; }
        body.theme-sunset .navbar-toggler-icon { filter: invert(1); }
        @media (max-width: 991px) {
            body.theme-sunset .navbar-collapse { background: #ffffff !important; }
            body.theme-sunset .navbar-collapse .nav-link { color: var(--text-primary) !important; background: transparent !important; }
            body.theme-sunset .navbar-collapse .nav-link:hover { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-sunset .navbar-collapse .nav-link.active { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-sunset .sidebar-header { background: #ffffff !important; border-bottom-color: var(--border); }
            body.theme-sunset .sidebar-header .navbar-brand { color: var(--accent) !important; }
            body.theme-sunset .sidebar-close { color: var(--text-secondary) !important; }
            body.theme-sunset .sidebar-close:hover { color: var(--accent) !important; }
        }

        /* Theme: Royal Purple */
        body.theme-royal {
            --bg-color: #f5f3ff;
            --card-bg: #ffffff;
            --text-primary: #5b21b6;
            --text-secondary: #7c6dc7;
            --accent: #7c3aed;
            --accent-light: #8b5cf6;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --border: #ddd6fe;
        }
        body.theme-royal .navbar { background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%) !important; }
        body.theme-royal .navbar-brand,
        body.theme-royal .nav-link { color: white !important; }
        body.theme-royal .nav-link:hover,
        body.theme-royal .nav-link.active { background: rgba(255, 255, 255, 0.15) !important; color: white !important; }
        body.theme-royal .navbar-toggler-icon { filter: invert(1); }
        @media (max-width: 991px) {
            body.theme-royal .navbar-collapse { background: #ffffff !important; }
            body.theme-royal .navbar-collapse .nav-link { color: var(--text-primary) !important; background: transparent !important; }
            body.theme-royal .navbar-collapse .nav-link:hover { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-royal .navbar-collapse .nav-link.active { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-royal .sidebar-header { background: #ffffff !important; border-bottom-color: var(--border); }
            body.theme-royal .sidebar-header .navbar-brand { color: var(--accent) !important; }
            body.theme-royal .sidebar-close { color: var(--text-secondary) !important; }
            body.theme-royal .sidebar-close:hover { color: var(--accent) !important; }
        }

        /* Theme: Midnight Dark - Softer, more comfortable colors */
        body.theme-dark {
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --text-primary: #e2e8f0;
            --text-secondary: #94a3b8;
            --accent: #60a5fa;
            --accent-light: #93c5fd;
            --success: #34d399;
            --warning: #fbbf24;
            --danger: #f87171;
            --border: #334155;
        }
        body.theme-dark .navbar { background: #1f2937 !important; border-bottom-color: #374151; }
        body.theme-dark .navbar-brand { color: white !important; }
        body.theme-dark .nav-link { color: #9ca3af !important; }
        body.theme-dark .nav-link:hover,
        body.theme-dark .nav-link.active { color: white !important; background: #374151; }
        /* Dark theme sidebar */
        @media (max-width: 991px) {
            body.theme-dark .navbar-collapse { background: #1f2937 !important; border-right-color: #374151; }
            body.theme-dark .sidebar-header { background: #1f2937 !important; border-bottom-color: #374151; }
            body.theme-dark .sidebar-header .navbar-brand { color: white !important; }
            body.theme-dark .sidebar-close { color: #9ca3af !important; }
            body.theme-dark .sidebar-close:hover { color: white !important; }
        }
        body.theme-dark .desktop-user-info { border-top-color: #374151 !important; }
        body.theme-dark .desktop-user-info .text-secondary { color: #9ca3af !important; }
        body.theme-dark .navbar-toggler-icon { filter: invert(1); }

        /* ============================================
           MIDNIGHT DARK THEME COMPREHENSIVE POLISH
           ============================================ */
        /* Cards */
        body.theme-dark .card {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .card-header {
            background-color: #111827 !important;
            border-bottom-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .card-body {
            color: #f9fafb !important;
        }
        body.theme-dark .card-footer {
            background-color: #111827 !important;
            border-top-color: #374151 !important;
        }

        /* Buttons - all variants */
        body.theme-dark .btn-primary {
            background-color: #3b82f6 !important;
            border-color: #3b82f6 !important;
            color: white !important;
        }
        body.theme-dark .btn-primary:hover {
            background-color: #2563eb !important;
            border-color: #2563eb !important;
        }
        body.theme-dark .btn-secondary {
            background-color: #4b5563 !important;
            border-color: #4b5563 !important;
            color: white !important;
        }
        body.theme-dark .btn-success {
            background-color: #059669 !important;
            border-color: #059669 !important;
            color: white !important;
        }
        body.theme-dark .btn-danger {
            background-color: #dc2626 !important;
            border-color: #dc2626 !important;
            color: white !important;
        }
        body.theme-dark .btn-warning {
            background-color: #d97706 !important;
            border-color: #d97706 !important;
            color: white !important;
        }
        body.theme-dark .btn-info {
            background-color: #0891b2 !important;
            border-color: #0891b2 !important;
            color: white !important;
        }
        body.theme-dark .btn-outline-primary {
            border-color: #3b82f6 !important;
            color: #3b82f6 !important;
        }
        body.theme-dark .btn-outline-primary:hover {
            background-color: #3b82f6 !important;
            color: white !important;
        }
        body.theme-dark .btn-outline-secondary {
            border-color: #9ca3af !important;
            color: #9ca3af !important;
        }
        body.theme-dark .btn-outline-secondary:hover {
            background-color: #4b5563 !important;
            color: white !important;
        }
        body.theme-dark .btn-outline-success {
            border-color: #10b981 !important;
            color: #10b981 !important;
        }
        body.theme-dark .btn-outline-success:hover {
            background-color: #10b981 !important;
            color: white !important;
        }
        body.theme-dark .btn-outline-danger {
            border-color: #ef4444 !important;
            color: #ef4444 !important;
        }
        body.theme-dark .btn-outline-danger:hover {
            background-color: #ef4444 !important;
            color: white !important;
        }
        body.theme-dark .btn:disabled {
            opacity: 0.5 !important;
            cursor: not-allowed !important;
        }

        /* Forms */
        body.theme-dark .form-control {
            background-color: #111827 !important;
            border-color: #4b5563 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .form-control:focus {
            background-color: #111827 !important;
            border-color: #3b82f6 !important;
            color: #f9fafb !important;
            box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.25) !important;
        }
        body.theme-dark .form-control:disabled,
        body.theme-dark .form-control[readonly] {
            background-color: #374151 !important;
            color: #9ca3af !important;
        }
        body.theme-dark .form-label {
            color: #f9fafb !important;
        }
        body.theme-dark .form-select {
            background-color: #111827 !important;
            border-color: #4b5563 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .form-select:focus {
            border-color: #3b82f6 !important;
            box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.25) !important;
        }
        body.theme-dark .form-check-input {
            background-color: #374151 !important;
            border-color: #4b5563 !important;
        }
        body.theme-dark .form-check-input:checked {
            background-color: #3b82f6 !important;
            border-color: #3b82f6 !important;
        }
        body.theme-dark .form-text {
            color: #9ca3af !important;
        }
        body.theme-dark textarea.form-control::placeholder,
        body.theme-dark input.form-control::placeholder {
            color: #6b7280 !important;
        }

        /* Tables - SOFT COMFORTABLE DARK MODE */
        body.theme-dark .table {
            color: #cbd5e1 !important;
            --bs-table-color: #cbd5e1 !important;
            --bs-table-bg: #1e293b !important;
            border-color: #334155 !important;
        }
        body.theme-dark .table thead th {
            background-color: #0f172a !important;
            color: #64748b !important;
            border-bottom: 2px solid #334155 !important;
            border-top: none !important;
            font-weight: 600 !important;
            text-transform: uppercase !important;
            font-size: 0.75rem !important;
            letter-spacing: 0.5px !important;
            padding: 1rem 0.75rem !important;
        }
        body.theme-dark .table tbody td {
            background-color: #1e293b !important;
            color: #cbd5e1 !important;
            border-color: #334155 !important;
            padding: 0.875rem 0.75rem !important;
            vertical-align: middle !important;
        }
        body.theme-dark .table tbody tr {
            color: #cbd5e1 !important;
            background-color: #1e293b !important;
        }
        body.theme-dark .table tbody tr:hover {
            background-color: #334155 !important;
            color: #f1f5f9 !important;
        }
        body.theme-dark .table tbody tr:hover td {
            background-color: #334155 !important;
            color: #f1f5f9 !important;
        }
        body.theme-dark .table-striped > tbody > tr:nth-of-type(odd) > * {
            background-color: #252f47 !important;
            color: #cbd5e1 !important;
        }
        body.theme-dark .table-striped > tbody > tr:nth-of-type(odd) > td {
            background-color: #252f47 !important;
            color: #cbd5e1 !important;
        }
        body.theme-dark .table-hover > tbody > tr:hover > * {
            background-color: #334155 !important;
            color: #f1f5f9 !important;
        }

        /* Table Row States - Softer colors */
        body.theme-dark .table-success {
            --bs-table-bg: rgba(52, 211, 153, 0.1) !important;
            --bs-table-color: #6ee7b7 !important;
        }
        body.theme-dark .table-success td {
            background-color: rgba(52, 211, 153, 0.1) !important;
            color: #6ee7b7 !important;
        }
        body.theme-dark .table-warning {
            --bs-table-bg: rgba(251, 191, 36, 0.1) !important;
            --bs-table-color: #fcd34d !important;
        }
        body.theme-dark .table-warning td {
            background-color: rgba(251, 191, 36, 0.1) !important;
            color: #fcd34d !important;
        }
        body.theme-dark .table-danger {
            --bs-table-bg: rgba(248, 113, 113, 0.1) !important;
            --bs-table-color: #fca5a5 !important;
        }
        body.theme-dark .table-danger td {
            background-color: rgba(248, 113, 113, 0.1) !important;
            color: #fca5a5 !important;
        }
        body.theme-dark .table-info {
            --bs-table-bg: rgba(56, 189, 248, 0.1) !important;
            --bs-table-color: #7dd3fc !important;
        }
        body.theme-dark .table-info td {
            background-color: rgba(56, 189, 248, 0.1) !important;
            color: #7dd3fc !important;
        }

        /* Table inside cards */
        body.theme-dark .card .table {
            margin-bottom: 0 !important;
        }
        body.theme-dark .card .table thead th:first-child {
            border-top-left-radius: 0.5rem !important;
        }
        body.theme-dark .card .table thead th:last-child {
            border-top-right-radius: 0.5rem !important;
        }

        /* List Groups */
        body.theme-dark .list-group-item {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .list-group-item:hover {
            background-color: #374151 !important;
        }
        body.theme-dark .list-group-item.active {
            background-color: #3b82f6 !important;
            border-color: #3b82f6 !important;
            color: white !important;
        }

        /* Modals */
        body.theme-dark .modal-content {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .modal-header {
            background-color: #111827 !important;
            border-bottom-color: #374151 !important;
        }
        body.theme-dark .modal-header .modal-title {
            color: #f9fafb !important;
        }
        body.theme-dark .modal-body {
            color: #f9fafb !important;
        }
        body.theme-dark .modal-footer {
            background-color: #111827 !important;
            border-top-color: #374151 !important;
        }
        body.theme-dark .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%) !important;
        }

        /* Text colors - ensure visibility in modals */
        body.theme-dark .modal-body .text-muted,
        body.theme-dark .modal-body .text-secondary {
            color: #94a3b8 !important;
        }
        body.theme-dark .modal-body .text-dark {
            color: #e2e8f0 !important;
        }
        body.theme-dark .modal-body h5,
        body.theme-dark .modal-body .h5 {
            color: #f1f5f9 !important;
        }
        body.theme-dark .modal-body .table {
            color: #e2e8f0 !important;
        }
        body.theme-dark .modal-body .table thead th {
            background-color: #0f172a !important;
            color: #94a3b8 !important;
            border-color: #334155 !important;
        }
        body.theme-dark .modal-body .table tbody td {
            color: #e2e8f0 !important;
            border-color: #334155 !important;
        }

        /* Alerts */
        body.theme-dark .alert-primary {
            background-color: rgba(59, 130, 246, 0.2) !important;
            border-color: #3b82f6 !important;
            color: #93c5fd !important;
        }
        body.theme-dark .alert-success {
            background-color: rgba(16, 185, 129, 0.2) !important;
            border-color: #10b981 !important;
            color: #6ee7b7 !important;
        }
        body.theme-dark .alert-danger {
            background-color: rgba(239, 68, 68, 0.2) !important;
            border-color: #ef4444 !important;
            color: #fca5a5 !important;
        }
        body.theme-dark .alert-warning {
            background-color: rgba(245, 158, 11, 0.2) !important;
            border-color: #f59e0b !important;
            color: #fcd34d !important;
        }
        body.theme-dark .alert-info {
            background-color: rgba(14, 165, 233, 0.2) !important;
            border-color: #0ea5e9 !important;
            color: #7dd3fc !important;
        }

        /* Badges - ensure visibility */
        body.theme-dark .badge.bg-primary {
            background-color: #3b82f6 !important;
            color: white !important;
        }
        body.theme-dark .badge.bg-secondary {
            background-color: #6b7280 !important;
            color: white !important;
        }
        body.theme-dark .badge.bg-success {
            background-color: #10b981 !important;
            color: white !important;
        }
        body.theme-dark .badge.bg-danger {
            background-color: #ef4444 !important;
            color: white !important;
        }
        body.theme-dark .badge.bg-warning {
            background-color: #f59e0b !important;
            color: #1f2937 !important;
        }
        body.theme-dark .badge.bg-info {
            background-color: #0ea5e9 !important;
            color: white !important;
        }
        body.theme-dark .badge.bg-light {
            background-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .badge.bg-dark {
            background-color: #111827 !important;
            color: #f9fafb !important;
        }

        /* Text colors */
        body.theme-dark .text-primary { color: #60a5fa !important; }
        body.theme-dark .text-secondary { color: #9ca3af !important; }
        body.theme-dark .text-success { color: #34d399 !important; }
        body.theme-dark .text-danger { color: #f87171 !important; }
        body.theme-dark .text-warning { color: #fbbf24 !important; }
        body.theme-dark .text-info { color: #38bdf8 !important; }
        body.theme-dark .text-light { color: #f3f4f6 !important; }
        body.theme-dark .text-dark { color: #1f2937 !important; }
        body.theme-dark .text-muted { color: #9ca3af !important; }
        body.theme-dark .text-white { color: #ffffff !important; }
        body.theme-dark .text-body { color: #f9fafb !important; }

        /* Dropdowns */
        body.theme-dark .dropdown-menu {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
        }
        body.theme-dark .dropdown-item {
            color: #f9fafb !important;
        }
        body.theme-dark .dropdown-item:hover,
        body.theme-dark .dropdown-item:focus {
            background-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .dropdown-divider {
            border-top-color: #374151 !important;
        }

        /* Pagination */
        body.theme-dark .page-link {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .page-link:hover {
            background-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .page-item.active .page-link {
            background-color: #3b82f6 !important;
            border-color: #3b82f6 !important;
            color: white !important;
        }
        body.theme-dark .page-item.disabled .page-link {
            background-color: #111827 !important;
            color: #6b7280 !important;
        }

        /* Progress bars */
        body.theme-dark .progress {
            background-color: #374151 !important;
        }

        /* Nav tabs and pills */
        body.theme-dark .nav-tabs {
            border-bottom-color: #374151 !important;
        }
        body.theme-dark .nav-tabs .nav-link {
            color: #9ca3af !important;
            border-color: transparent !important;
        }
        body.theme-dark .nav-tabs .nav-link:hover {
            border-color: #4b5563 #4b5563 #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .nav-tabs .nav-link.active {
            background-color: #1f2937 !important;
            border-color: #374151 #374151 #1f2937 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .nav-pills .nav-link {
            color: #9ca3af !important;
        }
        body.theme-dark .nav-pills .nav-link.active {
            background-color: #3b82f6 !important;
            color: white !important;
        }

        /* Breadcrumbs */
        body.theme-dark .breadcrumb {
            background-color: #1f2937 !important;
        }
        body.theme-dark .breadcrumb-item {
            color: #9ca3af !important;
        }
        body.theme-dark .breadcrumb-item.active {
            color: #f9fafb !important;
        }
        body.theme-dark .breadcrumb-item + .breadcrumb-item::before {
            color: #6b7280 !important;
        }

        /* Close button */
        body.theme-dark .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%) !important;
        }

        /* Input groups */
        body.theme-dark .input-group-text {
            background-color: #374151 !important;
            border-color: #4b5563 !important;
            color: #f9fafb !important;
        }

        /* Product cards on dashboard */
        body.theme-dark .product-card .card-title {
            color: #f9fafb !important;
        }
        body.theme-dark .product-card .price {
            color: #f9fafb !important;
        }
        body.theme-dark .product-card .stock {
            color: #9ca3af !important;
        }

        /* Stat cards */
        body.theme-dark .stat-card .stat-label {
            color: #9ca3af !important;
        }
        body.theme-dark .stat-card .stat-value {
            color: #f9fafb !important;
        }

        /* Table row states */
        body.theme-dark .table-success {
            --bs-table-bg: rgba(16, 185, 129, 0.2) !important;
            --bs-table-color: #6ee7b7 !important;
        }
        body.theme-dark .table-warning {
            --bs-table-bg: rgba(245, 158, 11, 0.2) !important;
            --bs-table-color: #fcd34d !important;
        }
        body.theme-dark .table-danger {
            --bs-table-bg: rgba(239, 68, 68, 0.2) !important;
            --bs-table-color: #fca5a5 !important;
        }
        body.theme-dark .table-info {
            --bs-table-bg: rgba(14, 165, 233, 0.2) !important;
            --bs-table-color: #7dd3fc !important;
        }

        /* Theme: Coffee Brown */
        body.theme-coffee {
            --bg-color: #fffbeb;
            --card-bg: #ffffff;
            --text-primary: #78350f;
            --text-secondary: #9c6b3f;
            --accent: #92400e;
            --accent-light: #d97706;
            --success: #059669;
            --warning: #d97706;
            --danger: #dc2626;
            --border: #fde68a;
        }
        body.theme-coffee .navbar { background: linear-gradient(135deg, #78350f 0%, #b45309 100%) !important; }
        body.theme-coffee .navbar-brand,
        body.theme-coffee .nav-link { color: #fffbeb !important; }
        body.theme-coffee .nav-link:hover,
        body.theme-coffee .nav-link.active { background: rgba(255, 255, 255, 0.15) !important; color: #fffbeb !important; }
        body.theme-coffee .navbar-toggler-icon { filter: invert(1); }
        @media (max-width: 991px) {
            body.theme-coffee .navbar-collapse { background: #ffffff !important; }
            body.theme-coffee .navbar-collapse .nav-link { color: var(--text-primary) !important; background: transparent !important; }
            body.theme-coffee .navbar-collapse .nav-link:hover { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-coffee .navbar-collapse .nav-link.active { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-coffee .sidebar-header { background: #ffffff !important; border-bottom-color: var(--border); }
            body.theme-coffee .sidebar-header .navbar-brand { color: var(--accent) !important; }
            body.theme-coffee .sidebar-close { color: var(--text-secondary) !important; }
            body.theme-coffee .sidebar-close:hover { color: var(--accent) !important; }
        }

        /* Theme: Berry Red */
        body.theme-berry {
            --bg-color: #fff1f2;
            --card-bg: #ffffff;
            --text-primary: #881337;
            --text-secondary: #b83b57;
            --accent: #9f1239;
            --accent-light: #e11d48;
            --success: #059669;
            --warning: #d97706;
            --danger: #be123c;
            --border: #fecdd3;
        }
        body.theme-berry .navbar { background: linear-gradient(135deg, #9f1239 0%, #e11d48 100%) !important; }
        body.theme-berry .navbar-brand,
        body.theme-berry .nav-link { color: white !important; }
        body.theme-berry .nav-link:hover,
        body.theme-berry .nav-link.active { background: rgba(255, 255, 255, 0.15) !important; color: white !important; }
        body.theme-berry .navbar-toggler-icon { filter: invert(1); }
        @media (max-width: 991px) {
            body.theme-berry .navbar-collapse { background: #ffffff !important; }
            body.theme-berry .navbar-collapse .nav-link { color: var(--text-primary) !important; background: transparent !important; }
            body.theme-berry .navbar-collapse .nav-link:hover { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-berry .navbar-collapse .nav-link.active { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-berry .sidebar-header { background: #ffffff !important; border-bottom-color: var(--border); }
            body.theme-berry .sidebar-header .navbar-brand { color: var(--accent) !important; }
            body.theme-berry .sidebar-close { color: var(--text-secondary) !important; }
            body.theme-berry .sidebar-close:hover { color: var(--accent) !important; }
        }

        /* Theme: Fresh Mint */
        body.theme-mint {
            --bg-color: #f0fdfa;
            --card-bg: #ffffff;
            --text-primary: #134e4a;
            --text-secondary: #3a9b8f;
            --accent: #0f766e;
            --accent-light: #14b8a6;
            --success: #059669;
            --warning: #d97706;
            --danger: #dc2626;
            --border: #ccfbf1;
        }
        body.theme-mint .navbar { background: linear-gradient(135deg, #0f766e 0%, #14b8a6 100%) !important; }
        body.theme-mint .navbar-brand,
        body.theme-mint .nav-link { color: white !important; }
        body.theme-mint .nav-link:hover,
        body.theme-mint .nav-link.active { background: rgba(255, 255, 255, 0.15) !important; color: white !important; }
        body.theme-mint .navbar-toggler-icon { filter: invert(1); }
        @media (max-width: 991px) {
            body.theme-mint .navbar-collapse { background: #ffffff !important; }
            body.theme-mint .navbar-collapse .nav-link { color: var(--text-primary) !important; background: transparent !important; }
            body.theme-mint .navbar-collapse .nav-link:hover { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-mint .navbar-collapse .nav-link.active { color: var(--accent) !important; background: var(--bg-color) !important; }
            body.theme-mint .sidebar-header { background: #ffffff !important; border-bottom-color: var(--border); }
            body.theme-mint .sidebar-header .navbar-brand { color: var(--accent) !important; }
            body.theme-mint .sidebar-close { color: var(--text-secondary) !important; }
            body.theme-mint .sidebar-close:hover { color: var(--accent) !important; }
        }

        /* Theme Button Overrides for gradient themes */
        body[class*="theme-"]:not(.theme-default):not(.theme-dark) .btn-primary {
            background: var(--accent);
            border-color: var(--accent);
        }
        body[class*="theme-"]:not(.theme-default):not(.theme-dark) .btn-primary:hover {
            background: var(--accent-light);
            border-color: var(--accent-light);
        }
        body[class*="theme-"]:not(.theme-default):not(.theme-dark) .bg-primary {
            background: var(--accent) !important;
        }
        body[class*="theme-"]:not(.theme-default):not(.theme-dark) .text-primary {
            color: var(--accent) !important;
        }
        body[class*="theme-"]:not(.theme-default):not(.theme-dark) .form-control:focus,
        body[class*="theme-"]:not(.theme-default):not(.theme-dark) .form-select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.1);
        }

        /* ============================================
           GLOBAL TEXT READABILITY IMPROVEMENTS
           ============================================ */

        /* Ensure all headings use primary text color */
        body[class*="theme-"] h1, body[class*="theme-"] h2, body[class*="theme-"] h3,
        body[class*="theme-"] h4, body[class*="theme-"] h5, body[class*="theme-"] h6 {
            color: var(--text-primary) !important;
        }

        /* Ensure paragraphs and labels are readable */
        body[class*="theme-"] p, body[class*="theme-"] label,
        body[class*="theme-"] .form-label, body[class*="theme-"] .card-title {
            color: var(--text-primary) !important;
        }

        /* Secondary text with better contrast */
        body[class*="theme-"] .text-secondary,
        body[class*="theme-"] .card-subtitle,
        body[class*="theme-"] small {
            color: var(--text-secondary) !important;
            font-weight: 500;
        }

        /* Table text readability */
        body[class*="theme-"] .table {
            color: var(--text-primary) !important;
        }
        body[class*="theme-"] .table th {
            color: var(--text-primary) !important;
            font-weight: 600;
        }
        body[class*="theme-"] .table td {
            color: var(--text-primary) !important;
        }

        /* Badge and alert text fixes */
        body[class*="theme-"] .badge {
            font-weight: 600;
        }
        body[class*="theme-"] .alert {
            color: var(--text-primary);
        }

        /* Dark theme specific text fixes */
        body.theme-dark .text-secondary,
        body.theme-dark small,
        body.theme-dark .card-subtitle {
            color: #9ca3af !important;
        }
        body.theme-dark .table {
            color: #f9fafb !important;
        }
        body.theme-dark .table th,
        body.theme-dark .table td {
            color: #f9fafb !important;
            border-color: #374151 !important;
        }

        /* Form and input text */
        body[class*="theme-"] .form-control,
        body[class*="theme-"] .form-select {
            color: var(--text-primary) !important;
            background-color: var(--card-bg) !important;
        }
        body[class*="theme-"] .form-control::placeholder {
            color: var(--text-secondary) !important;
            opacity: 0.7;
        }

        /* Modal text */
        body[class*="theme-"] .modal-title {
            color: var(--text-primary) !important;
        }
        body[class*="theme-"] .modal-body {
            color: var(--text-primary) !important;
        }

        /* Footer text */
        body[class*="theme-"] footer {
            color: var(--text-secondary) !important;
        }
        body[class*="theme-"] footer a {
            color: var(--accent) !important;
        }

        /* ============================================
           DASHBOARD PRODUCT CARD TEXT FIXES
           ============================================ */

        /* Product card text visibility */
        body[class*="theme-"] .product-card .card-title {
            color: var(--text-primary) !important;
        }
        body[class*="theme-"] .product-card .price {
            color: var(--text-primary) !important;
        }
        body[class*="theme-"] .product-card .stock {
            color: var(--text-secondary) !important;
        }
        body[class*="theme-"] .product-card .product-image.placeholder {
            color: var(--text-secondary) !important;
        }

        /* Stat card text */
        body[class*="theme-"] .stat-card .stat-label {
            color: var(--text-secondary) !important;
        }
        body[class*="theme-"] .stat-card .stat-value {
            color: var(--text-primary) !important;
        }

        /* Page header text */
        body[class*="theme-"] .page-header h2 {
            color: var(--text-primary) !important;
        }
        body[class*="theme-"] .page-header p {
            color: var(--text-secondary) !important;
        }

        /* Badge text visibility fix - ensure badges always have readable text */
        body[class*="theme-"] .badge {
            color: white !important;
            text-shadow: none !important;
        }
        body[class*="theme-"] .badge.bg-primary {
            background-color: var(--accent) !important;
            color: white !important;
        }
        body[class*="theme-"] .badge.bg-secondary {
            background-color: #6c757d !important;
            color: white !important;
        }
        body[class*="theme-"] .badge.bg-success {
            background-color: var(--success) !important;
            color: white !important;
        }
        body[class*="theme-"] .badge.bg-danger {
            background-color: var(--danger) !important;
            color: white !important;
        }
        body[class*="theme-"] .badge.bg-warning {
            background-color: #f59e0b !important;
            color: #000 !important;
        }
        body[class*="theme-"] .badge.bg-info {
            background-color: #0dcaf0 !important;
            color: #000 !important;
        }

        /* ============================================
           MIDNIGHT DARK THEME COMPREHENSIVE FIXES
           ============================================ */
        /* Card backgrounds and text */
        body.theme-dark .card {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
        }
        body.theme-dark .card-header {
            background-color: #1f2937 !important;
            border-bottom-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .card-body {
            color: #f9fafb !important;
        }
        
        /* Table styles */
        body.theme-dark .table {
            color: #f9fafb !important;
        }
        body.theme-dark .table thead th {
            background-color: #374151 !important;
            color: #f9fafb !important;
            border-color: #4b5563 !important;
        }
        body.theme-dark .table tbody td {
            border-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .table tbody tr:hover {
            background-color: #374151 !important;
        }
        
        /* Form elements */
        body.theme-dark .form-control {
            background-color: #111827 !important;
            border-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .form-control:focus {
            background-color: #111827 !important;
            border-color: #3b82f6 !important;
            color: #f9fafb !important;
            box-shadow: 0 0 0 0.25rem rgba(59, 130, 246, 0.25);
        }
        body.theme-dark .form-control:disabled {
            background-color: #374151 !important;
            color: #9ca3af !important;
        }
        body.theme-dark .form-label {
            color: #f9fafb !important;
        }
        body.theme-dark .form-select {
            background-color: #111827 !important;
            border-color: #374151 !important;
            color: #f9fafb !important;
        }
        
        /* Modal styles */
        body.theme-dark .modal-content {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
        }
        body.theme-dark .modal-header {
            background-color: #1f2937 !important;
            border-bottom-color: #374151 !important;
        }
        body.theme-dark .modal-header .modal-title {
            color: #f9fafb !important;
        }
        body.theme-dark .modal-body {
            color: #f9fafb !important;
        }
        body.theme-dark .modal-footer {
            background-color: #1f2937 !important;
            border-top-color: #374151 !important;
        }
        
        /* Product cards on dashboard */
        body.theme-dark .product-card {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
        }
        body.theme-dark .product-card .card-title {
            color: #f9fafb !important;
        }
        body.theme-dark .product-card .price {
            color: #f9fafb !important;
        }
        body.theme-dark .product-card .stock {
            color: #9ca3af !important;
        }
        
        /* Stat cards */
        body.theme-dark .stat-card {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
        }
        body.theme-dark .stat-card .stat-label {
            color: #9ca3af !important;
        }
        body.theme-dark .stat-card .stat-value {
            color: #f9fafb !important;
        }
        
        /* List groups */
        body.theme-dark .list-group-item {
            background-color: #1f2937 !important;
            border-color: #374151 !important;
            color: #f9fafb !important;
        }
        body.theme-dark .list-group-item:hover {
            background-color: #374151 !important;
        }
        
        /* Buttons - ensure visibility */
        body.theme-dark .btn-close {
            filter: invert(1) grayscale(100%) brightness(200%);
        }
        
        /* Inventory table specific */
        body.theme-dark .table .text-muted {
            color: #9ca3af !important;
        }
        body.theme-dark .table .text-secondary {
            color: #9ca3af !important;
        }
        body.theme-dark .table-success {
            background-color: #065f46 !important;
        }
        body.theme-dark .table-success td {
            color: #f9fafb !important;
        }
        body.theme-dark .table-warning {
            background-color: #92400e !important;
        }
        body.theme-dark .table-warning td {
            color: #f9fafb !important;
        }
    </style>
</head>
<?php
$currentTheme = $_SESSION['theme'] ?? 'default';

// Fetch license once to be used by theme enforcer and navbar
require_once __DIR__ . '/../../controllers/LicenseController.php';
global $pdo;
$mainLicense = LicenseController::getCurrentLicense($pdo);

// Enforce theme premium restriction globally
if ($currentTheme !== 'default' && (empty($mainLicense['premium_themes']) || !empty($mainLicense['is_expired']))) {
    $currentTheme = 'default';
    $_SESSION['theme'] = 'default';
}
?>
<body class="theme-<?= sanitize($currentTheme) ?>">
    <!-- Backdrop for mobile sidebar -->
    <div class="sidebar-backdrop" id="sidebarBackdrop" onclick="closeSidebar()"></div>
    
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2" href="index.php?page=dashboard&v=<?= time() ?>">
                StoreTap
                <?php 
                if (!empty($mainLicense['license_type']) && empty($mainLicense['is_expired'])):

                    if ($mainLicense['license_type'] === 'dev'): 
                ?>
                    <span class="badge rounded-pill text-white" style="background: linear-gradient(135deg, #00f2fe 0%, #4facfe 50%, #00f2fe 100%); font-size: 0.55em; letter-spacing: 2px; padding: 0.4em 0.8em; font-weight: 900; box-shadow: 0 0 10px rgba(0, 242, 254, 0.8), 0 0 20px rgba(79, 172, 254, 0.5); border: 1px solid rgba(255,255,255,0.4); text-shadow: 0 1px 2px rgba(0,0,0,0.5);">TEST</span>
                <?php elseif ($mainLicense['license_type'] === 'pro'): ?>
                    <span class="badge rounded-pill text-white" style="background: linear-gradient(135deg, #fdd034 0%, #f37335 33%, #d52d8b 66%, #8a2387 100%); font-size: 0.5em; letter-spacing: 1px; padding: 0.35em 0.65em; font-weight: 700; box-shadow: 0 2px 4px rgba(213, 45, 139, 0.3); border: 1px solid rgba(255,255,255,0.2);">PRO</span>
                <?php elseif (in_array($mainLicense['license_type'], ['free', 'basic'])): ?>
                    <span class="badge rounded-pill bg-secondary text-white" style="font-size: 0.5em; letter-spacing: 1px; padding: 0.35em 0.65em; font-weight: 700;">BASIC</span>
                <?php endif; ?>
                <span class="license-countdown badge rounded-pill bg-danger shadow-sm text-white" style="display: none; font-size: 0.5em; letter-spacing: 1px; padding: 0.35em 0.65em; font-weight: 700; border: 1px solid rgba(255,255,255,0.2);"></span>
                <?php endif; ?>
            </a>
            <button class="navbar-toggler" type="button" onclick="toggleSidebar()" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNav">
                <?php include __DIR__ . '/../partials/sidebar.php'; ?>
            </div>
        </div>
    </nav>
    
    <div class="container py-3 py-lg-4">
        <!-- OFFLINE OVERLAY CONTENT -->
        <?php if (isLoggedIn() && $currentPage !== 'settings' && $currentPage !== 'offline_dashboard' && $currentPage !== 'logout'): ?>
        <div id="offlineOverlay" class="d-none flex-column justify-content-center align-items-center text-center py-5">
            <div class="mb-2 position-relative d-inline-block">
                <span style="font-size: 5rem;">🌐</span>
                <span class="position-absolute" style="font-size: 2rem; bottom: 0; right: -10px;">❌</span>
            </div>
            
            <h2 class="fw-bold mb-3 mt-2">No Internet Connection</h2>
            
            <?php if ($currentPage === 'dashboard'): ?>
                <?php if (!empty($mainLicense['license_type']) && $mainLicense['license_type'] === 'pro'): ?>
                    <p class="text-secondary mb-4 fs-5">You are currently offline. Fortunately, your Pro License includes Offline Mode!</p>
                    <a href="index.php?page=offline_dashboard" class="btn btn-primary btn-lg rounded-pill fw-bold shadow px-5" style="background: linear-gradient(135deg, #fdd034 0%, #f37335 33%, #d52d8b 66%, #8a2387 100%); border: none; color: white;">Go to Offline Dashboard</a>
                <?php else: ?>
                    <p class="text-secondary mb-4 fs-5">You are currently offline. Unlock Offline Mode by purchasing a <span class="text-warning fw-bold">Pro License</span> to keep your store running without internet!</p>
                    <p class="text-muted small mb-0">Please wait for your connection to restore.</p>
                <?php endif; ?>
            <?php else: ?>
                <p class="text-secondary mb-4 fs-5">This feature requires an active internet connection. Please check your network and try again.</p>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- ONLINE CONTENT -->
        <div id="onlineContent">
            <?php if (isset($flash) && $flash): ?>
                <div class="alert alert-<?= sanitize($flash['type']) ?> mb-3" role="alert">
                    <?= sanitize($flash['message']) ?>
                </div>
            <?php endif; ?>
            <?php include __DIR__ . '/../' . $view . '.php'; ?>
        </div>
    </div>
    <footer class="text-center text-secondary small py-3 border-top" style="border-color: rgba(229,231,235,.8);">
        <div class="mb-2"><?= sanitize(APP_NAME) ?> <?= sanitize(APP_VERSION) ?> &ndash; Built by <a href="https://heyvince.vercel.app" target="_blank" rel="noopener">heyvince.vercel.app</a></div>
        <div>&copy; 2026 Vince AI Developer. All Rights Reserved.</div>
    </footer>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php if ($currentPage === 'offline_dashboard' || $currentPage === 'settings'): ?>
    <script src="assets/js/offlineStorage.js?v=<?= APP_VERSION ?>"></script>
    <?php endif; ?>
    <script>
        // Auto-add cache-busting to all forms
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(e) {
                // Add timestamp to action URL if it doesn't have one
                let action = form.getAttribute('action') || window.location.href;
                if (!action.includes('v=')) {
                    const separator = action.includes('?') ? '&' : '?';
                    form.setAttribute('action', action + separator + 'v=' + Date.now());
                }
            });
        });
    </script>
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('mainNav');
            const backdrop = document.getElementById('sidebarBackdrop');
            sidebar.classList.toggle('show');
            backdrop.classList.toggle('show');
            document.body.style.overflow = sidebar.classList.contains('show') ? 'hidden' : '';
        }
        
        function closeSidebar() {
            const sidebar = document.getElementById('mainNav');
            const backdrop = document.getElementById('sidebarBackdrop');
            sidebar.classList.remove('show');
            backdrop.classList.remove('show');
            document.body.style.overflow = '';
        }
        
        // Close sidebar when clicking nav links on mobile
        document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                if (window.innerWidth < 992) {
                    e.preventDefault();
                    closeSidebar();
                    setTimeout(() => {
                        window.location.href = link.href;
                    }, 300);
                }
            });
        });
        
        // Close sidebar on resize to desktop
        window.addEventListener('resize', () => {
            if (window.innerWidth >= 992) {
                closeSidebar();
            }
        });

        // Register Service Worker for PWA functionality
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/sw.js')
                    .then((registration) => {
                        console.log('[PWA] Service Worker registered:', registration.scope);

                        // Listen for updates to the service worker (New version available)
                        registration.addEventListener('updatefound', () => {
                            const newWorker = registration.installing;
                            newWorker.addEventListener('statechange', () => {
                                // If the new worker is installed and there's an existing controller (meaning it's an update, not first install)
                                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                                    showUpdateNotification();
                                }
                            });
                        });

                        // Listen for messages from service worker
                        navigator.serviceWorker.addEventListener('message', (event) => {
                            if (event.data.type === 'SYNC_COMPLETE') {
                                showToast('Connection restored. Data synced successfully.');
                            }
                        });
                    })
                    .catch((error) => {
                        console.log('[PWA] Service Worker registration failed:', error);
                    });
            });
        }

        // Check online/offline status
        window.addEventListener('online', () => {
            showToast('You are back online', 'success');
            // Trigger sync if available
            if ('serviceWorker' in navigator && 'SyncManager' in window) {
                navigator.serviceWorker.ready.then((registration) => {
                    registration.sync.register('sync-transactions');
                });
            }
        });

        window.addEventListener('offline', () => {
            showToast('You are offline. Changes will sync when connection is restored.', 'warning');
        });

        // Update Notification UI
        function showUpdateNotification() {
            // Check if one already exists
            if (document.getElementById('update-notification')) return;
            
            const banner = document.createElement('div');
            banner.id = 'update-notification';
            banner.className = 'alert position-fixed d-flex justify-content-between align-items-center m-0';
            banner.style.cssText = 'bottom: 20px; left: 50%; transform: translateX(-50%); z-index: 10000; padding: 1rem 1.5rem; border-radius: 0.75rem; box-shadow: 0 10px 25px rgba(0,0,0,0.25); width: 90%; max-width: 400px; background: var(--card-bg); color: var(--text-primary); border: 2px solid var(--accent);';
            banner.innerHTML = `
                <div>
                    <strong class="d-block mb-1" style="font-size: 1.1rem;">🚀 Update Available!</strong>
                    <small class="text-secondary" style="line-height: 1.2;">A new version of the system is ready.</small>
                </div>
                <button class="btn btn-primary btn-sm ms-3 fw-bold px-3" onclick="window.location.reload(true)">Refresh</button>
            `;
            document.body.appendChild(banner);
        }

        // Toast notification helper
        function showToast(message, type = 'info') {
            const toast = document.createElement('div');
            toast.className = `alert alert-${type === 'success' ? 'success' : type === 'warning' ? 'warning' : 'info'} position-fixed`;
            toast.style.cssText = 'top: 20px; right: 20px; z-index: 9999; padding: 1rem 1.5rem; border-radius: 0.5rem; box-shadow: 0 4px 12px rgba(0,0,0,0.15);';
            toast.textContent = message;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 5000);
        }

        // Single Session Enforcement Polling
        <?php if (isLoggedIn()): ?>
        setInterval(() => {
            fetch('index.php?page=api_check_conflict')
                .then(response => response.json())
                .then(data => {
                    if (data && data.conflict) {
                        showToast('SECURITY ALERT: Someone just tried to log into this account from another device!', 'warning');
                        // Play a sound to get attention if needed, or make the toast more persistent
                    }
                })
                .catch(err => console.error('Polling error:', err));
        }, 20000); // 20 seconds
        <?php endif; ?>
    </script>
    
    <?php 
    $secondsLeft = null;
    if (!empty($mainLicense['expires_at']) && empty($mainLicense['is_expired'])) {
        $secondsLeft = strtotime($mainLicense['expires_at']) - time();
    }
    ?>
    <script>
        let licenseSecondsLeft = <?= $secondsLeft !== null ? $secondsLeft : 'null' ?>;
        if (licenseSecondsLeft !== null && licenseSecondsLeft > 0) {
            setInterval(() => {
                licenseSecondsLeft--;
                if (licenseSecondsLeft <= 86400 && licenseSecondsLeft > 0) {
                    document.querySelectorAll('.license-countdown').forEach(el => {
                        el.style.display = 'inline-block';
                        
                        let h = Math.floor(licenseSecondsLeft / 3600);
                        let m = Math.floor((licenseSecondsLeft % 3600) / 60);
                        let s = licenseSecondsLeft % 60;
                        let text = '';
                        if (h > 0) text += h + 'h ';
                        if (m > 0 || h > 0) text += m + 'm ';
                        text += s + 's';
                        
                        el.innerText = `Expiring in ${text}`;
                    });
                }
                if (licenseSecondsLeft <= 0) {
                    window.location.reload();
                }
            }, 1000);
        }
    </script>
    
    <?php 
    $currentPage = $_GET['page'] ?? 'dashboard';
    if (isLoggedIn() && !empty($mainLicense['is_expired']) && $currentPage !== 'license' && $currentPage !== 'logout'): 
    ?>
    <div class="modal fade show" id="licenseExpiredModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" style="display: block; background: rgba(0,0,0,0.85); z-index: 1060;">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content text-center p-4 border-0" style="border-radius: 1rem; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
                <div class="modal-body">
                    <div class="mb-3">
                        <span style="font-size: 4rem;">⚠️</span>
                    </div>
                    <h3 class="fw-bold mb-3">License Expired</h3>
                    <?php if (isAdmin()): ?>
                        <p class="text-secondary mb-4" style="font-size: 1.1rem;">Your StoreTap license has expired. Please enter a new license key to continue using the system.</p>
                        <div class="d-grid gap-3">
                            <a href="index.php?page=license" class="btn btn-primary btn-lg fw-bold rounded-pill shadow-sm">Go to License Management</a>
                            <a href="index.php?page=logout" class="text-secondary small text-decoration-none">Log Out</a>
                        </div>
                    <?php else: ?>
                        <p class="text-secondary mb-4" style="font-size: 1.1rem;">Your StoreTap license has expired. Please contact the administrator to update the license key.</p>
                        <div class="d-grid gap-3">
                            <a href="index.php?page=logout" class="btn btn-outline-secondary btn-lg fw-bold rounded-pill shadow-sm">Log Out</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <script>
        // Disable scrolling when modal is open
        document.body.style.overflow = 'hidden';
    </script>
    <?php endif; ?>
    
    <script>
        const isProLicense = <?= (!empty($mainLicense['license_type']) && $mainLicense['license_type'] === 'pro') ? 'true' : 'false' ?>;
        
        function checkOfflineStatus() {
            const overlay = document.getElementById('offlineOverlay');
            const content = document.getElementById('onlineContent');
            
            if (!navigator.onLine) {
                if (isProLicense) {
                    // Auto-redirect to offline dashboard if Pro
                    if (window.location.search.indexOf('page=offline_dashboard') === -1) {
                        window.location.href = 'index.php?page=offline_dashboard';
                        return;
                    }
                } else {
                    // Show block overlay if not Pro
                    if (overlay) {
                        overlay.classList.remove('d-none');
                        overlay.classList.add('d-flex');
                    }
                    if (content) content.classList.add('d-none');
                }
            } else {
                if (overlay) {
                    overlay.classList.add('d-none');
                    overlay.classList.remove('d-flex');
                }
                if (content) content.classList.remove('d-none');
            }
        }
        
        window.addEventListener('online', checkOfflineStatus);
        window.addEventListener('offline', checkOfflineStatus);
        
        // Initial check
        if (!navigator.onLine) {
            checkOfflineStatus();
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/driver.js@1.0.1/dist/driver.js.iife.js"></script>
    <script>
        function startTutorial(forcePage = null) {
            const params = new URLSearchParams(window.location.search);
            const page = forcePage || params.get('page') || 'dashboard';
            
            const isMobile = window.innerWidth < 992;
            const menuElement = isMobile ? '.navbar-toggler' : '.navbar-nav';
            
            let steps = [];
            
            if (page === 'dashboard') {
                steps = [
                    { popover: { title: 'Welcome to StoreTap! 🎉', description: 'Let us show you around so you can start recording sales easily.' } },
                    { element: menuElement, popover: { title: 'Main Menu', description: 'Here you can access your Inventory, Reports, Utang records, and Settings.', side: isMobile ? "bottom" : "right", align: 'start' } },
                    { element: '.stat-card', popover: { title: 'Daily Stats', description: 'Quickly monitor your total sales, income, and utang for the day.' } },
                    { element: '#fastSaleBtn', popover: { title: 'Fast Sale Mode', description: 'Click this if a customer is buying multiple items. It turns on the Cart system.' } },
                    { element: '.product-card', popover: { title: 'Your Products', description: 'Tap Cash Sale to quickly record a paid item, or Record Utang if they will pay later.' } }
                ];
                
                if (!isProLicense) {
                    steps.push({ popover: { title: 'Offline Mode 📶', description: 'Did you know StoreTap can run even without internet? Upgrade to PRO to unlock Offline Mode so your store never stops!' } });
                }
                
                steps.push({ popover: { title: 'You are ready! 🚀', description: 'Explore other pages like Sales and Inventory to see more tutorials. You can always restart this guide from the Menu.' } });
                
            } else if (page === 'sales') {
                steps = [
                    { popover: { title: 'Sales Records 💰', description: 'This page shows all the sales you have made.' } },
                    { element: isMobile ? '.card' : '.table', popover: { title: 'Transactions', description: 'You can edit the price or delete a transaction here if you made a mistake.' } }
                ];
            } else if (page === 'inventory') {
                steps = [
                    { popover: { title: 'Inventory Management 🏪', description: 'Keep track of your stock levels here.' } },
                    { element: '.stat-card', popover: { title: 'Inventory Summary', description: 'See your total products and total current stock at a glance.' } }
                ];
            } else if (page === 'product_manage') {
                steps = [
                    { popover: { title: 'Products Setup 📦', description: 'Create and edit the items you are selling.' } },
                    { element: 'form', popover: { title: 'Add Product', description: 'Use this form to add a new product. You can set the name, price, and initial stock.' } }
                ];
            } else if (page === 'sales_report') {
                steps = [
                    { popover: { title: 'Business Reports 📈', description: 'See how your business is performing over time.' } },
                    { element: 'form', popover: { title: 'Filters', description: 'Filter your reports by day, month, or custom date range to see total revenue.' } }
                ];
            } else {
                // Redirect to dashboard if there's no tutorial for current page
                window.location.href = 'index.php?page=dashboard&tutorial=1';
                return;
            }

            const tour = window.driver.js.driver({
                showProgress: true,
                allowClose: true,
                steps: steps
            });
            
            // Small delay to ensure UI is fully rendered
            setTimeout(() => {
                tour.drive();
                localStorage.setItem('tutorial_done_' + page, 'true');
            }, 500);
        }

        // Auto-start if first time on supported pages
        window.addEventListener('DOMContentLoaded', () => {
            const params = new URLSearchParams(window.location.search);
            const page = params.get('page') || 'dashboard';
            const forceTutorial = params.get('tutorial');
            
            const supportedPages = ['dashboard', 'sales', 'inventory', 'product_manage', 'sales_report'];
            
            if (supportedPages.includes(page)) {
                if (!localStorage.getItem('tutorial_done_' + page) || forceTutorial) {
                    if (window.innerWidth < 992) {
                        closeSidebar();
                    }
                    setTimeout(() => startTutorial(page), 1000);
                }
            }
        });
    </script>
</body>
</html>
