<?php
require_once __DIR__ . '/config.php';

try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS license_config (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            license_key VARCHAR(255) NOT NULL,
            license_type ENUM('free', 'standard', 'pro') NOT NULL DEFAULT 'free',
            offline_dashboard TINYINT(1) NOT NULL DEFAULT 0,
            premium_themes TINYINT(1) NOT NULL DEFAULT 0,
            expires_at DATETIME NOT NULL,
            date_activated DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // Insert a default free license if empty
    $stmt = $pdo->query("SELECT COUNT(*) FROM license_config");
    if ($stmt->fetchColumn() == 0) {
        $expires = date('Y-m-d H:i:s', strtotime('+1 month'));
        $pdo->exec("INSERT INTO license_config (license_key, license_type, offline_dashboard, premium_themes, expires_at) VALUES ('FREE-TRIAL', 'free', 0, 0, '$expires')");
        echo "Default Free license added.\n";
    }

    echo "Migration successful: license_config table created.\n";
} catch (PDOException $e) {
    die("Migration failed: " . $e->getMessage() . "\n");
}
