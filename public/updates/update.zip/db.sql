-- StoreTap Database Schema
-- Use this SQL to create the database and initial tables for StoreTap.

CREATE DATABASE IF NOT EXISTS storetap CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE storetapv2;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','staff') NOT NULL DEFAULT 'staff',
  last_active DATETIME DEFAULT NULL,
  current_session_id VARCHAR(128) DEFAULT NULL,
  login_attempt_flag TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_name VARCHAR(255) NOT NULL,
  category VARCHAR(100) DEFAULT 'Uncategorized',
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  stock_qty INT UNSIGNED NOT NULL DEFAULT 0,
  initial_stock INT UNSIGNED NOT NULL DEFAULT 0,
  total_units_added INT UNSIGNED NOT NULL DEFAULT 0,
  image VARCHAR(255) DEFAULT NULL,
  INDEX idx_product_name (product_name),
  INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS sales (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id INT UNSIGNED NOT NULL,
  qty INT UNSIGNED NOT NULL DEFAULT 1,
  original_qty INT UNSIGNED NOT NULL DEFAULT 0,
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  total DECIMAL(10,2) NOT NULL,
  created_by VARCHAR(100) DEFAULT NULL,
  notes TEXT,
  date_created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  date_updated DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
  INDEX idx_sales_product (product_id),
  INDEX idx_sales_date (date_created)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS utang (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  customer_name VARCHAR(255) NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  qty INT UNSIGNED NOT NULL DEFAULT 1,
  total DECIMAL(10,2) NOT NULL,
  remaining_balance DECIMAL(10,2) NOT NULL,
  due_date DATE NOT NULL,
  status ENUM('Unpaid','Paid','Partial') NOT NULL DEFAULT 'Unpaid',
  created_by VARCHAR(100) DEFAULT NULL,
  date_created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
  INDEX idx_utang_product (product_id),
  INDEX idx_utang_date (date_created),
  INDEX idx_utang_customer (customer_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS utang_payments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  utang_id INT UNSIGNED NOT NULL,
  amount_paid DECIMAL(10,2) NOT NULL,
  remaining_balance DECIMAL(10,2) NOT NULL,
  paid_by VARCHAR(100) DEFAULT NULL,
  date_created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (utang_id) REFERENCES utang(id) ON DELETE CASCADE,
  INDEX idx_payment_utang (utang_id),
  INDEX idx_payment_date (date_created)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS inventory_checks (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id INT UNSIGNED NOT NULL,
  expected_qty INT UNSIGNED NOT NULL,
  actual_qty INT UNSIGNED NOT NULL,
  missing_qty INT NOT NULL,
  checked_by VARCHAR(100) NOT NULL,
  notes TEXT,
  date_created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_check_product (product_id),
  INDEX idx_check_date (date_created)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS license_config (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  license_key VARCHAR(255) NOT NULL,
  license_type ENUM('free', 'standard', 'pro') NOT NULL DEFAULT 'free',
  offline_dashboard TINYINT(1) NOT NULL DEFAULT 0,
  premium_themes TINYINT(1) NOT NULL DEFAULT 0,
  expires_at DATETIME NOT NULL,
  date_activated DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO users (username, password, role) VALUES
('admin', '$2y$10$uANPCR.VBFw3Otri6uHNdOmOJuhGLULwgoXZkwLG0urqPpm5DIbIu', 'admin');

INSERT INTO products (product_name, price, stock_qty) VALUES
('Sari-sari Water Bottle', 15.00, 20),
('Instant Noodles', 12.00, 30),
('Softdrink Can', 25.00, 15),
('Rice 1kg', 70.00, 10);
