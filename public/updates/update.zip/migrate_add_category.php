<?php
require_once __DIR__ . '/init.php';

try {
    // Check if column already exists
    $stmt = $pdo->prepare("SHOW COLUMNS FROM products LIKE 'category'");
    $stmt->execute();
    $columnExists = $stmt->fetch();

    if (!$columnExists) {
        $pdo->exec("ALTER TABLE products ADD COLUMN category VARCHAR(100) DEFAULT 'Uncategorized' AFTER product_name");
        
        // Let's seed some categories for the demo products if they exist
        $pdo->exec("UPDATE products SET category = 'Beverages' WHERE product_name LIKE '%Water%' OR product_name LIKE '%Softdrink%'");
        $pdo->exec("UPDATE products SET category = 'Noodles / Hot Food' WHERE product_name LIKE '%Noodles%'");
        $pdo->exec("UPDATE products SET category = 'Pantry' WHERE product_name LIKE '%Rice%'");

        echo "<h2>Migration Successful!</h2>";
        echo "<p>The 'category' column was added to the 'products' table.</p>";
    } else {
        echo "<h2>Migration skipped</h2>";
        echo "<p>The 'category' column already exists in the 'products' table.</p>";
    }
} catch (PDOException $e) {
    echo "<h2>Migration Failed!</h2>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
}

echo '<a href="index.php?page=dashboard">Back to Dashboard</a>';
