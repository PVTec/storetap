/**
 * StoreTap Offline Storage Module
 * Handles localStorage operations with background sync
 */

const OfflineStorage = {
    // Keys for localStorage
    KEYS: {
        SALES_QUEUE: 'storetap_sales_queue',
        UTANG_QUEUE: 'storetap_utang_queue',
        PRODUCTS: 'storetap_products',
        STATS: 'storetap_stats',
        LAST_SYNC: 'storetap_last_sync',
        SYNC_STATUS: 'storetap_sync_status'
    },

    // Mutex to prevent concurrent sync calls (race condition fix)
    isSyncing: false,

    // Initialize the module
    init() {
        this.startSyncLoop();
        this.updateStorageUsage();

        // Always sync fresh data from server when online
        // (especially needed after form submits like sale/utang/product)
        const needsSync = localStorage.getItem('storetap_needs_sync');
        if (needsSync) {
            localStorage.removeItem('storetap_needs_sync');
        }
        this.syncAllFromServer();

        // Re-sync every time the user comes back to this tab
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && this.isOnline()) {
                this.syncAllFromServer();
            }
        });

        console.log('OfflineStorage initialized');
    },

    // Sync both products and stats from server in one call
    syncAllFromServer() {
        if (!this.isOnline()) return;
        this.syncProductsFromServer();
        this.syncStatsFromServer();
    },

    // Get storage usage in bytes
    getStorageUsage() {
        let total = 0;
        for (let key in localStorage) {
            if (localStorage.hasOwnProperty(key)) {
                total += localStorage[key].length * 2; // UTF-16 encoding
            }
        }
        return total;
    },

    // Format bytes to human readable
    formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    // Update storage usage display
    updateStorageUsage() {
        const usage = this.getStorageUsage();
        const max = 5 * 1024 * 1024; // Approximate localStorage limit (5MB)
        const percentage = Math.min((usage / max) * 100, 100);
        
        // Dispatch event for settings page to listen
        window.dispatchEvent(new CustomEvent('storageUsageUpdate', {
            detail: { usage, percentage, formatted: this.formatBytes(usage) }
        }));
        
        return { usage, percentage, formatted: this.formatBytes(usage) };
    },

    // Queue a sale for background sync
    queueSale(saleData) {
        const queue = this.getSalesQueue();
        queue.push({
            ...saleData,
            id: 'local_' + Date.now(),
            timestamp: Date.now(),
            synced: false
        });
        localStorage.setItem(this.KEYS.SALES_QUEUE, JSON.stringify(queue));
        this.updateStorageUsage();
        this.triggerSync();
        return true;
    },

    // Get sales queue
    getSalesQueue() {
        const data = localStorage.getItem(this.KEYS.SALES_QUEUE);
        return data ? JSON.parse(data) : [];
    },

    // Queue utang for background sync
    queueUtang(utangData) {
        const queue = this.getUtangQueue();
        queue.push({
            ...utangData,
            id: 'local_' + Date.now(),
            timestamp: Date.now(),
            synced: false
        });
        localStorage.setItem(this.KEYS.UTANG_QUEUE, JSON.stringify(queue));
        this.updateStorageUsage();
        this.triggerSync();
        return true;
    },

    // Get utang queue
    getUtangQueue() {
        const data = localStorage.getItem(this.KEYS.UTANG_QUEUE);
        return data ? JSON.parse(data) : [];
    },

    // Store products locally for instant access
    storeProducts(products) {
        localStorage.setItem(this.KEYS.PRODUCTS, JSON.stringify({
            data: products,
            timestamp: Date.now()
        }));
        this.updateStorageUsage();
    },

    // Sync products from server
    syncProductsFromServer() {
        if (!this.isOnline()) return;
        
        fetch('index.php?page=api_products&_t=' + Date.now(), {
            method: 'GET',
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate'
            }
        })
        .then(response => {
            if (!response.ok) throw new Error('Failed to fetch products');
            return response.json();
        })
        .then(products => {
            if (Array.isArray(products)) {
                this.storeProducts(products);
            }
        })
        .catch(err => console.error('[OfflineStorage] Error syncing products:', err));
    },

    // Sync stats from server
    syncStatsFromServer() {
        if (!this.isOnline()) return;
        
        fetch('index.php?page=api_stats&_t=' + Date.now(), {
            method: 'GET',
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate'
            }
        })
        .then(response => {
            if (!response.ok) throw new Error('Failed to fetch stats');
            return response.json();
        })
        .then(stats => {
            if (stats) {
                this.storeStats(stats);
                window.dispatchEvent(new CustomEvent('statsUpdated'));
            }
        })
        .catch(err => console.error('[OfflineStorage] Error syncing stats:', err));
    },

    // Get cached products
    getProducts() {
        const data = localStorage.getItem(this.KEYS.PRODUCTS);
        if (!data) return null;
        const parsed = JSON.parse(data);
        return parsed.data || null;
    },

    // Store stats locally
    storeStats(stats) {
        localStorage.setItem(this.KEYS.STATS, JSON.stringify({
            data: stats,
            timestamp: Date.now()
        }));
        this.updateStorageUsage();
    },

    // Get cached stats
    getStats() {
        const data = localStorage.getItem(this.KEYS.STATS);
        if (!data) return null;
        const parsed = JSON.parse(data);
        return parsed.data || null;
    },

    // Check if online
    isOnline() {
        if (window.isForcedOffline) return false;
        
        if (typeof window.isConnectionFast !== 'undefined') {
            return window.isConnectionFast;
        }
        return navigator.onLine;
    },

    // Trigger immediate sync
    async triggerSync() {
        if (this.isOnline()) {
            await this.syncToServer();
        }
    },

    // Background sync to server
    async syncToServer() {
        // MUTEX: Prevent race condition — only one sync can run at a time
        if (this.isSyncing) {
            console.log('[OfflineStorage] Sync already in progress, skipping.');
            return { success: false, message: 'Sync already in progress' };
        }

        const salesQueue = this.getSalesQueue().filter(item => !item.synced);
        const utangQueue = this.getUtangQueue().filter(item => !item.synced);

        if (salesQueue.length === 0 && utangQueue.length === 0) {
            return { success: true, message: 'Nothing to sync' };
        }

        this.isSyncing = true;

        const results = { sales: [], utang: [], errors: [] };

        try {
            // Sync sales
            for (const sale of salesQueue) {
                try {
                    const formData = new FormData();
                    formData.append('action', 'sale');
                    formData.append('product_id', sale.productId);
                    formData.append('qty', sale.qty);
                    formData.append('price', sale.price);
                    formData.append('offline_id', sale.id);

                    const response = await fetch('index.php?page=dashboard&v=' + Date.now(), {
                        method: 'POST',
                        body: formData
                    });

                    if (response.ok) {
                        sale.synced = true;
                        sale.server_synced = true;
                        results.sales.push(sale.id);
                        // Remove from queue IMMEDIATELY after each successful sync to prevent double-send
                        const currentQueue = this.getSalesQueue();
                        const updated = currentQueue.filter(s => s.id !== sale.id);
                        localStorage.setItem(this.KEYS.SALES_QUEUE, JSON.stringify(updated));
                    }
                } catch (error) {
                    console.error('Sync error for sale:', sale.id, error);
                    results.errors.push({ id: sale.id, error: error.message });
                }
            }

            // Sync utang
            for (const utang of utangQueue) {
                try {
                    const formData = new FormData();
                    formData.append('action', 'utang');
                    formData.append('customer_name', utang.customerName);
                    formData.append('product_id', utang.productId);
                    formData.append('due_date', utang.dueDate);
                    formData.append('offline_id', utang.id);

                    const response = await fetch('index.php?page=dashboard&v=' + Date.now(), {
                        method: 'POST',
                        body: formData
                    });

                    if (response.ok) {
                        utang.synced = true;
                        utang.server_synced = true;
                        results.utang.push(utang.id);
                        // Remove from queue IMMEDIATELY after each successful sync to prevent double-send
                        const currentQueue = this.getUtangQueue();
                        const updated = currentQueue.filter(u => u.id !== utang.id);
                        localStorage.setItem(this.KEYS.UTANG_QUEUE, JSON.stringify(updated));
                    }
                } catch (error) {
                    console.error('Sync error for utang:', utang.id, error);
                    results.errors.push({ id: utang.id, error: error.message });
                }
            }

            // Update last sync time
            localStorage.setItem(this.KEYS.LAST_SYNC, Date.now().toString());

            // Update sync status
            const remainingSales = this.getSalesQueue();
            const remainingUtang = this.getUtangQueue();
            localStorage.setItem(this.KEYS.SYNC_STATUS, JSON.stringify({
                lastSync: Date.now(),
                pendingSales: remainingSales.length,
                pendingUtang: remainingUtang.length,
                isOnline: this.isOnline()
            }));

            // Fetch fresh data from server after successful upload
            if (results.sales.length > 0 || results.utang.length > 0) {
                this.syncProductsFromServer();
                this.syncStatsFromServer();
            }

            // Dispatch sync complete event
            window.dispatchEvent(new CustomEvent('syncComplete', {
                detail: results
            }));

        } finally {
            // ALWAYS release the lock, even if an error occurred
            this.isSyncing = false;
        }

        return results;
    },

    // Start automatic sync loop
    startSyncLoop() {
        // Sync every 30 seconds when online
        // Sync pending transactions every 30 seconds when online
        setInterval(() => {
            if (this.isOnline()) {
                this.syncToServer();
                this.syncAllFromServer(); // Keep offline cache fresh
            }
        }, 30000);

        // Listen for online/offline events
        window.addEventListener('online', () => {
            console.log('Back online - triggering sync');
            this.syncToServer();
            this.syncAllFromServer(); // Pull latest data immediately
        });

        window.addEventListener('offline', () => {
            console.log('Gone offline');
        });

        // Listen for custom network speed events (from main.php checkOfflineStatus)
        window.addEventListener('networkStatusChange', (e) => {
            if (e.detail.isFast) {
                console.log('Network is fast - syncing data.');
                // Only sync data pull here; syncToServer is triggered by 'online' event above.
                // This avoids double-submitting the same pending transactions.
                this.syncAllFromServer();
            }
        });
    },

    // Get sync status for display
    getSyncStatus() {
        const status = localStorage.getItem(this.KEYS.SYNC_STATUS);
        const lastSync = localStorage.getItem(this.KEYS.LAST_SYNC);
        
        if (!status) {
            return {
                lastSync: null,
                pendingSales: 0,
                pendingUtang: 0,
                isOnline: this.isOnline()
            };
        }

        const parsed = JSON.parse(status);
        return {
            ...parsed,
            lastSync: lastSync ? new Date(parseInt(lastSync)) : null,
            isOnline: this.isOnline()
        };
    },

    // Clear all local storage (called from settings)
    clearAll() {
        Object.values(this.KEYS).forEach(key => {
            localStorage.removeItem(key);
        });
        this.updateStorageUsage();
        console.log('All offline storage cleared');
    },

    // Instant sale - store locally and update UI immediately
    instantSale(saleData) {
        // Queue for background sync
        this.queueSale(saleData);
        
        // Update local stats immediately
        const stats = this.getStats() || { income: 0, sales: 0, utang: 0 };
        stats.income = (parseFloat(stats.income) || 0) + parseFloat(saleData.total);
        stats.sales = (parseInt(stats.sales) || 0) + parseInt(saleData.qty);
        this.storeStats(stats);
        window.dispatchEvent(new CustomEvent('statsUpdated'));

        return { success: true, local: true };
    },

    // Instant utang - store locally and update UI immediately
    instantUtang(utangData) {
        this.queueUtang(utangData);
        
        // Update local stats immediately
        const stats = this.getStats() || { income: 0, sales: 0, utang: 0 };
        stats.utang = (parseInt(stats.utang) || 0) + 1;
        this.storeStats(stats);
        window.dispatchEvent(new CustomEvent('statsUpdated'));

        return { success: true, local: true };
    },
    
    // Remove pending offline sale
    removeOfflineSale(id) {
        let queue = this.getSalesQueue();
        const initialLength = queue.length;
        
        // Find the sale to restore stock
        const sale = queue.find(s => s.id === id);
        if (sale) {
            const products = this.getProducts();
            if (products) {
                const p = products.find(p => p.id == sale.productId);
                if (p) p.stock_qty = parseInt(p.stock_qty) + parseInt(sale.qty);
                this.storeProducts(products);
            }
        }
        
        queue = queue.filter(s => s.id !== id);
        localStorage.setItem(this.KEYS.SALES_QUEUE, JSON.stringify(queue));
        this.updateStorageUsage();
        
        // Update stats
        if (sale) {
            const stats = this.getStats();
            if (stats) {
                stats.income = (parseFloat(stats.income) || 0) - parseFloat(sale.total);
                stats.sales = (parseInt(stats.sales) || 0) - parseInt(sale.qty);
                this.storeStats(stats);
                window.dispatchEvent(new CustomEvent('statsUpdated'));
            }
        }
        
        return queue.length < initialLength;
    },
    
    // Remove pending offline utang
    removeOfflineUtang(id) {
        let queue = this.getUtangQueue();
        const initialLength = queue.length;
        
        // Find the utang to restore stock
        const utang = queue.find(u => u.id === id);
        if (utang) {
            const products = this.getProducts();
            if (products) {
                const p = products.find(p => p.id == utang.productId);
                if (p) p.stock_qty = parseInt(p.stock_qty) + 1; // Assuming utang is qty 1 based on current logic
                this.storeProducts(products);
            }
        }
        
        queue = queue.filter(u => u.id !== id);
        localStorage.setItem(this.KEYS.UTANG_QUEUE, JSON.stringify(queue));
        this.updateStorageUsage();
        
        // Update stats
        if (utang) {
            const stats = this.getStats();
            if (stats) {
                stats.utang = (parseInt(stats.utang) || 0) - 1;
                this.storeStats(stats);
                window.dispatchEvent(new CustomEvent('statsUpdated'));
            }
        }
        
        return queue.length < initialLength;
    }
};

// Initialize on load
if (typeof window !== 'undefined') {
    window.OfflineStorage = OfflineStorage;
    document.addEventListener('DOMContentLoaded', () => {
        OfflineStorage.init();
    });
}
