/**
 * StoreTap Offline Storage Module
 * Handles localStorage operations with background sync
 */

const OfflineStorage = {
    // Keys for localStorage
    KEYS: {
        SALES_QUEUE: 'storetap_sales_queue',
        UTANG_QUEUE: 'storetap_utang_queue',
        PRODUCTS: 'storetap_products',
        STATS: 'storetap_stats',
        LAST_SYNC: 'storetap_last_sync',
        SYNC_STATUS: 'storetap_sync_status'
    },

    // Initialize the module
    init() {
        this.startSyncLoop();
        this.updateStorageUsage();
        console.log('OfflineStorage initialized');
    },

    // Get storage usage in bytes
    getStorageUsage() {
        let total = 0;
        for (let key in localStorage) {
            if (localStorage.hasOwnProperty(key)) {
                total += localStorage[key].length * 2; // UTF-16 encoding
            }
        }
        return total;
    },

    // Format bytes to human readable
    formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    },

    // Update storage usage display
    updateStorageUsage() {
        const usage = this.getStorageUsage();
        const max = 5 * 1024 * 1024; // Approximate localStorage limit (5MB)
        const percentage = Math.min((usage / max) * 100, 100);
        
        // Dispatch event for settings page to listen
        window.dispatchEvent(new CustomEvent('storageUsageUpdate', {
            detail: { usage, percentage, formatted: this.formatBytes(usage) }
        }));
        
        return { usage, percentage, formatted: this.formatBytes(usage) };
    },

    // Queue a sale for background sync
    queueSale(saleData) {
        const queue = this.getSalesQueue();
        queue.push({
            ...saleData,
            id: 'local_' + Date.now(),
            timestamp: Date.now(),
            synced: false
        });
        localStorage.setItem(this.KEYS.SALES_QUEUE, JSON.stringify(queue));
        this.updateStorageUsage();
        this.triggerSync();
        return true;
    },

    // Get sales queue
    getSalesQueue() {
        const data = localStorage.getItem(this.KEYS.SALES_QUEUE);
        return data ? JSON.parse(data) : [];
    },

    // Queue utang for background sync
    queueUtang(utangData) {
        const queue = this.getUtangQueue();
        queue.push({
            ...utangData,
            id: 'local_' + Date.now(),
            timestamp: Date.now(),
            synced: false
        });
        localStorage.setItem(this.KEYS.UTANG_QUEUE, JSON.stringify(queue));
        this.updateStorageUsage();
        this.triggerSync();
        return true;
    },

    // Get utang queue
    getUtangQueue() {
        const data = localStorage.getItem(this.KEYS.UTANG_QUEUE);
        return data ? JSON.parse(data) : [];
    },

    // Store products locally for instant access
    storeProducts(products) {
        localStorage.setItem(this.KEYS.PRODUCTS, JSON.stringify({
            data: products,
            timestamp: Date.now()
        }));
        this.updateStorageUsage();
    },

    // Get cached products
    getProducts() {
        const data = localStorage.getItem(this.KEYS.PRODUCTS);
        if (!data) return null;
        const parsed = JSON.parse(data);
        return parsed.data || null;
    },

    // Store stats locally
    storeStats(stats) {
        localStorage.setItem(this.KEYS.STATS, JSON.stringify({
            data: stats,
            timestamp: Date.now()
        }));
        this.updateStorageUsage();
    },

    // Get cached stats
    getStats() {
        const data = localStorage.getItem(this.KEYS.STATS);
        if (!data) return null;
        const parsed = JSON.parse(data);
        return parsed.data || null;
    },

    // Check if online
    isOnline() {
        return navigator.onLine;
    },

    // Trigger immediate sync
    async triggerSync() {
        if (this.isOnline()) {
            await this.syncToServer();
        }
    },

    // Background sync to server
    async syncToServer() {
        const salesQueue = this.getSalesQueue().filter(item => !item.synced);
        const utangQueue = this.getUtangQueue().filter(item => !item.synced);

        if (salesQueue.length === 0 && utangQueue.length === 0) {
            return { success: true, message: 'Nothing to sync' };
        }

        const results = { sales: [], utang: [], errors: [] };

        // Sync sales
        for (const sale of salesQueue) {
            try {
                const formData = new FormData();
                formData.append('action', 'sale');
                formData.append('product_id', sale.productId);
                formData.append('qty', sale.qty);
                formData.append('price', sale.price);
                formData.append('offline_id', sale.id);

                const response = await fetch('index.php?page=dashboard&v=' + Date.now(), {
                    method: 'POST',
                    body: formData
                });

                if (response.ok) {
                    sale.synced = true;
                    sale.server_synced = true;
                    results.sales.push(sale.id);
                }
            } catch (error) {
                console.error('Sync error for sale:', sale.id, error);
                results.errors.push({ id: sale.id, error: error.message });
            }
        }

        // Sync utang
        for (const utang of utangQueue) {
            try {
                const formData = new FormData();
                formData.append('action', 'utang');
                formData.append('customer_name', utang.customerName);
                formData.append('product_id', utang.productId);
                formData.append('due_date', utang.dueDate);
                formData.append('offline_id', utang.id);

                const response = await fetch('index.php?page=dashboard&v=' + Date.now(), {
                    method: 'POST',
                    body: formData
                });

                if (response.ok) {
                    utang.synced = true;
                    utang.server_synced = true;
                    results.utang.push(utang.id);
                }
            } catch (error) {
                console.error('Sync error for utang:', utang.id, error);
                results.errors.push({ id: utang.id, error: error.message });
            }
        }

        // Update queues by completely removing successfully synced items to prevent duplicates
        const allSales = this.getSalesQueue();
        const allUtang = this.getUtangQueue();
        const remainingSales = allSales.filter(s => !results.sales.includes(s.id));
        const remainingUtang = allUtang.filter(u => !results.utang.includes(u.id));

        localStorage.setItem(this.KEYS.SALES_QUEUE, JSON.stringify(remainingSales));
        localStorage.setItem(this.KEYS.UTANG_QUEUE, JSON.stringify(remainingUtang));

        // Update last sync time
        localStorage.setItem(this.KEYS.LAST_SYNC, Date.now().toString());

        // Update sync status
        const pendingSales = remainingSales.length;
        const pendingUtang = remainingUtang.length;
        
        localStorage.setItem(this.KEYS.SYNC_STATUS, JSON.stringify({
            lastSync: Date.now(),
            pendingSales,
            pendingUtang,
            isOnline: this.isOnline()
        }));

        // Dispatch sync complete event
        window.dispatchEvent(new CustomEvent('syncComplete', {
            detail: results
        }));

        return results;
    },

    // Start automatic sync loop
    startSyncLoop() {
        // Sync every 30 seconds when online
        setInterval(() => {
            if (this.isOnline()) {
                this.syncToServer();
            }
        }, 30000);

        // Listen for online/offline events
        window.addEventListener('online', () => {
            console.log('Back online - triggering sync');
            this.syncToServer();
        });

        window.addEventListener('offline', () => {
            console.log('Gone offline');
        });
    },

    // Get sync status for display
    getSyncStatus() {
        const status = localStorage.getItem(this.KEYS.SYNC_STATUS);
        const lastSync = localStorage.getItem(this.KEYS.LAST_SYNC);
        
        if (!status) {
            return {
                lastSync: null,
                pendingSales: 0,
                pendingUtang: 0,
                isOnline: this.isOnline()
            };
        }

        const parsed = JSON.parse(status);
        return {
            ...parsed,
            lastSync: lastSync ? new Date(parseInt(lastSync)) : null,
            isOnline: this.isOnline()
        };
    },

    // Clear all local storage (called from settings)
    clearAll() {
        Object.values(this.KEYS).forEach(key => {
            localStorage.removeItem(key);
        });
        this.updateStorageUsage();
        console.log('All offline storage cleared');
    },

    // Instant sale - store locally and update UI immediately
    instantSale(saleData) {
        // Queue for background sync
        this.queueSale(saleData);
        
        // Update local stats immediately
        const stats = this.getStats() || { todayIncome: 0, todayItems: 0 };
        stats.todayIncome = (parseFloat(stats.todayIncome) || 0) + parseFloat(saleData.total);
        stats.todayItems = (parseInt(stats.todayItems) || 0) + parseInt(saleData.qty);
        this.storeStats(stats);

        return { success: true, local: true };
    },

    // Instant utang - store locally and update UI immediately
    instantUtang(utangData) {
        this.queueUtang(utangData);
        return { success: true, local: true };
    },
    
    // Remove pending offline sale
    removeOfflineSale(id) {
        let queue = this.getSalesQueue();
        const initialLength = queue.length;
        
        // Find the sale to restore stock
        const sale = queue.find(s => s.id === id);
        if (sale) {
            const products = this.getProducts();
            if (products) {
                const p = products.find(p => p.id == sale.productId);
                if (p) p.stock_qty = parseInt(p.stock_qty) + parseInt(sale.qty);
                this.storeProducts(products);
            }
        }
        
        queue = queue.filter(s => s.id !== id);
        localStorage.setItem(this.KEYS.SALES_QUEUE, JSON.stringify(queue));
        this.updateStorageUsage();
        
        // Update stats
        if (sale) {
            const stats = this.getStats();
            if (stats) {
                stats.todayIncome = (parseFloat(stats.todayIncome) || 0) - parseFloat(sale.total);
                stats.todayItems = (parseInt(stats.todayItems) || 0) - parseInt(sale.qty);
                this.storeStats(stats);
            }
        }
        
        return queue.length < initialLength;
    },
    
    // Remove pending offline utang
    removeOfflineUtang(id) {
        let queue = this.getUtangQueue();
        const initialLength = queue.length;
        
        // Find the utang to restore stock
        const utang = queue.find(u => u.id === id);
        if (utang) {
            const products = this.getProducts();
            if (products) {
                const p = products.find(p => p.id == utang.productId);
                if (p) p.stock_qty = parseInt(p.stock_qty) + 1; // Assuming utang is qty 1 based on current logic
                this.storeProducts(products);
            }
        }
        
        queue = queue.filter(u => u.id !== id);
        localStorage.setItem(this.KEYS.UTANG_QUEUE, JSON.stringify(queue));
        this.updateStorageUsage();
        
        return queue.length < initialLength;
    }
};

// Initialize on load
if (typeof window !== 'undefined') {
    window.OfflineStorage = OfflineStorage;
    document.addEventListener('DOMContentLoaded', () => {
        OfflineStorage.init();
    });
}
