<?php
/**
 * Simple PWA Icon Generator
 * Creates placeholder PNG icons for the PWA manifest
 * Run this once to generate icons: php generate-icons.php
 */

$sizes = [72, 96, 128, 144, 152, 192, 384, 512];
$color = '#0d6efd'; // Primary blue color

foreach ($sizes as $size) {
    // Create image
    $image = imagecreatetruecolor($size, $size);
    
    // Parse hex color
    $r = hexdec(substr($color, 1, 2));
    $g = hexdec(substr($color, 3, 2));
    $b = hexdec(substr($color, 5, 2));
    
    // Fill background
    $bgColor = imagecolorallocate($image, $r, $g, $b);
    imagefill($image, 0, 0, $bgColor);
    
    // Add rounded corners (simple approximation)
    $white = imagecolorallocate($image, 255, 255, 255);
    
    // Add text "S" for StoreTap
    $fontSize = intval($size * 0.45);
    $text = "S";
    
    // Get text dimensions
    $bbox = imagettfbbox($fontSize, 0, __DIR__ . '/../../arial.ttf', $text);
    if ($bbox === false) {
        // Fallback to built-in font if TTF not available
        $textWidth = imagefontwidth(5) * strlen($text);
        $textHeight = imagefontheight(5);
        $x = ($size - $textWidth) / 2;
        $y = ($size + $textHeight) / 2;
        imagestring($image, 5, intval($x), intval($y - $textHeight/2), $text, $white);
    } else {
        $textWidth = $bbox[2] - $bbox[0];
        $textHeight = $bbox[1] - $bbox[7];
        $x = ($size - $textWidth) / 2;
        $y = ($size + $textHeight) / 2;
        imagettftext($image, $fontSize, 0, intval($x), intval($y), $white, __DIR__ . '/../../arial.ttf', $text);
    }
    
    // Save as PNG
    $filename = __DIR__ . "/icon-{$size}x{$size}.png";
    imagepng($image, $filename);
    imagedestroy($image);
    
    echo "Created: icon-{$size}x{$size}.png\n";
}

echo "\nIcons generated successfully!\n";
