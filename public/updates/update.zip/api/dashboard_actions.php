<?php
// api/dashboard_actions.php - AJAX endpoint for dashboard actions
require_once __DIR__ . '/../init.php';
require_once __DIR__ . '/../controllers/BaseController.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Sale.php';
require_once __DIR__ . '/../models/Utang.php';

header('Content-Type: application/json');

// Check login
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Not authenticated']);
    exit;
}

$action = $_POST['action'] ?? '';
$productId = intval($_POST['product_id'] ?? 0);

if ($productId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid product selection.']);
    exit;
}

$productModel = new Product($pdo);
$product = $productModel->getById($productId);

if (!$product) {
    echo json_encode(['success' => false, 'message' => 'Product not found.']);
    exit;
}

if ($product['stock_qty'] <= 0) {
    echo json_encode(['success' => false, 'message' => 'Product is out of stock.']);
    exit;
}

if ($action === 'sale') {
    try {
        $pdo->beginTransaction();
        $productModel->deductStock($productId);
        $saleModel = new Sale($pdo);
        $saleModel->create($productId, 1, $product['price'], $product['price']);
        $pdo->commit();

        // Get updated stats using system time
        $today = getSystemTime('Y-m-d');
        $saleModel = new Sale($pdo);
        $statsData = $saleModel->getTodayStats($today);
        $utangModel = new Utang($pdo);
        $utangData = $utangModel->getTodayCount($today);

        echo json_encode([
            'success' => true,
            'message' => 'Cash sale recorded successfully.',
            'product_id' => $productId,
            'new_stock' => $product['stock_qty'] - 1,
            'stats' => [
                'total_items' => intval($statsData['total_items'] ?? 0),
                'total_income' => floatval($statsData['total_income'] ?? 0),
                'utang_count' => intval($utangData)
            ]
        ]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Unable to save sale: ' . $e->getMessage()]);
    }
} elseif ($action === 'utang') {
    $customerName = trim($_POST['customer_name'] ?? '');
    $dueDate = $_POST['due_date'] ?? '';

    if ($customerName === '' || $dueDate === '') {
        echo json_encode(['success' => false, 'message' => 'Customer name and due date are required.']);
        exit;
    }

    try {
        $pdo->beginTransaction();
        $productModel->deductStock($productId);
        $utangModel = new Utang($pdo);
        $utangModel->create($customerName, $productId, 1, $product['price'], $dueDate);
        $pdo->commit();

        // Get updated stats using system time
        $today = getSystemTime('Y-m-d');
        $saleModel = new Sale($pdo);
        $statsData = $saleModel->getTodayStats($today);
        $utangModel = new Utang($pdo);
        $utangData = $utangModel->getTodayCount($today);

        echo json_encode([
            'success' => true,
            'message' => 'Utang recorded successfully.',
            'product_id' => $productId,
            'new_stock' => $product['stock_qty'] - 1,
            'stats' => [
                'total_items' => intval($statsData['total_items'] ?? 0),
                'total_income' => floatval($statsData['total_income'] ?? 0),
                'utang_count' => intval($utangData)
            ]
        ]);
    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'message' => 'Unable to save utang: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action.']);
}
