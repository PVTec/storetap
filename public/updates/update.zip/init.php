<?php
// init.php
// Common bootstrap for StoreTap pages

// Prevent all caching - critical for free hosting with aggressive caching
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');

session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/auto_migrate.php';

function isLoggedIn(): bool
{
    return !empty($_SESSION['user']);
}

function currentUser(): array
{
    return $_SESSION['user'] ?? [];
}

function requireLogin(): void
{
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function requireAdmin(): void
{
    requireLogin();
    if (!isAdmin()) {
        header('Location: dashboard.php');
        exit;
    }
}

function isAdmin(): bool
{
    $user = currentUser();
    return isset($user['role']) && $user['role'] === 'admin';
}

function flash(string $message, string $type = 'success'): void
{
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}

function consumeFlash(): ?array
{
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function sanitize(string $value): string
{
    return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
}

/**
 * Get the system time adjusted by the manual time offset from settings.
 * This allows the admin to set a custom "today" date for the entire system.
 *
 * @param string $format PHP date format, default 'Y-m-d'
 * @return string Formatted date/time string
 */
function getSystemTime(string $format = 'Y-m-d'): string
{
    $offset = $_SESSION['manual_time_offset'] ?? 0;
    $timestamp = time() + (int)$offset;
    return date($format, $timestamp);
}

/**
 * Get the system timestamp adjusted by the manual time offset.
 *
 * @return int Unix timestamp
 */
function getSystemTimestamp(): int
{
    $offset = $_SESSION['manual_time_offset'] ?? 0;
    return time() + (int)$offset;
}

// Update last active status for online users tracking
if (isLoggedIn() && isset($pdo)) {
    try {
        $stmt = $pdo->prepare('UPDATE users SET last_active = NOW() WHERE id = :id');
        $stmt->execute(['id' => $_SESSION['user']['id']]);
    } catch (PDOException $e) {
        // Ignore quietly, possibly the last_active column doesn't exist yet (needs migration)
    }
}
