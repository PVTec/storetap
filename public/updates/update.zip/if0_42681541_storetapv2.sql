-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql205.infinityfree.com
-- Generation Time: Aug 23, 2026 at 07:03 AM
-- Server version: 11.4.12-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_42681541_storetapv2`
--

-- --------------------------------------------------------

--
-- Table structure for table `inventory_checks`
--

CREATE TABLE `inventory_checks` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `expected_qty` int(10) UNSIGNED NOT NULL,
  `actual_qty` int(10) UNSIGNED NOT NULL,
  `missing_qty` int(11) NOT NULL,
  `checked_by` varchar(100) NOT NULL,
  `notes` text DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_checks`
--

INSERT INTO `inventory_checks` (`id`, `product_id`, `expected_qty`, `actual_qty`, `missing_qty`, `checked_by`, `notes`, `date_created`) VALUES
(1, 2, 23, 23, 0, 'vince', '', '2026-04-23 11:20:25'),
(2, 2, 22, 22, 0, 'vince', 'Stock verified correct', '2026-04-23 11:32:46'),
(3, 2, 22, 22, 0, 'vince', 'Stock verified correct', '2026-04-23 11:32:51'),
(4, 4, 8, 8, 0, 'vince', 'Stock verified correct', '2026-04-23 11:32:54'),
(5, 1, 17, 17, 0, 'vince', 'Stock verified correct', '2026-04-23 11:32:57'),
(6, 3, 11, 11, 0, 'vince', 'Stock verified correct', '2026-04-23 11:33:01'),
(7, 2, 22, 0, 22, 'admin', 'missing', '2026-04-23 11:33:52'),
(8, 2, 0, 22, -22, 'admin', 'just joking', '2026-04-23 11:34:31'),
(9, 2, 19, 19, 0, 'admin', 'Stock verified correct', '2026-04-23 12:01:25'),
(10, 2, 498, 498, 0, 'vince', 'Stock verified correct', '2026-08-18 10:54:04'),
(11, 1, 342, 352, -10, 'vince_admin', 'Stock verified correct', '2026-08-22 15:25:21');

-- --------------------------------------------------------

--
-- Table structure for table `license_config`
--

CREATE TABLE `license_config` (
  `id` int(10) UNSIGNED NOT NULL,
  `license_key` varchar(255) NOT NULL,
  `license_type` enum('free','standard','pro') NOT NULL DEFAULT 'free',
  `offline_dashboard` tinyint(1) NOT NULL DEFAULT 0,
  `premium_themes` tinyint(1) NOT NULL DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `date_activated` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `license_config`
--

INSERT INTO `license_config` (`id`, `license_key`, `license_type`, `offline_dashboard`, `premium_themes`, `expires_at`, `date_activated`) VALUES
(1, 'FREE-TRIAL', 'free', 0, 0, '2026-09-20 06:51:09', '2026-08-20 03:51:09'),
(2, 'FREE-', 'free', 0, 0, '2026-08-20 18:55:23', '2026-08-20 03:54:23'),
(3, 'PRO-', 'pro', 1, 1, '2027-01-20 18:56:35', '2026-08-20 03:56:35'),
(4, 'STANDARD-', 'standard', 0, 1, '2026-11-20 18:57:38', '2026-08-20 03:57:38'),
(5, 'PRO-', 'pro', 1, 1, '2027-01-21 10:45:23', '2026-08-20 19:45:23'),
(6, 'FREE-', 'free', 0, 0, '2026-08-21 10:59:43', '2026-08-20 19:58:43'),
(7, 'STANDARD-', 'standard', 0, 1, '2026-11-21 11:01:24', '2026-08-20 20:01:24'),
(8, 'PRO-', 'pro', 1, 1, '2027-01-21 11:11:36', '2026-08-20 20:11:36'),
(9, 'FREE-SKBP-XCYQ-49OY', 'free', 0, 0, '2026-09-20 18:29:14', '2026-08-21 03:29:15'),
(11, 'BASIC-SYS-Q1L1-5RT1', '', 0, 0, '2026-09-20 23:58:35', '2026-08-21 08:58:35'),
(12, 'PRO-BWTU-UEKM-YDUE', 'pro', 1, 1, '2026-09-21 00:22:02', '2026-08-21 09:22:02');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `stock_qty` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `initial_stock` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `total_units_added` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `price`, `stock_qty`, `initial_stock`, `total_units_added`, `image`) VALUES
(1, 'Sari-sari Water Bottle', '15.00', 349, 385, 385, 'uploads/6a83d499cd740_1000091662.jpg'),
(2, 'Instant Noodles', '12.00', 330, 472, 472, 'uploads/6a83d47fe0cdd_1000091663.jpg'),
(3, 'Softdrink Can', '25.00', 285, 293, 293, 'uploads/6a83d4e2ccc2b_1000091666.jpg'),
(4, 'Rice 1kg', '70.00', 88, 94, 94, 'uploads/6a83d4f319d3c_1000091665.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `qty` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `original_qty` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL,
  `created_by` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `product_id`, `qty`, `original_qty`, `price`, `total`, `created_by`, `notes`, `date_created`, `date_updated`) VALUES
(96, 4, 1, 1, '70.00', '70.00', 'admin', NULL, '2026-08-18 14:01:04', NULL),
(97, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-18 15:19:34', NULL),
(98, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-18 15:19:48', NULL),
(99, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-18 15:19:48', NULL),
(100, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-18 15:42:16', NULL),
(101, 2, 3, 3, '12.00', '36.00', 'admin', NULL, '2026-08-20 14:33:14', NULL),
(102, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 14:33:14', NULL),
(103, 4, 1, 1, '70.00', '70.00', 'admin', NULL, '2026-08-20 14:33:14', NULL),
(104, 3, 1, 1, '25.00', '25.00', 'admin', NULL, '2026-08-20 14:33:14', NULL),
(105, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 15:06:15', NULL),
(106, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:06:17', NULL),
(107, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:06:22', NULL),
(108, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:11:40', NULL),
(109, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:11:53', NULL),
(110, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 15:11:58', NULL),
(111, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:12:15', NULL),
(112, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:12:29', NULL),
(113, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 15:12:29', NULL),
(114, 3, 2, 2, '25.00', '50.00', 'admin', NULL, '2026-08-20 15:12:29', NULL),
(115, 4, 2, 2, '70.00', '140.00', 'admin', NULL, '2026-08-20 15:12:29', NULL),
(116, 2, 2, 2, '12.00', '24.00', 'admin', NULL, '2026-08-20 15:12:54', NULL),
(117, 1, 3, 3, '15.00', '45.00', 'admin', NULL, '2026-08-20 15:12:54', NULL),
(118, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:15:41', NULL),
(119, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 15:56:57', NULL),
(120, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:56:59', NULL),
(121, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:57:01', NULL),
(122, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 15:57:22', NULL),
(123, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:57:24', NULL),
(124, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:57:25', NULL),
(125, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:57:28', NULL),
(126, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:59:21', NULL),
(127, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:59:25', NULL),
(128, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:59:25', NULL),
(129, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:59:58', NULL),
(130, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 15:59:59', NULL),
(131, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:02:53', NULL),
(132, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:02:58', NULL),
(133, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:02:59', NULL),
(134, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:03:43', NULL),
(135, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:03:44', NULL),
(136, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:03:44', NULL),
(137, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:03:47', NULL),
(138, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:03:48', NULL),
(139, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:03:48', NULL),
(140, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:03:49', NULL),
(141, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:03:49', NULL),
(142, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:03:50', NULL),
(143, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:03:50', NULL),
(144, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:04:29', NULL),
(145, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:04:29', NULL),
(146, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:04:30', NULL),
(147, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:04:31', NULL),
(148, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:04:32', NULL),
(149, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:09:20', NULL),
(150, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:09:21', NULL),
(151, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:09:22', NULL),
(152, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:09:27', NULL),
(153, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:09:30', NULL),
(154, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:09:32', NULL),
(155, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:09:36', NULL),
(156, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:10:36', NULL),
(157, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:10:37', NULL),
(158, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:10:38', NULL),
(159, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:10:42', NULL),
(160, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:10:46', NULL),
(161, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:12:09', NULL),
(162, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:12:10', NULL),
(163, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:12:12', NULL),
(164, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:12:16', NULL),
(165, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:12:18', NULL),
(166, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:12:19', NULL),
(167, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:12:20', NULL),
(168, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:13:16', NULL),
(169, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:13:16', NULL),
(170, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:13:17', NULL),
(171, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:13:19', NULL),
(172, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:13:51', NULL),
(173, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:13:58', NULL),
(174, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:14:09', NULL),
(175, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:14:29', NULL),
(176, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:14:29', NULL),
(177, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:14:31', NULL),
(178, 2, 1, 1, '12.00', '12.00', 'vince', NULL, '2026-08-20 16:15:29', NULL),
(179, 1, 1, 1, '15.00', '15.00', 'vince', NULL, '2026-08-20 16:15:34', NULL),
(180, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:15:43', NULL),
(181, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:15:43', NULL),
(182, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:17:55', NULL),
(183, 3, 1, 1, '25.00', '25.00', 'vince', NULL, '2026-08-20 16:22:54', NULL),
(184, 1, 1, 1, '15.00', '15.00', 'vince', NULL, '2026-08-20 16:22:58', NULL),
(185, 2, 1, 1, '12.00', '12.00', 'vince', NULL, '2026-08-20 16:22:59', NULL),
(186, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:28:39', NULL),
(187, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:28:43', NULL),
(188, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:28:43', NULL),
(189, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:28:48', NULL),
(190, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:28:48', NULL),
(191, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:28:49', NULL),
(192, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:11', NULL),
(193, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:11', NULL),
(194, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:12', NULL),
(195, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:12', NULL),
(196, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:13', NULL),
(197, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:13', NULL),
(198, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:14', NULL),
(199, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:14', NULL),
(200, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:15', NULL),
(201, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:29:15', NULL),
(202, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:15', NULL),
(203, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:16', NULL),
(204, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:16', NULL),
(205, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:29:17', NULL),
(206, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:18', NULL),
(207, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:25', NULL),
(208, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:26', NULL),
(209, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:27', NULL),
(210, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:27', NULL),
(211, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:27', NULL),
(212, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:27', NULL),
(213, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:29:28', NULL),
(214, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:28', NULL),
(215, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:29', NULL),
(216, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:29', NULL),
(217, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:29', NULL),
(218, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:29', NULL),
(219, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:30', NULL),
(220, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:29:30', NULL),
(221, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:30', NULL),
(222, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:30', NULL),
(223, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:31', NULL),
(224, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:31', NULL),
(225, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:29:32', NULL),
(226, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:32', NULL),
(227, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:32', NULL),
(228, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:29:33', NULL),
(229, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:30:03', NULL),
(230, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:30:03', NULL),
(231, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:30:04', NULL),
(232, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:30:05', NULL),
(233, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:30:05', NULL),
(234, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:30:06', NULL),
(235, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:30:06', NULL),
(236, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:30:07', NULL),
(237, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:30:08', NULL),
(238, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:30:08', NULL),
(239, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:31:15', NULL),
(240, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:31:16', NULL),
(241, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:31:17', NULL),
(242, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:31:17', NULL),
(243, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:31:17', NULL),
(244, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:31:17', NULL),
(245, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:31:18', NULL),
(246, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:31:18', NULL),
(247, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:32:21', NULL),
(248, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:32:22', NULL),
(249, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:32:22', NULL),
(250, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:32:48', NULL),
(251, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:32:49', NULL),
(252, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:32:50', NULL),
(253, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:32:50', NULL),
(254, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:33:25', NULL),
(255, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:33:25', NULL),
(256, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:33:27', NULL),
(257, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:33:27', NULL),
(258, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:34:09', NULL),
(259, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:34:10', NULL),
(260, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:34:10', NULL),
(261, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:34:11', NULL),
(262, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:34:39', NULL),
(263, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:34:40', NULL),
(264, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:34:40', NULL),
(265, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:34:41', NULL),
(266, 1, 1, 1, '15.00', '15.00', 'vince', NULL, '2026-08-20 16:38:47', NULL),
(267, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:38:54', NULL),
(268, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:38:55', NULL),
(269, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:38:55', NULL),
(270, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:38:56', NULL),
(271, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:38:58', NULL),
(272, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:38:59', NULL),
(273, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-20 16:38:59', NULL),
(274, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:39:18', NULL),
(275, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-20 16:46:02', NULL),
(276, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-21 10:46:58', NULL),
(277, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-21 10:47:04', NULL),
(278, 3, 1, 1, '25.00', '25.00', 'admin', NULL, '2026-08-21 10:47:08', NULL),
(279, 1, 2, 2, '15.00', '30.00', 'admin', NULL, '2026-08-21 10:47:27', NULL),
(280, 2, 2, 2, '12.00', '24.00', 'admin', NULL, '2026-08-21 10:47:27', NULL),
(281, 3, 3, 3, '25.00', '75.00', 'admin', NULL, '2026-08-21 10:47:27', NULL),
(282, 4, 3, 3, '70.00', '210.00', 'admin', NULL, '2026-08-21 10:47:27', NULL),
(283, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-21 10:57:32', NULL),
(284, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-21 10:59:48', NULL),
(285, 4, 1, 1, '70.00', '70.00', 'admin', NULL, '2026-08-21 12:23:54', NULL),
(286, 1, 1, 1, '15.00', '15.00', 'admin', NULL, '2026-08-21 12:23:57', NULL),
(287, 1, 1, 1, '15.00', '15.00', 'vince_admin', NULL, '2026-08-21 13:00:00', NULL),
(288, 2, 1, 1, '12.00', '12.00', 'admin', NULL, '2026-08-21 21:39:15', NULL),
(290, 1, 1, 1, '15.00', '15.00', 'vince_admin', NULL, '2026-08-22 02:17:40', NULL),
(291, 1, 3, 3, '15.00', '45.00', 'vince_admin', NULL, '2026-08-22 02:17:55', NULL),
(292, 1, 1, 1, '15.00', '15.00', 'vince_admin', NULL, '2026-08-22 02:18:07', NULL),
(293, 2, 1, 1, '12.00', '12.00', 'vince_admin', NULL, '2026-08-22 02:18:12', NULL),
(294, 1, 2, 2, '15.00', '30.00', 'vince_admin', NULL, '2026-08-22 13:14:07', NULL),
(295, 3, 1, 1, '25.00', '25.00', 'vince_admin', NULL, '2026-08-22 13:14:07', NULL),
(296, 4, 1, 1, '70.00', '70.00', 'vince_admin', NULL, '2026-08-22 13:14:07', NULL),
(297, 2, 1, 1, '12.00', '12.00', 'vince_admin', NULL, '2026-08-22 13:14:07', NULL),
(298, 2, 1, 1, '12.00', '12.00', 'vince_admin', NULL, '2026-08-22 13:18:44', NULL),
(299, 1, 1, 1, '15.00', '15.00', 'vince_admin', NULL, '2026-08-22 13:18:45', NULL),
(300, 1, 1, 1, '15.00', '15.00', 'vince_admin', NULL, '2026-08-22 15:21:01', NULL),
(301, 1, 1, 1, '15.00', '15.00', 'vince_admin', NULL, '2026-08-22 15:22:56', NULL),
(302, 1, 1, 1, '15.00', '15.00', 'Demo', NULL, '2026-08-22 19:20:58', NULL),
(303, 3, 1, 1, '25.00', '25.00', 'Demo', NULL, '2026-08-22 19:21:46', NULL),
(304, 1, 1, 1, '15.00', '15.00', 'Demo', NULL, '2026-08-22 19:22:23', NULL),
(305, 4, 1, 1, '70.00', '70.00', 'Demo', NULL, '2026-08-22 19:22:48', NULL),
(306, 3, 1, 1, '25.00', '25.00', 'vince_admin', NULL, '2026-08-22 21:12:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','staff') NOT NULL DEFAULT 'staff',
  `last_active` datetime DEFAULT NULL,
  `current_session_id` varchar(128) DEFAULT NULL,
  `login_attempt_flag` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `last_active`, `current_session_id`, `login_attempt_flag`) VALUES
(1, 'admin', '$2y$10$uANPCR.VBFw3Otri6uHNdOmOJuhGLULwgoXZkwLG0urqPpm5DIbIu', 'admin', '2026-08-23 03:48:55', 'a11364d451c0a3401782d2f13c69accb', 0),
(2, 'vince', '$2y$10$Kf2SZkdsPgvaCIC./JSTEuOLGQcPhUQ7Nbf8hP6nu1.beZ0kbvk86', 'staff', '2026-08-20 22:03:40', 'f51f2322a7e729d2fd79118bf405053f', 0),
(3, 'errol', '$2y$10$qr7NE/LBetvl1OQtnBBW8O/rUHtHw9vgq1UeXbGjtzeaSAt1kERSe', 'admin', NULL, NULL, 0),
(4, 'vince_admin', '$2y$10$SAKgNQXQHNx8Z3k1aap1AucYyt7x6XeDfNMm5WPytJAbzk.iFITrK', 'admin', '2026-08-22 06:14:29', '0c8357a475dbd89ba3b67d844c0de545', 0),
(6, 'charles', '$2y$10$dJx21MGWSIG6/jwS0yg3deRwdWJgm10NJ9XGXRvWmEx9gunCi4LWe', 'admin', NULL, NULL, 0),
(7, 'beverly', '$2y$10$FiTWVSHKwRuhiIAaZcgFW.2TikM8YL0FQqhDu4p5DJ07ZsUrpu2em', 'admin', NULL, NULL, 0),
(8, 'jacob', '$2y$10$TFWYjNqgHDnKHTk5xoXS7OP2rQzaLdhq2d6EA1a7hmIAbRFKcLZh2', 'admin', NULL, NULL, 0),
(9, 'Demo', '$2y$10$rsSmuZhPYaWb9xHyFKDcY.gcXXsbDq1E75UIJ8BhWbe3BCTMkGN5O', 'admin', '2026-08-22 04:23:07', NULL, 0),
(10, 'jeseryl', '$2y$10$L8oTV/6cJrSlXSEnL4c3/eYr9MOdZt2q1Yj6e6IHQJeX6Ko9Vvlpu', 'admin', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `utang`
--

CREATE TABLE `utang` (
  `id` int(10) UNSIGNED NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `qty` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `total` decimal(10,2) NOT NULL,
  `remaining_balance` decimal(10,2) NOT NULL,
  `due_date` date NOT NULL,
  `status` enum('Unpaid','Paid','Partial') NOT NULL DEFAULT 'Unpaid',
  `created_by` varchar(100) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `utang`
--

INSERT INTO `utang` (`id`, `customer_name`, `product_id`, `qty`, `total`, `remaining_balance`, `due_date`, `status`, `created_by`, `date_created`) VALUES
(6, 'Bababyyy', 2, 1, '12.00', '12.00', '2026-08-29', 'Unpaid', 'admin', '2026-08-20 16:15:02'),
(7, 'Bababyyy', 2, 1, '12.00', '0.00', '2026-08-29', 'Paid', 'admin', '2026-08-20 16:15:09'),
(8, 'Jii', 2, 1, '12.00', '7.00', '2026-08-28', 'Partial', 'admin', '2026-08-20 16:16:00'),
(9, 'Hjuan', 1, 1, '15.00', '3.00', '2026-08-23', 'Partial', 'vince_admin', '2026-08-22 15:22:56'),
(10, 'Gh', 2, 1, '12.00', '12.00', '2026-08-23', 'Unpaid', 'vince_admin', '2026-08-22 21:12:32'),
(11, 'juan', 1, 1, '15.00', '15.00', '2026-08-23', 'Unpaid', 'admin', '2026-08-23 16:34:40');

-- --------------------------------------------------------

--
-- Table structure for table `utang_payments`
--

CREATE TABLE `utang_payments` (
  `id` int(10) UNSIGNED NOT NULL,
  `utang_id` int(10) UNSIGNED NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `remaining_balance` decimal(10,2) NOT NULL,
  `paid_by` varchar(100) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `utang_payments`
--

INSERT INTO `utang_payments` (`id`, `utang_id`, `amount_paid`, `remaining_balance`, `paid_by`, `date_created`) VALUES
(6, 7, '12.00', '0.00', 'admin', '2026-08-20 19:49:33'),
(7, 8, '5.00', '7.00', 'vince_admin', '2026-08-22 00:21:55'),
(8, 9, '12.00', '3.00', 'vince_admin', '2026-08-22 06:12:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventory_checks`
--
ALTER TABLE `inventory_checks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_check_product` (`product_id`),
  ADD KEY `idx_check_date` (`date_created`);

--
-- Indexes for table `license_config`
--
ALTER TABLE `license_config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_product_name` (`product_name`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sales_product` (`product_id`),
  ADD KEY `idx_sales_date` (`date_created`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `utang`
--
ALTER TABLE `utang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_utang_product` (`product_id`),
  ADD KEY `idx_utang_date` (`date_created`),
  ADD KEY `idx_utang_customer` (`customer_name`);

--
-- Indexes for table `utang_payments`
--
ALTER TABLE `utang_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_payment_utang` (`utang_id`),
  ADD KEY `idx_payment_date` (`date_created`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inventory_checks`
--
ALTER TABLE `inventory_checks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `license_config`
--
ALTER TABLE `license_config`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=307;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `utang`
--
ALTER TABLE `utang`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `utang_payments`
--
ALTER TABLE `utang_payments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventory_checks`
--
ALTER TABLE `inventory_checks`
  ADD CONSTRAINT `inventory_checks_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `utang`
--
ALTER TABLE `utang`
  ADD CONSTRAINT `utang_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `utang_payments`
--
ALTER TABLE `utang_payments`
  ADD CONSTRAINT `utang_payments_ibfk_1` FOREIGN KEY (`utang_id`) REFERENCES `utang` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
