-- Fix database columns that have DEFAULT CURRENT_TIMESTAMP overriding our system time values
-- This removes the defaults so our explicit date_created values are used

-- Fix sales table
ALTER TABLE sales 
MODIFY COLUMN date_created DATETIME NOT NULL;

-- Fix utang table  
ALTER TABLE utang 
MODIFY COLUMN date_created DATETIME NOT NULL;

-- Fix inventory_checks table
ALTER TABLE inventory_checks 
MODIFY COLUMN date_created DATETIME NOT NULL;

-- Fix utang_payments table if it has date_created
ALTER TABLE utang_payments 
MODIFY COLUMN date_created DATETIME NOT NULL;
