<?php
// app.php
// Application settings that can be safely overwritten during OTA updates

define('APP_NAME', 'StoreTap');
define('APP_VERSION', 'v2.1.0.12.5');

// StoreTap Central Licensing Server URL
define('LICENSE_SERVER_URL', 'https://storetap-central.vercel.app');
