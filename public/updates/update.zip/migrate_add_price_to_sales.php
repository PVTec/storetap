<?php
// Migration: Add price column to sales table
// Run this file to update existing database

require_once __DIR__ . '/config.php';

try {
    // Check if price column exists
    $check = $pdo->query("SHOW COLUMNS FROM sales LIKE 'price'");
    if ($check->rowCount() > 0) {
        echo "Price column already exists in sales table.\n";
    } else {
        // Add price column
        $pdo->exec("ALTER TABLE sales ADD COLUMN price DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER original_qty");
        echo "✅ Successfully added 'price' column to sales table.\n";
    }
    
    // Update existing sales records to have price from products table
    $stmt = $pdo->query("
        UPDATE sales s 
        JOIN products p ON s.product_id = p.id 
        SET s.price = p.price 
        WHERE s.price = 0
    ");
    $updated = $stmt->rowCount();
    echo "✅ Updated {$updated} existing sales records with product prices.\n";
    
    echo "\nMigration completed successfully!\n";
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
