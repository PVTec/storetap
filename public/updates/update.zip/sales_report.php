<?php
require_once __DIR__ . '/layout.php';
requireLogin();
requireAdmin();

$today = getSystemTime('Y-m-d');

$salesSummary = $pdo->prepare('SELECT COUNT(*) AS total_items, SUM(total) AS total_income FROM sales WHERE DATE(date_created) = :today');
$salesSummary->execute(['today' => $today]);
$salesSummary = $salesSummary->fetch();

$todaySales = $pdo->prepare('SELECT s.*, p.product_name FROM sales s JOIN products p ON s.product_id = p.id WHERE DATE(s.date_created) = :today ORDER BY s.date_created DESC');
$todaySales->execute(['today' => $today]);
$todaySales = $todaySales->fetchAll();

$todayUtang = $pdo->prepare('SELECT u.*, p.product_name FROM utang u JOIN products p ON u.product_id = p.id WHERE DATE(u.date_created) = :today ORDER BY u.date_created DESC');
$todayUtang->execute(['today' => $today]);
$todayUtang = $todayUtang->fetchAll();

page_header('Sales Report', 'reports');
?>
<div class="page-header">
    <h2>Reports</h2>
    <p>Daily sales and utang overview.</p>
</div>

<div class="row g-2 g-md-3 mb-4">
    <div class="col-4">
        <div class="card stat-card">
            <div class="stat-label">Items Sold</div>
            <div class="stat-value"><?= intval($salesSummary['total_items'] ?? 0) ?></div>
        </div>
    </div>
    <div class="col-4">
        <div class="card stat-card">
            <div class="stat-label">Cash Income</div>
            <div class="stat-value">₱<?= number_format($salesSummary['total_income'] ?? 0, 0) ?></div>
        </div>
    </div>
    <div class="col-4">
        <div class="card stat-card">
            <div class="stat-label">Utang Added</div>
            <div class="stat-value"><?= count($todayUtang) ?></div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-12 col-lg-6">
        <div class="card p-3">
            <h5 class="mb-3 fw-bold">Today's Cash Sales</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Qty</th>
                            <th>Total</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($todaySales)): ?>
                            <tr><td colspan="4" class="text-center text-muted">No cash sales recorded today.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($todaySales as $sale): ?>
                            <tr>
                                <td><?= sanitize($sale['product_name']) ?></td>
                                <td><?= intval($sale['qty']) ?></td>
                                <td>₱ <?= number_format($sale['total'], 2) ?></td>
                                <td><?= date('H:i:s', strtotime($sale['date_created'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-6">
        <div class="card p-3">
            <h5 class="mb-3 fw-bold">Today's Utang</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Customer</th>
                            <th>Product</th>
                            <th>Total</th>
                            <th>Due Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($todayUtang)): ?>
                            <tr><td colspan="5" class="text-center text-muted">No utang records for today.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($todayUtang as $utang): ?>
                            <tr>
                                <td><?= sanitize($utang['customer_name']) ?></td>
                                <td><?= sanitize($utang['product_name']) ?></td>
                                <td>₱ <?= number_format($utang['total'], 2) ?></td>
                                <td><?= sanitize($utang['due_date']) ?></td>
                                <td><span class="badge <?= $utang['status'] === 'Paid' ? 'bg-success' : 'bg-warning text-dark' ?>"><?= sanitize($utang['status']) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php page_footer();
