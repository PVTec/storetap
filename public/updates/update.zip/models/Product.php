<?php
// models/Product.php
require_once __DIR__ . '/BaseModel.php';

class Product extends BaseModel {
    public function getAll($limit = 0, $offset = 0) {
        if ($limit > 0) {
            $stmt = $this->pdo->prepare('SELECT * FROM products ORDER BY product_name ASC LIMIT :limit OFFSET :offset');
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetchAll();
        }

        return $this->pdo->query('SELECT * FROM products ORDER BY product_name ASC')->fetchAll();
    }

    public function getCount() {
        $stmt = $this->pdo->query('SELECT COUNT(*) as total FROM products');
        $result = $stmt->fetch();
        return intval($result['total'] ?? 0);
    }

    public function getById($id) {
        $stmt = $this->pdo->prepare('SELECT * FROM products WHERE id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function create($name, $price, $stock, $image = null) {
        $stmt = $this->pdo->prepare('INSERT INTO products (product_name, price, stock_qty, initial_stock, total_units_added, image) VALUES (:name, :price, :stock, :initial_stock, :total_units, :image)');
        return $stmt->execute([
            'name' => $name,
            'price' => $price,
            'stock' => $stock,
            'initial_stock' => $stock,
            'total_units' => $stock,
            'image' => $image
        ]);
    }

    public function update($id, $name, $price, $stock, $image = null) {
        $stmt = $this->pdo->prepare('UPDATE products SET product_name = :name, price = :price, stock_qty = :stock, image = :image WHERE id = :id');
        return $stmt->execute(['name' => $name, 'price' => $price, 'stock' => $stock, 'image' => $image, 'id' => $id]);
    }

    public function delete($id) {
        try {
            $this->pdo->beginTransaction();
            // First delete related utang records
            $stmt = $this->pdo->prepare('DELETE FROM utang WHERE product_id = :id');
            $stmt->execute(['id' => $id]);
            // Delete related sales records
            $stmt = $this->pdo->prepare('DELETE FROM sales WHERE product_id = :id');
            $stmt->execute(['id' => $id]);
            // Now delete the product
            $stmt = $this->pdo->prepare('DELETE FROM products WHERE id = :id');
            $result = $stmt->execute(['id' => $id]);
            $this->pdo->commit();
            return $result;
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    public function clearAll() {
        try {
            $this->pdo->beginTransaction();
            $this->pdo->exec('DELETE FROM utang');
            $this->pdo->exec('DELETE FROM sales');
            $this->pdo->exec('DELETE FROM products');
            $this->pdo->commit();
            return true;
        } catch (PDOException $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    public function deductStock($id, $qty = 1) {
        $stmt = $this->pdo->prepare('UPDATE products SET stock_qty = stock_qty - :qty WHERE id = :id');
        return $stmt->execute(['qty' => $qty, 'id' => $id]);
    }

    public function addStock($id, $qty) {
        $stmt = $this->pdo->prepare('UPDATE products SET stock_qty = stock_qty + :qty, total_units_added = total_units_added + :qty2 WHERE id = :id');
        $stmt->bindValue(':qty', $qty, PDO::PARAM_INT);
        $stmt->bindValue(':qty2', $qty, PDO::PARAM_INT);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function getInventoryStats() {
        return $this->pdo->query('
            SELECT 
                COUNT(*) as total_products,
                SUM(total_units_added) as total_units_ever,
                SUM(stock_qty * price) as expected_income,
                SUM(stock_qty) as current_stock
            FROM products
        ')->fetch();
    }

    public function restoreStock($id, $qty) {
        $stmt = $this->pdo->prepare('UPDATE products SET stock_qty = stock_qty + :qty WHERE id = :id');
        return $stmt->execute(['qty' => $qty, 'id' => $id]);
    }

    public function updateStock($id, $newQty) {
        $stmt = $this->pdo->prepare('UPDATE products SET stock_qty = :stock WHERE id = :id');
        return $stmt->execute(['stock' => $newQty, 'id' => $id]);
    }

    public function logInventoryCheck($productId, $expectedQty, $actualQty, $missingQty, $checkedBy, $notes = null) {
        $stmt = $this->pdo->prepare('INSERT INTO inventory_checks (product_id, expected_qty, actual_qty, missing_qty, checked_by, notes, date_created) VALUES (:product_id, :expected_qty, :actual_qty, :missing_qty, :checked_by, :notes, :date_created)');
        return $stmt->execute([
            'product_id' => $productId,
            'expected_qty' => $expectedQty,
            'actual_qty' => $actualQty,
            'missing_qty' => $missingQty,
            'checked_by' => $checkedBy,
            'notes' => $notes,
            'date_created' => getSystemTime('Y-m-d H:i:s')
        ]);
    }

    public function getInventoryChecks($productId = null) {
        if ($productId) {
            $stmt = $this->pdo->prepare('SELECT c.*, p.product_name FROM inventory_checks c JOIN products p ON c.product_id = p.id WHERE c.product_id = :product_id ORDER BY c.date_created DESC');
            $stmt->execute(['product_id' => $productId]);
        } else {
            $stmt = $this->pdo->query('SELECT c.*, p.product_name FROM inventory_checks c JOIN products p ON c.product_id = p.id ORDER BY c.date_created DESC');
        }
        return $stmt->fetchAll();
    }

    public function getLastInventoryCheck($productId) {
        $stmt = $this->pdo->prepare('SELECT * FROM inventory_checks WHERE product_id = :product_id ORDER BY date_created DESC LIMIT 1');
        $stmt->execute(['product_id' => $productId]);
        return $stmt->fetch();
    }

    public function getInventoryChecksForRange($startDate, $endDate) {
        $stmt = $this->pdo->prepare('SELECT c.*, p.product_name FROM inventory_checks c JOIN products p ON c.product_id = p.id WHERE DATE(c.date_created) BETWEEN :start AND :end ORDER BY c.date_created DESC');
        $stmt->execute(['start' => $startDate, 'end' => $endDate]);
        return $stmt->fetchAll();
    }
}
