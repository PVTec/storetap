<?php
// models/Utang.php
require_once __DIR__ . '/BaseModel.php';

class Utang extends BaseModel {
    public function create($customerName, $productId, $qty, $total, $dueDate, $createdBy = null) {
        $stmt = $this->pdo->prepare('INSERT INTO utang (customer_name, product_id, qty, total, remaining_balance, due_date, created_by, date_created) VALUES (:customer_name, :product_id, :qty, :total, :remaining_balance, :due_date, :created_by, :date_created)');
        return $stmt->execute([
            'customer_name' => $customerName,
            'product_id' => $productId,
            'qty' => $qty,
            'total' => $total,
            'remaining_balance' => $total,
            'due_date' => $dueDate,
            'created_by' => $createdBy,
            'date_created' => getSystemTime('Y-m-d H:i:s')
        ]);
    }

    public function getAll() {
        return $this->pdo->query('SELECT u.*, p.product_name FROM utang u JOIN products p ON u.product_id = p.id ORDER BY u.date_created DESC')->fetchAll();
    }

    public function getById($id) {
        $stmt = $this->pdo->prepare('SELECT u.*, p.product_name FROM utang u JOIN products p ON u.product_id = p.id WHERE u.id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function markPaid($id) {
        $stmt = $this->pdo->prepare('UPDATE utang SET status = "Paid", remaining_balance = 0 WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    public function addPayment($utangId, $amountPaid, $remainingBalance, $paidBy) {
        $stmt = $this->pdo->prepare('INSERT INTO utang_payments (utang_id, amount_paid, remaining_balance, paid_by) VALUES (:utang_id, :amount_paid, :remaining_balance, :paid_by)');
        return $stmt->execute([
            'utang_id' => $utangId,
            'amount_paid' => $amountPaid,
            'remaining_balance' => $remainingBalance,
            'paid_by' => $paidBy
        ]);
    }

    public function updateBalance($utangId, $remainingBalance, $status) {
        $stmt = $this->pdo->prepare('UPDATE utang SET remaining_balance = :remaining_balance, status = :status WHERE id = :id');
        return $stmt->execute([
            'id' => $utangId,
            'remaining_balance' => $remainingBalance,
            'status' => $status
        ]);
    }

    public function getPayments($utangId) {
        $stmt = $this->pdo->prepare('SELECT * FROM utang_payments WHERE utang_id = :utang_id ORDER BY date_created DESC');
        $stmt->execute(['utang_id' => $utangId]);
        return $stmt->fetchAll();
    }

    public function getUtangForRange($startDate, $endDate) {
        $stmt = $this->pdo->prepare('SELECT u.*, p.product_name FROM utang u JOIN products p ON u.product_id = p.id WHERE DATE(u.date_created) BETWEEN :start AND :end ORDER BY u.date_created DESC');
        $stmt->execute(['start' => $startDate, 'end' => $endDate]);
        return $stmt->fetchAll();
    }

    public function clearAll() {
        return $this->pdo->exec('DELETE FROM utang');
    }

    public function getTodayCount($today = null) {
        if (!$today) {
            $today = date('Y-m-d');
        }
        $stmt = $this->pdo->prepare('SELECT COUNT(*) AS total_utang FROM utang WHERE DATE(date_created) = :today');
        $stmt->execute(['today' => $today]);
        return $stmt->fetch()['total_utang'];
    }
}
