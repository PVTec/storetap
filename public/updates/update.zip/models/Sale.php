<?php
// models/Sale.php
require_once __DIR__ . '/BaseModel.php';

class Sale extends BaseModel {
    public function create($productId, $qty, $price, $total, $createdBy = null) {
        $systemTime = getSystemTime('Y-m-d H:i:s');
        error_log("Sale::create() - System time: " . $systemTime . " | Offset: " . ($_SESSION['manual_time_offset'] ?? 'NOT SET'));
        $stmt = $this->pdo->prepare('INSERT INTO sales (product_id, qty, original_qty, price, total, created_by, date_created) VALUES (:product_id, :qty, :original_qty, :price, :total, :created_by, :date_created)');
        return $stmt->execute([
            'product_id' => $productId,
            'qty' => $qty,
            'original_qty' => $qty,
            'price' => $price,
            'total' => $total,
            'created_by' => $createdBy,
            'date_created' => $systemTime
        ]);
    }

    public function getStatsForRange($startDate, $endDate) {
        $stmt = $this->pdo->prepare('SELECT SUM(qty) AS total_items, SUM(total) AS total_income FROM sales WHERE DATE(date_created) BETWEEN :start AND :end');
        $stmt->execute(['start' => $startDate, 'end' => $endDate]);
        return $stmt->fetch();
    }

    public function getSalesForRange($startDate, $endDate) {
        $stmt = $this->pdo->prepare('SELECT s.*, p.product_name FROM sales s JOIN products p ON s.product_id = p.id WHERE DATE(s.date_created) BETWEEN :start AND :end ORDER BY s.date_created DESC');
        $stmt->execute(['start' => $startDate, 'end' => $endDate]);
        return $stmt->fetchAll();
    }

    public function getSalesByUser($username, $date) {
        $stmt = $this->pdo->prepare('SELECT s.*, p.product_name, p.price FROM sales s JOIN products p ON s.product_id = p.id WHERE s.created_by = :username AND DATE(s.date_created) = :date ORDER BY s.date_created DESC');
        $stmt->execute(['username' => $username, 'date' => $date]);
        return $stmt->fetchAll();
    }

    public function getAllSales($date = null) {
        if ($date) {
            $stmt = $this->pdo->prepare('SELECT s.*, p.product_name, p.price FROM sales s JOIN products p ON s.product_id = p.id WHERE DATE(s.date_created) = :date ORDER BY s.date_created DESC');
            $stmt->execute(['date' => $date]);
        } else {
            $stmt = $this->pdo->query('SELECT s.*, p.product_name, p.price FROM sales s JOIN products p ON s.product_id = p.id ORDER BY s.date_created DESC');
        }
        return $stmt->fetchAll();
    }

    public function getSaleById($id) {
        $stmt = $this->pdo->prepare('SELECT s.*, p.product_name, p.price FROM sales s JOIN products p ON s.product_id = p.id WHERE s.id = :id LIMIT 1');
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }

    public function updateSale($id, $newQty, $newTotal, $note = null) {
        $stmt = $this->pdo->prepare('UPDATE sales SET qty = :qty, total = :total, notes = :notes WHERE id = :id');
        return $stmt->execute([
            'id' => $id,
            'qty' => $newQty,
            'total' => $newTotal,
            'notes' => $note
        ]);
    }

    public function updateSalePrice($id, $newPrice, $newTotal, $note = null) {
        $stmt = $this->pdo->prepare('UPDATE sales SET price = :price, total = :total, notes = :notes WHERE id = :id');
        return $stmt->execute([
            'id' => $id,
            'price' => $newPrice,
            'total' => $newTotal,
            'notes' => $note
        ]);
    }

    public function deleteSale($id) {
        $stmt = $this->pdo->prepare('DELETE FROM sales WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    public function clearAll() {
        return $this->pdo->exec('DELETE FROM sales');
    }

    public function getRecentSales($limit = 5) {
        $stmt = $this->pdo->prepare('SELECT s.*, p.product_name FROM sales s JOIN products p ON s.product_id = p.id ORDER BY s.date_created DESC LIMIT :limit');
        $stmt->bindValue(':limit', (int) $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getTodayStats($today = null) {
        if (!$today) {
            $today = date('Y-m-d');
        }
        $stmt = $this->pdo->prepare('SELECT SUM(qty) AS total_items, SUM(total) AS total_income FROM sales WHERE DATE(date_created) = :today');
        $stmt->execute(['today' => $today]);
        return $stmt->fetch();
    }
}
