<?php
// models/User.php
require_once __DIR__ . '/BaseModel.php';

class User extends BaseModel {
    public function authenticate($username, $password) {
        $stmt = $this->pdo->prepare('SELECT id, username, password, role, current_session_id, (last_active >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)) AS is_recently_active FROM users WHERE username = :username LIMIT 1');
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }
        return false;
    }

    public function getUserByUsername($username) {
        $stmt = $this->pdo->prepare('SELECT id, username, role, last_active, current_session_id FROM users WHERE username = :username LIMIT 1');
        $stmt->execute(['username' => $username]);
        return $stmt->fetch();
    }

    public function getAll() {
        return $this->pdo->query('SELECT id, username, role FROM users ORDER BY username ASC')->fetchAll();
    }

    public function create($username, $password, $role) {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->pdo->prepare('INSERT INTO users (username, password, role) VALUES (:username, :password, :role)');
        return $stmt->execute(['username' => $username, 'password' => $hash, 'role' => $role]);
    }

    public function update($id, $username, $password, $role) {
        if ($password) {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $this->pdo->prepare('UPDATE users SET username = :username, password = :password, role = :role WHERE id = :id');
            return $stmt->execute(['username' => $username, 'password' => $hash, 'role' => $role, 'id' => $id]);
        } else {
            $stmt = $this->pdo->prepare('UPDATE users SET username = :username, role = :role WHERE id = :id');
            return $stmt->execute(['username' => $username, 'role' => $role, 'id' => $id]);
        }
    }

    public function delete($id) {
        $stmt = $this->pdo->prepare('DELETE FROM users WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    public function updateLastActive($id) {
        $stmt = $this->pdo->prepare('UPDATE users SET last_active = NOW() WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    public function getOnlineUsers() {
        // Users active within the last 5 minutes
        $stmt = $this->pdo->prepare("SELECT username FROM users WHERE last_active >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    public function setSession($id, $sessionId) {
        $stmt = $this->pdo->prepare('UPDATE users SET current_session_id = :session_id, login_attempt_flag = 0 WHERE id = :id');
        return $stmt->execute(['session_id' => $sessionId, 'id' => $id]);
    }

    public function clearSession($id) {
        $stmt = $this->pdo->prepare('UPDATE users SET current_session_id = NULL WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    public function flagLoginAttempt($id) {
        $stmt = $this->pdo->prepare('UPDATE users SET login_attempt_flag = 1 WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    public function checkAndClearLoginFlag($id) {
        $stmt = $this->pdo->prepare('SELECT login_attempt_flag FROM users WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $flag = $stmt->fetchColumn();
        
        if ($flag) {
            // Clear it so it only shows once
            $this->pdo->prepare('UPDATE users SET login_attempt_flag = 0 WHERE id = :id')->execute(['id' => $id]);
            return true;
        }
        return false;
    }
}
