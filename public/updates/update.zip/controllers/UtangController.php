<?php
// controllers/UtangController.php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/Utang.php';

class UtangController extends BaseController {
    public function records() {
        requireLogin();

        $utangModel = new Utang($this->pdo);
        $flash = consumeFlash();
        $currentUser = $_SESSION['user']['username'] ?? '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
            $action = $_POST['action'];

            if ($action === 'mark_paid' && isLoggedIn()) {
                $utangId = intval($_POST['utang_id'] ?? 0);
                if ($utangId > 0) {
                    $utangModel->markPaid($utangId);
                    flash('Utang marked as paid.', 'success');
                }
                $this->redirect('index.php?page=utang_records');
            }

            if ($action === 'add_payment' && isLoggedIn()) {
                $utangId = intval($_POST['utang_id'] ?? 0);
                $paymentAmount = floatval($_POST['payment_amount'] ?? 0);

                if ($utangId > 0 && $paymentAmount > 0) {
                    $utang = $utangModel->getById($utangId);

                    if ($utang && $utang['status'] !== 'Paid') {
                        $currentBalance = floatval($utang['remaining_balance']);

                        if ($paymentAmount >= $currentBalance) {
                            // Full payment - mark as paid
                            $utangModel->addPayment($utangId, $paymentAmount, 0, $currentUser);
                            $utangModel->markPaid($utangId);
                            flash('Payment recorded. Utang fully paid.', 'success');
                        } else {
                            // Partial payment
                            $newBalance = $currentBalance - $paymentAmount;
                            $utangModel->addPayment($utangId, $paymentAmount, $newBalance, $currentUser);
                            $utangModel->updateBalance($utangId, $newBalance, 'Partial');
                            flash('Partial payment recorded. Remaining balance: ₱' . number_format($newBalance, 2), 'success');
                        }
                    } else {
                        flash('Invalid utang record or already paid.', 'danger');
                    }
                } else {
                    flash('Invalid payment amount.', 'danger');
                }
                $this->redirect('index.php?page=utang_records');
            }
        }

        // Get payment history for a specific utang if requested
        $viewUtangId = intval($_GET['view_payments'] ?? 0);
        $paymentHistory = [];
        $viewUtang = null;

        if ($viewUtangId > 0) {
            $viewUtang = $utangModel->getById($viewUtangId);
            if ($viewUtang) {
                $paymentHistory = $utangModel->getPayments($viewUtangId);
            }
        }

        $utangRecords = $utangModel->getAll();

        $this->render('pages/utang_records', [
            'flash' => $flash,
            'utangRecords' => $utangRecords,
            'paymentHistory' => $paymentHistory,
            'viewUtang' => $viewUtang,
            'viewUtangId' => $viewUtangId
        ], 'Utang Records');
    }
}
