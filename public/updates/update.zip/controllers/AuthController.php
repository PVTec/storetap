<?php
// controllers/AuthController.php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/User.php';

class AuthController extends BaseController {
    public function login() {
        if (isLoggedIn()) {
            $this->redirect('index.php?page=dashboard');
        }

        $error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';

            if ($username === '' || $password === '') {
                $error = 'Please enter your username and password.';
            } else {
                $userModel = new User($this->pdo);
                $user = $userModel->authenticate($username, $password);
                if ($user) {
                    // Check for active session conflict
                    $isRecentlyActive = (bool) $user['is_recently_active'];
                    $hasSession = !empty($user['current_session_id']);
                    $isDifferentDevice = session_id() !== $user['current_session_id'];

                    if ($isRecentlyActive && $hasSession && $isDifferentDevice) {
                        // Conflict detected!
                        $userModel->flagLoginAttempt($user['id']);
                        $error = 'CONFLICT';
                    } else {
                        // Login successful
                        $_SESSION['user'] = [
                            'id' => $user['id'],
                            'username' => $user['username'],
                            'role' => $user['role'],
                        ];
                        // Register session
                        $userModel->setSession($user['id'], session_id());
                        $this->redirect('index.php?page=dashboard');
                    }
                } else {
                    $error = 'Invalid username or password.';
                }
            }
        }

        // Render login without sidebar
        extract(['error' => $error, 'title' => 'Login']);
        require_once __DIR__ . '/../views/pages/login.php';
    }

    public function logout() {
        if (isset($_SESSION['user']['id'])) {
            $userModel = new User($this->pdo);
            $userModel->clearSession($_SESSION['user']['id']);
        }
        session_unset();
        session_destroy();
        $this->redirect('index.php?page=login');
    }

    public function checkConflict() {
        header('Content-Type: application/json');
        if (!isLoggedIn()) {
            echo json_encode(['conflict' => false]);
            exit;
        }

        $userModel = new User($this->pdo);
        $hasConflict = $userModel->checkAndClearLoginFlag($_SESSION['user']['id']);
        
        echo json_encode(['conflict' => $hasConflict]);
        exit;
    }
}
