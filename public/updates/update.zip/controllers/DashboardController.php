<?php
// controllers/DashboardController.php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/Sale.php';
require_once __DIR__ . '/../models/Utang.php';

class DashboardController extends BaseController {
    public function index() {
        requireLogin();

        $flash = consumeFlash();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        }

        $productModel = new Product($this->pdo);
        $saleModel = new Sale($this->pdo);
        $utangModel = new Utang($this->pdo);

        $products = $productModel->getAll();
        // Sort products by stock quantity descending (more stock first)
        usort($products, function($a, $b) {
            return $b['stock_qty'] <=> $a['stock_qty'];
        });
        $today = getSystemTime('Y-m-d');
        $statsData = $saleModel->getStatsForRange($today, $today);
        $utangData = $utangModel->getTodayCount($today);
        $lowStockCount = $this->getLowStockCount();
        $recentSales = $saleModel->getRecentSales(5);
        
        // Calculate totals for instant updates
        $todayIncome = floatval($statsData['total_income'] ?? 0);
        $todayItems = intval($statsData['total_items'] ?? 0);
        $totalStock = $this->getTotalStock($products);

        $this->render('pages/dashboard', [
            'flash' => $flash,
            'products' => $products,
            'statsData' => $statsData,
            'utangData' => $utangData,
            'lowStockCount' => $lowStockCount,
            'recentSales' => $recentSales,
            'todayIncome' => $todayIncome,
            'todayItems' => $todayItems,
            'totalStock' => $totalStock,
        ], 'Dashboard');
    }

    private function handlePost() {
        $action = $_POST['action'] ?? '';
        
        $productModel = new Product($this->pdo);
        $currentUser = currentUser();
        $createdBy = $currentUser['username'] ?? 'system';

        if ($action === 'sale') {
            $productId = intval($_POST['product_id'] ?? 0);
            if ($productId <= 0) {
                flash('Invalid product selection.', 'danger');
                $this->redirect('index.php?page=dashboard');
            }
            $product = $productModel->getById($productId);
            if (!$product) {
                flash('Product not found.', 'danger');
                $this->redirect('index.php?page=dashboard');
            }
            if ($product['stock_qty'] <= 0) {
                flash('Cannot transact. Product is out of stock.', 'danger');
                $this->redirect('index.php?page=dashboard');
            }
            
            try {
                $this->pdo->beginTransaction();
                $productModel->deductStock($productId);
                $saleModel = new Sale($this->pdo);
                $saleModel->create($productId, 1, $product['price'], $product['price'], $createdBy);
                $this->pdo->commit();
                flash('Cash sale recorded successfully.', 'success');
            } catch (Exception $e) {
                $this->pdo->rollBack();
                flash('Unable to save sale: ' . $e->getMessage(), 'danger');
            }
        } elseif ($action === 'utang') {
            $productId = intval($_POST['product_id'] ?? 0);
            if ($productId <= 0) {
                flash('Invalid product selection.', 'danger');
                $this->redirect('index.php?page=dashboard');
            }
            $product = $productModel->getById($productId);
            if (!$product) {
                flash('Product not found.', 'danger');
                $this->redirect('index.php?page=dashboard');
            }
            if ($product['stock_qty'] <= 0) {
                flash('Cannot transact. Product is out of stock.', 'danger');
                $this->redirect('index.php?page=dashboard');
            }
            
            $customerName = trim($_POST['customer_name'] ?? '');
            $dueDate = $_POST['due_date'] ?? '';

            if ($customerName === '' || $dueDate === '') {
                flash('Customer name and due date are required for utang.', 'danger');
                $this->redirect('index.php?page=dashboard');
            }

            try {
                $this->pdo->beginTransaction();
                $productModel->deductStock($productId);
                $utangModel = new Utang($this->pdo);
                $utangModel->create($customerName, $productId, 1, $product['price'], $dueDate, $createdBy);
                $this->pdo->commit();
                flash('Utang recorded successfully.', 'success');
            } catch (Exception $e) {
                $this->pdo->rollBack();
                flash('Unable to save utang: ' . $e->getMessage(), 'danger');
            }
        } elseif ($action === 'undo_sale') {
            $saleId = intval($_POST['sale_id'] ?? 0);
            if ($saleId <= 0) {
                flash('Invalid sale to undo.', 'danger');
                $this->redirect('index.php?page=dashboard');
            }

            $saleModel = new Sale($this->pdo);
            $sale = $saleModel->getSaleById($saleId);

            if (!$sale) {
                flash('Sale not found.', 'danger');
                $this->redirect('index.php?page=dashboard');
            }

            // Check permissions - staff can only undo their own sales
            $currentUser = currentUser();
            $isAdmin = isAdmin();
            $isOwnSale = $sale['created_by'] === ($currentUser['username'] ?? 'system');
            
            if (!$isAdmin && !$isOwnSale) {
                flash('You can only undo your own sales.', 'danger');
                $this->redirect('index.php?page=dashboard');
            }

            try {
                $this->pdo->beginTransaction();
                // Restore stock
                $productModel->addStock($sale['product_id'], $sale['qty']);
                // Delete the sale completely (remove from records)
                $saleModel->deleteSale($saleId);
                $this->pdo->commit();
                flash('Sale removed: ' . sanitize($sale['product_name']) . ' - Stock restored.', 'success');
            } catch (Exception $e) {
                $this->pdo->rollBack();
                flash('Unable to undo sale: ' . $e->getMessage(), 'danger');
            }
        } elseif ($action === 'fast_sale') {
            $cartData = json_decode($_POST['cart_data'] ?? '[]', true);
            $paymentAmount = floatval($_POST['payment_amount'] ?? 0);
            
            if (empty($cartData) || !is_array($cartData)) {
                flash('No items in cart.', 'danger');
                $this->redirect('index.php?page=dashboard');
            }
            
            $saleModel = new Sale($this->pdo);
            $totalAmount = 0;
            $saleCount = 0;
            
            try {
                $this->pdo->beginTransaction();
                
                foreach ($cartData as $item) {
                    $productId = intval($item['productId'] ?? 0);
                    $qty = intval($item['qty'] ?? 1);
                    $price = floatval($item['price'] ?? 0);
                    $total = $price * $qty;
                    
                    if ($productId <= 0 || $qty <= 0 || $price <= 0) {
                        continue;
                    }
                    
                    $product = $productModel->getById($productId);
                    if (!$product || $product['stock_qty'] < $qty) {
                        throw new Exception('Insufficient stock for: ' . ($product['product_name'] ?? 'Product'));
                    }
                    
                    // Deduct stock
                    $productModel->deductStock($productId, $qty);
                    
                    // Create sale with specified qty
                    $saleModel->create($productId, $qty, $price, $total, $createdBy);
                    
                    $totalAmount += $total;
                    $saleCount++;
                }
                
                if ($saleCount === 0) {
                    throw new Exception('No valid items to process.');
                }
                
                $change = $paymentAmount - $totalAmount;
                
                $this->pdo->commit();
                flash("Fast sale completed! {$saleCount} item(s) sold. Total: ₱{$totalAmount}, Change: ₱{$change}", 'success');
            } catch (Exception $e) {
                $this->pdo->rollBack();
                flash('Fast sale failed: ' . $e->getMessage(), 'danger');
            }
        }

        $this->redirect('index.php?page=dashboard');
    }

    private function getTotalStock($products) {
        return array_sum(array_column($products, 'stock_qty'));
    }

    private function getLowStockCount() {
        $stmt = $this->pdo->prepare('SELECT COUNT(*) FROM products WHERE stock_qty <= 5');
        $stmt->execute();
        return $stmt->fetchColumn();
    }
}
