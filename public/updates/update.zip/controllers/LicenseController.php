<?php

require_once __DIR__ . '/BaseController.php';

class LicenseController extends BaseController
{
    public function index(): void
    {
        requireAdmin();

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'activate') {
            $this->handleActivation();
            return;
        }

        // Fetch current license
        $currentLicense = self::getCurrentLicense($this->pdo);

        $this->render('pages/license', [
            'currentLicense' => $currentLicense
        ], 'License Management');
    }

    private function handleActivation(): void
    {
        $key = trim($_POST['license_key'] ?? '');
        if (empty($key)) {
            flash('Please enter a valid license key.', 'danger');
            header('Location: index.php?page=license');
            exit;
        }

        $keyUpper = strtoupper($key);
        $deviceId = $this->getDeviceId();
        $websiteUrl = $_SERVER['HTTP_HOST'] ?? 'unknown';

        // cURL to the Central License Server
        $apiUrl = defined('LICENSE_SERVER_URL') ? LICENSE_SERVER_URL . '/api/verify' : 'http://localhost:3000/api/verify';
        
        $ch = curl_init($apiUrl);
        $payload = json_encode(['key' => $keyUpper, 'deviceId' => $deviceId, 'websiteUrl' => $websiteUrl]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type:application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if (!$response) {
            flash('Failed to connect to the license server. Please check your internet connection.', 'danger');
            header('Location: index.php?page=license');
            exit;
        }

        $data = json_decode($response, true);

        if ($httpCode !== 200 || !isset($data['status']) || $data['status'] !== 'valid') {
            $msg = $data['message'] ?? 'Invalid license key.';
            flash($msg, 'danger');
            header('Location: index.php?page=license');
            exit;
        }

        // License is Valid
        $type = $data['tier'] ?? 'basic';
        $expiresAt = date('Y-m-d H:i:s', strtotime($data['expiresAt']));
        
        // Define offline and premium based on tier
        $offlineDashboard = ($type === 'pro') ? 1 : 0;
        $premiumThemes = ($type === 'pro' || $type === 'standard') ? 1 : 0;

        flash("License activated successfully! Expires on " . date('M d, Y', strtotime($expiresAt)), 'success');

        // Insert new license record
        $stmt = $this->pdo->prepare("INSERT INTO license_config (license_key, license_type, offline_dashboard, premium_themes, expires_at) VALUES (:key, :type, :offline, :premium, :expires)");
        $stmt->execute([
            'key' => $keyUpper,
            'type' => $type,
            'offline' => $offlineDashboard,
            'premium' => $premiumThemes,
            'expires' => $expiresAt
        ]);

        header('Location: index.php?page=license');
        exit;
    }

    private function getDeviceId(): string
    {
        $idFile = __DIR__ . '/../../device.id';
        if (file_exists($idFile)) {
            return trim(file_get_contents($idFile));
        }
        
        // Generate a simple unique ID for this device installation
        $newId = bin2hex(random_bytes(16));
        file_put_contents($idFile, $newId);
        return $newId;
    }

    public static function getCurrentLicense(PDO $pdo): array
    {
        $stmt = $pdo->query("SELECT * FROM license_config ORDER BY id DESC LIMIT 1");
        $license = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$license) {
            return [
                'license_key' => 'None',
                'license_type' => 'basic',
                'offline_dashboard' => 0,
                'premium_themes' => 0,
                'expires_at' => date('Y-m-d H:i:s', strtotime('-1 day')),
                'is_expired' => true
            ];
        }

        $license['is_expired'] = (strtotime($license['expires_at']) < getSystemTimestamp());
        return $license;
    }
}
