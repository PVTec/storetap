<?php
// controllers/ProductController.php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/Product.php';

class ProductController extends BaseController {
    public function manage() {
        requireLogin();

        $productModel = new Product($this->pdo);
        $flash = consumeFlash();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        }

        $editProduct = null;
        if (isset($_GET['edit'])) {
            $editProduct = $productModel->getById(intval($_GET['edit']));
        }

        $currentPage = max(1, intval($_GET['page_num'] ?? 1));
        $limit = 25;
        $totalProducts = $productModel->getCount();
        $totalPages = max(1, (int) ceil($totalProducts / $limit));
        if ($currentPage > $totalPages) {
            $currentPage = $totalPages;
        }
        $offset = ($currentPage - 1) * $limit;

        $products = $productModel->getAll($limit, $offset);
        // Sort products by stock quantity descending (more stock first)
        usort($products, function($a, $b) {
            return $b['stock_qty'] <=> $a['stock_qty'];
        });

        $this->render('pages/product_manage', [
            'flash' => $flash,
            'editProduct' => $editProduct,
            'products' => $products,
            'currentPage' => $currentPage,
            'totalPages' => $totalPages,
            'totalProducts' => $totalProducts,
            'limit' => $limit,
        ], 'Manage Products');
    }

    private function handlePost() {
        $action = $_POST['action'] ?? '';
        $name = trim($_POST['product_name'] ?? '');
        $price = floatval($_POST['price'] ?? 0);
        $stock = intval($_POST['stock_qty'] ?? 0);
        $productId = intval($_POST['product_id'] ?? 0);

        $imagePath = $this->uploadImage();

        if ($action === 'create') {
            if ($name === '' || $price < 0 || $stock < 0) {
                flash('Please provide valid product details.', 'danger');
            } else {
                $productModel = new Product($this->pdo);
                $productModel->create($name, $price, $stock, $imagePath);
                flash('Product added successfully.', 'success');
            }
        } elseif ($action === 'update' && $productId > 0) {
            if ($name === '' || $price < 0 || $stock < 0) {
                flash('Please provide valid product details.', 'danger');
            } else {
                $productModel = new Product($this->pdo);
                if (!$imagePath) {
                    // Keep existing image
                    $existing = $productModel->getById($productId);
                    $imagePath = $existing['image'];
                }
                $productModel->update($productId, $name, $price, $stock, $imagePath);
                flash('Product updated successfully.', 'success');
            }
        } elseif ($action === 'delete' && $productId > 0) {
            $productModel = new Product($this->pdo);
            $productModel->delete($productId);
            flash('Product deleted.', 'success');
        }

        $this->redirect('index.php?page=product_manage');
    }

    private function uploadImage() {
        if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            return null;
        }

        $uploadDir = __DIR__ . '/../uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        $fileName = uniqid() . '_' . basename($_FILES['image']['name']);
        $targetPath = $uploadDir . $fileName;

        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($_FILES['image']['type'], $allowedTypes)) {
            return null;
        }

        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetPath)) {
            return 'uploads/' . $fileName;
        }

        return null;
    }
}
