<?php
// controllers/InventoryHistoryController.php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/Product.php';

class InventoryHistoryController extends BaseController {
    public function index() {
        requireLogin();
        requireAdmin(); // Only admin can access this page

        $productModel = new Product($this->pdo);
        $flash = consumeFlash();

        // Get all inventory checks
        $inventoryChecks = $productModel->getInventoryChecks();

        // Get all products for filter dropdown
        $products = $productModel->getAll();
        // Sort products by stock quantity descending (more stock first)
        usort($products, function($a, $b) {
            return $b['stock_qty'] <=> $a['stock_qty'];
        });

        // Get unique checkers for filter dropdown
        $checkers = array_unique(array_column($inventoryChecks, 'checked_by'));
        sort($checkers);

        // Apply filters
        $filteredChecks = $inventoryChecks;
        $filterProductId = $_GET['product_id'] ?? '';
        $filterChecker = $_GET['checked_by'] ?? '';
        $dateFrom = $_GET['date_from'] ?? '';
        $dateTo = $_GET['date_to'] ?? '';

        if ($filterProductId) {
            $filteredChecks = array_filter($filteredChecks, fn($c) => $c['product_id'] == $filterProductId);
        }

        if ($filterChecker) {
            $filteredChecks = array_filter($filteredChecks, fn($c) => $c['checked_by'] === $filterChecker);
        }

        if ($dateFrom) {
            $filteredChecks = array_filter($filteredChecks, fn($c) => date('Y-m-d', strtotime($c['date_created'])) >= $dateFrom);
        }

        if ($dateTo) {
            $filteredChecks = array_filter($filteredChecks, fn($c) => date('Y-m-d', strtotime($c['date_created'])) <= $dateTo);
        }

        // Re-index array after filtering
        $filteredChecks = array_values($filteredChecks);

        $today = getSystemTime('Y-m-d');

        $this->render('pages/inventory_history', [
            'flash' => $flash,
            'inventoryChecks' => $inventoryChecks,
            'filteredChecks' => $filteredChecks,
            'products' => $products,
            'checkers' => $checkers,
            'filterProductId' => $filterProductId,
            'filterChecker' => $filterChecker,
            'dateFrom' => $dateFrom,
            'dateTo' => $dateTo,
            'today' => $today
        ], 'Inventory History');
    }
}
