<?php
// controllers/SalesController.php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/Sale.php';
require_once __DIR__ . '/../models/Product.php';

class SalesController extends BaseController {
    public function index() {
        requireLogin();

        $saleModel = new Sale($this->pdo);
        $productModel = new Product($this->pdo);
        $flash = consumeFlash();

        $today = getSystemTime('Y-m-d');
        $currentUser = $_SESSION['user']['username'] ?? '';
        $isAdmin = isAdmin();

        // Handle POST actions
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
            $action = $_POST['action'];

            if ($action === 'edit_sale') {
                $saleId = intval($_POST['sale_id'] ?? 0);
                $customPrice = floatval($_POST['custom_price'] ?? 0);
                $note = trim($_POST['note'] ?? '');

                if ($saleId > 0 && $customPrice >= 0 && $note !== '') {
                    $sale = $saleModel->getSaleById($saleId);

                    if ($sale) {
                        // Check permissions
                        $canEdit = false;
                        if ($isAdmin) {
                            $canEdit = true;
                        } else {
                            // Staff can only edit their own today's sales
                            $saleDate = date('Y-m-d', strtotime($sale['date_created']));
                            $canEdit = ($sale['created_by'] === $currentUser && $saleDate === $today);
                        }

                        if ($canEdit) {
                            $qty = intval($sale['qty']);
                            $newTotal = $qty * $customPrice;
                            $oldPrice = floatval($sale['price']);

                            // Append note to existing notes with price change info
                            $existingNote = $sale['notes'] ?? '';
                            $timestamp = getSystemTime('Y-m-d H:i:s');
                            $priceChangeInfo = "Price changed from ₱{$oldPrice} to ₱{$customPrice}. Reason: {$note}";
                            $fullNote = ($existingNote ? $existingNote . "\n" : '') . "[$timestamp] $currentUser: {$priceChangeInfo}";

                            $saleModel->updateSalePrice($saleId, $customPrice, $newTotal, $fullNote);
                            flash('Sale price updated successfully.', 'success');
                        } else {
                            flash('You do not have permission to edit this sale.', 'danger');
                        }
                    }
                } else {
                    flash('Custom price and note are required.', 'danger');
                }
                $this->redirect('index.php?page=sales');
            }

            if ($action === 'delete_sale') {
                $saleId = intval($_POST['sale_id'] ?? 0);

                if ($saleId > 0) {
                    $sale = $saleModel->getSaleById($saleId);

                    if ($sale) {
                        // Check permissions
                        $canDelete = false;
                        if ($isAdmin) {
                            $canDelete = true;
                        } else {
                            // Staff can only delete their own today's sales
                            $saleDate = date('Y-m-d', strtotime($sale['date_created']));
                            $canDelete = ($sale['created_by'] === $currentUser && $saleDate === $today);
                        }

                        if ($canDelete) {
                            // Restore stock
                            $productModel->restoreStock($sale['product_id'], $sale['qty']);
                            $saleModel->deleteSale($saleId);
                            flash('Sale deleted successfully.', 'success');
                        } else {
                            flash('You do not have permission to delete this sale.', 'danger');
                        }
                    }
                }
                $this->redirect('index.php?page=sales');
            }

            if ($action === 'add_note') {
                $saleId = intval($_POST['sale_id'] ?? 0);
                $note = trim($_POST['note'] ?? '');

                if ($saleId > 0 && $note) {
                    $sale = $saleModel->getSaleById($saleId);

                    if ($sale) {
                        // Check permissions
                        $canEdit = false;
                        if ($isAdmin) {
                            $canEdit = true;
                        } else {
                            $saleDate = date('Y-m-d', strtotime($sale['date_created']));
                            $canEdit = ($sale['created_by'] === $currentUser && $saleDate === $today);
                        }

                        if ($canEdit) {
                            $existingNote = $sale['notes'] ?? '';
                            $timestamp = getSystemTime('Y-m-d H:i:s');
                            $fullNote = ($existingNote ? $existingNote . "\n" : '') . "[$timestamp] $currentUser: $note";

                            $saleModel->updateSale($saleId, $sale['qty'], $sale['total'], $fullNote);
                            flash('Note added successfully.', 'success');
                        } else {
                            flash('You do not have permission to add notes to this sale.', 'danger');
                        }
                    }
                }
                $this->redirect('index.php?page=sales');
            }
        }

        // Get sales based on user role
        if ($isAdmin) {
            // Admin sees all sales
            $filterDate = $_GET['date'] ?? '';
            if ($filterDate) {
                $sales = $saleModel->getAllSales($filterDate);
            } else {
                $sales = $saleModel->getAllSales();
            }
        } else {
            // Staff sees only today's sales for themselves
            $sales = $saleModel->getSalesByUser($currentUser, $today);
        }

        $this->render('pages/sales', [
            'flash' => $flash,
            'sales' => $sales,
            'today' => $today,
            'isAdmin' => $isAdmin,
            'currentUser' => $currentUser,
            'filterDate' => $_GET['date'] ?? ''
        ], 'Sales');
    }
}
