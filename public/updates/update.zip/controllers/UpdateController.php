<?php
// controllers/UpdateController.php

class UpdateController {
    private $pdo;
    private $tmpDir;
    private $updateUrl;

    public function __construct($pdo) {
        $this->pdo = $pdo;
        $this->tmpDir = __DIR__ . '/../tmp';
        // Make sure tmp dir exists
        if (!is_dir($this->tmpDir)) {
            mkdir($this->tmpDir, 0755, true);
        }
        
        // Define the base URL for updates from config
        $this->updateUrl = defined('LICENSE_SERVER_URL') ? LICENSE_SERVER_URL . '/updates' : 'https://storetap-central.vercel.app/updates';
    }

    // 1. Check for updates
    public function check() {
        requireLogin();
        header('Content-Type: application/json');
        
        try {
            $jsonContext = stream_context_create(['http' => ['timeout' => 5]]);
            $versionDataJson = @file_get_contents($this->updateUrl . '/version.json?t=' . time(), false, $jsonContext);
            
            if (!$versionDataJson) {
                echo json_encode(['status' => 'error', 'message' => 'Could not connect to update server.']);
                exit;
            }

            $versionData = json_decode($versionDataJson, true);
            
            if (!$versionData || !isset($versionData['latest_version'])) {
                echo json_encode(['status' => 'error', 'message' => 'Invalid response from update server.']);
                exit;
            }

            $currentVersion = defined('APP_VERSION') ? APP_VERSION : 'v0.0.0';
            $hasUpdate = version_compare($this->normalizeVersion($versionData['latest_version']), $this->normalizeVersion($currentVersion), '>');

            echo json_encode([
                'status' => 'success',
                'has_update' => $hasUpdate,
                'current_version' => $currentVersion,
                'latest_version' => $versionData['latest_version'],
                'changelog' => $versionData['changelog'] ?? 'No changelog provided.',
                'download_url' => $versionData['download_url'] ?? ($this->updateUrl . '/update.zip')
            ]);

        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        exit;
    }

    // 2. Download the update zip
    public function download() {
        requireLogin();
        if (!isAdmin()) {
            echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
            exit;
        }
        
        header('Content-Type: application/json');
        
        try {
            $downloadUrl = $_POST['download_url'] ?? ($this->updateUrl . '/update.zip');
            $zipFile = $this->tmpDir . '/update.zip';

            // Use cURL for better handling of large files if available
            if (function_exists('curl_init')) {
                $fp = fopen($zipFile, 'w+');
                $ch = curl_init($downloadUrl);
                curl_setopt($ch, CURLOPT_TIMEOUT, 300);
                curl_setopt($ch, CURLOPT_FILE, $fp);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                // Also add user agent just in case Vercel blocks empty agents
                curl_setopt($ch, CURLOPT_USERAGENT, 'StoreTap-OTA-Client');
                curl_exec($ch);
                $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                fclose($fp);
                
                if ($httpCode !== 200) {
                    @unlink($zipFile);
                    throw new Exception("Download failed with HTTP code $httpCode");
                }
            } else {
                // Fallback to file_get_contents
                $zipData = @file_get_contents($downloadUrl);
                if ($zipData === false) {
                    throw new Exception("Failed to download update file.");
                }
                file_put_contents($zipFile, $zipData);
            }

            if (!file_exists($zipFile) || filesize($zipFile) === 0) {
                throw new Exception("Downloaded file is empty or missing.");
            }

            echo json_encode(['status' => 'success', 'message' => 'Download complete.']);

        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        exit;
    }

    // 3. Extract the zip and cleanup
    public function extract() {
        requireLogin();
        if (!isAdmin()) {
            echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
            exit;
        }

        header('Content-Type: application/json');
        
        try {
            $zipFile = $this->tmpDir . '/update.zip';
            $extractPath = realpath(__DIR__ . '/../');

            if (!file_exists($zipFile)) {
                throw new Exception("Update file not found. Please try downloading again.");
            }

            if (!class_exists('ZipArchive')) {
                throw new Exception("PHP ZipArchive extension is not installed.");
            }

            $zip = new ZipArchive;
            $res = $zip->open($zipFile);
            if ($res === TRUE) {
                // Extract everything over the current directory
                $zip->extractTo($extractPath);
                $zip->close();
                
                // Cleanup
                @unlink($zipFile);
                
                echo json_encode(['status' => 'success', 'message' => 'Update extracted successfully.']);
            } else {
                throw new Exception("Failed to open the zip file. Error code: " . $res);
            }
        } catch (Exception $e) {
            echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
        exit;
    }

    // Helper to strip 'v' and any extra dots for standard version_compare
    private function normalizeVersion($version) {
        $clean = ltrim(strtolower($version), 'v');
        return $clean;
    }
}
