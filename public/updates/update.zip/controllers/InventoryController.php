<?php
// controllers/InventoryController.php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/Product.php';

class InventoryController extends BaseController {
    public function index() {
        requireLogin();

        $productModel = new Product($this->pdo);
        $flash = consumeFlash();
        $currentUser = $_SESSION['user']['username'] ?? '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
            $action = $_POST['action'];

            if ($action === 'clear_inventory') {
                if (!isAdmin()) {
                    flash('You do not have permission to clear inventory.', 'danger');
                    $this->redirect('index.php?page=inventory');
                }
                $productModel->clearAll();
                flash('Inventory cleared successfully.', 'success');
                $this->redirect('index.php?page=inventory');
            }

            if ($action === 'check_inventory') {
                $productId = intval($_POST['product_id'] ?? 0);
                $actualQty = intval($_POST['actual_qty'] ?? -1);
                $notes = trim($_POST['check_notes'] ?? '');

                if ($productId > 0 && $actualQty >= 0) {
                    $product = $productModel->getById($productId);

                    if ($product) {
                        $expectedQty = intval($product['stock_qty']);
                        $missingQty = $expectedQty - $actualQty;

                        // Log the inventory check
                        $productModel->logInventoryCheck($productId, $expectedQty, $actualQty, $missingQty, $currentUser, $notes);

                        // Update stock to actual quantity if different
                        if ($actualQty !== $expectedQty) {
                            $productModel->updateStock($productId, $actualQty);
                            if ($missingQty > 0) {
                                flash("Inventory checked. {$missingQty} missing item(s) logged and stock updated.", 'warning');
                            } else {
                                flash('Inventory checked. Stock updated to match actual quantity.', 'success');
                            }
                        } else {
                            flash('Inventory checked. No discrepancies found.', 'success');
                        }
                    } else {
                        flash('Product not found.', 'danger');
                    }
                } else {
                    flash('Invalid inventory check data.', 'danger');
                }
                $this->redirect('index.php?page=inventory');
            }
        }

        $products = $productModel->getAll();
        // Sort products by stock quantity descending (more stock first)
        usort($products, function($a, $b) {
            return $b['stock_qty'] <=> $a['stock_qty'];
        });

        $inventoryStats = $productModel->getInventoryStats();
        $lowStockCount = $this->pdo->prepare('SELECT COUNT(*) FROM products WHERE stock_qty <= 5');
        $lowStockCount->execute();
        $lowStockCount = intval($lowStockCount->fetchColumn());

        // Get last check info for each product
        $lastChecks = [];
        foreach ($products as $product) {
            $lastCheck = $productModel->getLastInventoryCheck($product['id']);
            if ($lastCheck) {
                $lastChecks[$product['id']] = $lastCheck;
            }
        }

        // Get all inventory checks for history modal (admin only)
        $allInventoryChecks = isAdmin() ? $productModel->getInventoryChecks() : [];

        $today = getSystemTime('Y-m-d');

        $this->render('pages/inventory', [
            'products' => $products,
            'inventoryStats' => $inventoryStats,
            'lowStockCount' => $lowStockCount,
            'flash' => $flash,
            'lastChecks' => $lastChecks,
            'allInventoryChecks' => $allInventoryChecks,
            'today' => $today
        ], 'Inventory');
    }
}
