<?php
// controllers/UserController.php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/User.php';

class UserController extends BaseController {
    public function manage() {
        requireAdmin();

        $userModel = new User($this->pdo);
        $flash = consumeFlash();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->handlePost();
        }

        $editUser = null;
        if (isset($_GET['edit'])) {
            $stmt = $this->pdo->prepare('SELECT id, username, role FROM users WHERE id = :id LIMIT 1');
            $stmt->execute(['id' => intval($_GET['edit'])]);
            $editUser = $stmt->fetch();
        }

        $users = $userModel->getAll();

        // Get online users (active within last 5 minutes)
        $onlineUsers = $userModel->getOnlineUsers();

        $this->render('pages/manage_users', [
            'flash' => $flash,
            'editUser' => $editUser,
            'users' => $users,
            'onlineUsers' => $onlineUsers,
        ], 'Manage Users');
    }



    private function handlePost() {
        $action = $_POST['action'] ?? '';
        $userId = intval($_POST['user_id'] ?? 0);
        $username = trim($_POST['username'] ?? '');
        $role = $_POST['role'] ?? 'staff';
        $password = $_POST['password'] ?? '';

        if ($action === 'create') {
            if ($username === '' || ($password === '') || !in_array($role, ['admin', 'staff'], true)) {
                flash('Please provide valid user credentials.', 'danger');
            } else {
                $userModel = new User($this->pdo);
                $userModel->create($username, $password, $role);
                flash('User created successfully.', 'success');
            }
        } elseif ($action === 'update' && $userId > 0) {
            if ($username === '' || !in_array($role, ['admin', 'staff'], true)) {
                flash('Please provide valid username and role.', 'danger');
            } else {
                $userModel = new User($this->pdo);
                $userModel->update($userId, $username, $password, $role);
                flash('User updated successfully.', 'success');
            }
        } elseif ($action === 'delete' && $userId > 0) {
            if ($userId === currentUser()['id']) {
                flash('You cannot delete your own account.', 'danger');
            } else {
                $userModel = new User($this->pdo);
                $userModel->delete($userId);
                flash('User deleted successfully.', 'success');
            }
        }

        $this->redirect('index.php?page=manage_users');
    }
}
