<?php
// controllers/OfflineDashboardController.php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/Product.php';

class OfflineDashboardController extends BaseController {
    public function index() {
        requireLogin();
        
        require_once __DIR__ . '/LicenseController.php';
        $license = LicenseController::getCurrentLicense($this->pdo);

        if (empty($license['offline_dashboard']) || !empty($license['is_expired'])) {
            flash('Offline Mode requires an active Pro License.', 'warning');
            header('Location: index.php?page=dashboard');
            exit;
        }
        $productModel = new Product($this->pdo);
        $products = $productModel->getAll();
        
        // Sort products by stock quantity descending
        usort($products, function($a, $b) {
            return $b['stock_qty'] <=> $a['stock_qty'];
        });

        $categories = $productModel->getAllCategories();

        $this->render('pages/offline_dashboard', [
            'products' => $products,
            'categories' => $categories
        ], 'Offline Mode');
    }

    public function apiProducts() {
        requireLogin();
        header('Content-Type: application/json');
        
        $productModel = new Product($this->pdo);
        $products = $productModel->getAll();
        
        usort($products, function($a, $b) {
            return $b['stock_qty'] <=> $a['stock_qty'];
        });

        echo json_encode($products);
        exit;
    }

    public function apiStats() {
        requireLogin();
        header('Content-Type: application/json');
        
        require_once __DIR__ . '/../models/Sale.php';
        require_once __DIR__ . '/../models/Utang.php';
        
        $saleModel = new Sale($this->pdo);
        $utangModel = new Utang($this->pdo);
        
        $today = getSystemTime('Y-m-d');
        $statsData = $saleModel->getStatsForRange($today, $today);
        $utangData = $utangModel->getTodayCount($today);
        
        echo json_encode([
            'sales' => intval($statsData['total_items'] ?? 0),
            'income' => floatval($statsData['total_income'] ?? 0),
            'utang' => intval($utangData)
        ]);
        exit;
    }
}
