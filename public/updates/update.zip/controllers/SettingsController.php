<?php
// controllers/SettingsController.php
require_once __DIR__ . '/BaseController.php';

class SettingsController extends BaseController {
    
    private $availableThemes = [
        'default' => [
            'name' => 'Classic Minimal',
            'description' => 'Clean black & white design',
            'premium' => false
        ],
        'pink' => [
            'name' => 'Premium Pink',
            'description' => 'Elegant rose & blush tones for boutiques',
            'premium' => true
        ],
        'ocean' => [
            'name' => 'Ocean Blue',
            'description' => 'Calming navy & aqua for modern stores',
            'premium' => true
        ],
        'forest' => [
            'name' => 'Forest Green',
            'description' => 'Natural emerald & sage for organic shops',
            'premium' => true
        ],
        'sunset' => [
            'name' => 'Sunset Orange',
            'description' => 'Warm coral & peach for vibrant stores',
            'premium' => true
        ],
        'royal' => [
            'name' => 'Royal Purple',
            'description' => 'Luxurious violet & lavender for premium shops',
            'premium' => true
        ],
        'dark' => [
            'name' => 'Midnight Dark',
            'description' => 'Sleek dark mode for low-light environments',
            'premium' => true
        ],
        'coffee' => [
            'name' => 'Coffee Brown',
            'description' => 'Warm mocha & cream for cozy cafes',
            'premium' => true
        ],
        'berry' => [
            'name' => 'Berry Red',
            'description' => 'Rich crimson & cherry for bold brands',
            'premium' => true
        ],
        'mint' => [
            'name' => 'Fresh Mint',
            'description' => 'Cool mint & teal for fresh concepts',
            'premium' => true
        ]
    ];

    public function index() {
        requireLogin();
        
        $flash = consumeFlash();
        $currentUser = $_SESSION['user']['username'] ?? '';
        $isAdmin = isAdmin();
        
        require_once __DIR__ . '/LicenseController.php';
        $license = LicenseController::getCurrentLicense($this->pdo);
        $hasPremiumThemes = !empty($license['premium_themes']) && empty($license['is_expired']);
        
        // Handle theme change
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
            $action = $_POST['action'];

            if ($action === 'change_theme') {
                $theme = $_POST['theme'] ?? 'default';

                if (array_key_exists($theme, $this->availableThemes)) {
                    if ($this->availableThemes[$theme]['premium'] && !$hasPremiumThemes) {
                        flash('This theme requires a license with Premium Themes enabled.', 'danger');
                    } else {
                        $_SESSION['theme'] = $theme;
                        $_SESSION['theme_version'] = time(); // Force instant refresh
                        flash('Theme updated successfully!', 'success');
                    }
                } else {
                    flash('Invalid theme selected.', 'danger');
                }
                // Redirect with cache-busting timestamp
                $this->redirect('index.php?page=settings&v=' . time());
            }

            if ($action === 'save_time_offset') {
                $offset = intval($_POST['offset'] ?? 0);
                $_SESSION['manual_time_offset'] = $offset;
                header('Content-Type: application/json');
                echo json_encode(['success' => true, 'offset' => $offset]);
                exit;
            }
        }
        
        $currentTheme = $_SESSION['theme'] ?? 'default';
        if ($currentTheme !== 'default' && $this->availableThemes[$currentTheme]['premium'] && !$hasPremiumThemes) {
            $currentTheme = 'default';
            $_SESSION['theme'] = 'default';
        }
        
        $this->render('pages/settings', [
            'flash' => $flash,
            'availableThemes' => $this->availableThemes,
            'currentTheme' => $currentTheme,
            'isAdmin' => $isAdmin,
            'currentUser' => $currentUser,
            'hasPremiumThemes' => $hasPremiumThemes
        ], 'Settings');
    }
}
