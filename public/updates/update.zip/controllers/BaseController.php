<?php
// controllers/BaseController.php
class BaseController {
    protected $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    protected function render($view, $data = [], $title = 'StoreTap') {
        $data['title'] = $title;
        extract($data);
        require_once __DIR__ . '/../views/layouts/main.php';
    }

    protected function redirect($url) {
        // Append a cache-busting timestamp to bypass aggressive host caching (e.g. InfinityFree)
        $separator = (parse_url($url, PHP_URL_QUERY) == NULL) ? '?' : '&';
        $url .= $separator . 'cb=' . time();
        header('Location: ' . $url);
        exit;
    }
}
