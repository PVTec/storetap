<?php
// controllers/ReportController.php
require_once __DIR__ . '/BaseController.php';
require_once __DIR__ . '/../models/Sale.php';
require_once __DIR__ . '/../models/Utang.php';

class ReportController extends BaseController {
    public function sales() {
        requireLogin();

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'clear_sales') {
            if (!isAdmin()) {
                flash('You do not have permission to clear sales.', 'danger');
                $this->redirect('index.php?page=sales_report');
            }

            $saleModel = new Sale($this->pdo);
            $utangModel = new Utang($this->pdo);
            $saleModel->clearAll();
            $utangModel->clearAll();
            flash('Sales and utang data cleared successfully.', 'success');
            $this->redirect('index.php?page=sales_report');
        }

        $period = $_GET['period'] ?? 'today';
        $startDate = $_GET['start_date'] ?? '';
        $endDate = $_GET['end_date'] ?? '';

        list($rangeStart, $rangeEnd, $periodLabel) = $this->getDateRange($period, $startDate, $endDate);

        $saleModel = new Sale($this->pdo);
        $utangModel = new Utang($this->pdo);

        $salesSummary = $saleModel->getStatsForRange($rangeStart, $rangeEnd);
        $periodSales = $saleModel->getSalesForRange($rangeStart, $rangeEnd);
        $periodUtang = $utangModel->getUtangForRange($rangeStart, $rangeEnd);

        // Get inventory checks for the period
        require_once __DIR__ . '/../models/Product.php';
        $productModel = new Product($this->pdo);
        $inventoryChecks = $productModel->getInventoryChecksForRange($rangeStart, $rangeEnd);

        // Use system time for today's fallback in view
        $today = getSystemTime('Y-m-d');

        $this->render('pages/sales_report', [
            'salesSummary' => $salesSummary,
            'periodSales' => $periodSales,
            'periodUtang' => $periodUtang,
            'inventoryChecks' => $inventoryChecks,
            'period' => $period,
            'periodLabel' => $periodLabel,
            'startDate' => $startDate,
            'endDate' => $endDate,
            'today' => $today,
        ], 'Sales Report');
    }

    private function getDateRange($period, $startDate, $endDate) {
        $today = getSystemTime('Y-m-d');
        $rangeStart = $today;
        $rangeEnd = $today;
        $label = 'Today';
        $todayTs = getSystemTimestamp();

        switch ($period) {
            case 'yesterday':
                $rangeStart = date('Y-m-d', strtotime('-1 day', $todayTs));
                $rangeEnd = $rangeStart;
                $label = 'Yesterday';
                break;
            case 'last_7_days':
                $rangeStart = date('Y-m-d', strtotime('-6 days', $todayTs));
                $rangeEnd = $today;
                $label = 'Last 7 Days';
                break;
            case 'this_month':
                $rangeStart = date('Y-m-01', $todayTs);
                $rangeEnd = $today;
                $label = 'This Month';
                break;
            case 'custom':
                if ($startDate && $endDate && $startDate <= $endDate) {
                    $rangeStart = $startDate;
                    $rangeEnd = $endDate;
                    $label = 'Custom Range';
                } else {
                    $rangeStart = $today;
                    $rangeEnd = $today;
                    $label = 'Today';
                    $period = 'today';
                }
                break;
            default:
                $rangeStart = $today;
                $rangeEnd = $today;
                $label = 'Today';
                $period = 'today';
                break;
        }

        return [$rangeStart, $rangeEnd, $label];
    }
}
