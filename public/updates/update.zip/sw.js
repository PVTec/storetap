/**
 * StoreTap Service Worker
 * Provides offline caching and background sync capabilities
 */

const CACHE_NAME = 'storetap-v2.1.1';
const STATIC_ASSETS = [
  '/',
  '/index.php',
  '/index.php?page=dashboard',
  '/index.php?page=offline_dashboard',
  '/index.php?page=sales',
  '/index.php?page=inventory',
  '/index.php?page=sales_report',
  '/index.php?page=utang_records',
  '/views/layouts/main.php',
  '/views/pages/dashboard.php',
  '/views/pages/offline_dashboard.php',
  '/views/pages/sales.php',
  '/views/pages/inventory.php',
  '/views/pages/sales_report.php',
  '/views/pages/utang_records.php'
];

// Install - cache static assets
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        return cache.addAll(STATIC_ASSETS);
      })
      .catch((err) => {
        console.log('[SW] Cache install failed:', err);
      })
  );
  self.skipWaiting();
});

// Activate - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch - serve from cache or network
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests and external URLs
  if (request.method !== 'GET' || !url.pathname.startsWith('/')) {
    return;
  }

  // API/POST requests - network only with background sync
  if (request.method === 'POST' || url.pathname.includes('/api/')) {
    event.respondWith(
      fetch(request)
        .catch(() => {
          // Queue for background sync if offline
          if ('sync' in self.registration) {
            self.registration.sync.register('sync-transactions');
          }
          return new Response(JSON.stringify({ 
            error: 'Offline - will sync when online',
            offline: true 
          }), {
            status: 503,
            headers: { 'Content-Type': 'application/json' }
          });
        })
    );
    return;
  }

  // Handle cache-busting parameters
  let cacheRequest = request;
  if (url.searchParams.has('v')) {
    const newUrl = new URL(request.url);
    newUrl.searchParams.delete('v');
    cacheRequest = new Request(newUrl.href);
  }

  const isStatic = url.pathname.match(/\.(css|js|png|jpg|jpeg|gif|svg|ico|json)$/i) || url.pathname.includes('/assets/');

  if (isStatic) {
    // Static assets - Cache first, then background update (Stale-While-Revalidate)
    event.respondWith(
      caches.match(cacheRequest).then((cached) => {
        if (cached) {
          // Fetch in background using ORIGINAL request (with v= parameter) to bust server cache
          fetch(request).then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              const responseClone = networkResponse.clone();
              caches.open(CACHE_NAME).then((cache) => {
                // Store using the stripped URL so it matches next time
                cache.put(cacheRequest, responseClone);
              });
            }
          }).catch(() => {
            // Ignore network errors on background update
          });
          return cached;
        }

        // If not in cache, fetch from network using original request
        return fetch(request).then((networkResponse) => {
          if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
            return networkResponse;
          }
          const responseClone = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(cacheRequest, responseClone);
          });
          return networkResponse;
        });
      })
    );
  } else {
    // Dynamic pages (HTML/PHP) - Network first, fallback to cache
    event.respondWith(
      fetch(request)
        .then((response) => {
          if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
          }
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(cacheRequest, responseClone);
          });
          return response;
        })
        .catch(() => {
          return caches.match(cacheRequest).then((cached) => {
            if (cached) {
              return cached;
            }
            // Return offline fallback if available
            if (request.mode === 'navigate') {
              return caches.match('/index.php?page=offline_dashboard');
            }
          });
        })
    );
  }
});

// Background sync for offline transactions
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-transactions') {
    event.waitUntil(syncOfflineTransactions());
  }
});

// Sync offline transactions when back online
async function syncOfflineTransactions() {
  // This will be called when the device comes back online
  // The app should have stored pending transactions in IndexedDB
  // and this function would sync them to the server
  const clients = await self.clients.matchAll();
  clients.forEach((client) => {
    client.postMessage({
      type: 'SYNC_COMPLETE',
      message: 'Connection restored - ready to sync'
    });
  });
}

// Handle push notifications (future feature)
self.addEventListener('push', (event) => {
  if (event.data) {
    const data = event.data.json();
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: '/assets/icon-192x192.png',
      badge: '/assets/icon-72x72.png'
    });
  }
});
