<?php
// Migration script to add missing columns and tables
require_once __DIR__ . '/init.php';

try {
    // Check if columns exist
    $productColumns = $pdo->query("SHOW COLUMNS FROM products")->fetchAll(PDO::FETCH_COLUMN);
    $salesColumns = $pdo->query("SHOW COLUMNS FROM sales")->fetchAll(PDO::FETCH_COLUMN);
    $utangColumns = $pdo->query("SHOW COLUMNS FROM utang")->fetchAll(PDO::FETCH_COLUMN);
    $userColumns = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    
    if (!in_array('initial_stock', $productColumns)) {
        $pdo->exec("ALTER TABLE products ADD COLUMN initial_stock INT UNSIGNED NOT NULL DEFAULT 0");
        echo "Added 'initial_stock' column\n";
    }
    
    if (!in_array('total_units_added', $productColumns)) {
        $pdo->exec("ALTER TABLE products ADD COLUMN total_units_added INT UNSIGNED NOT NULL DEFAULT 0");
        echo "Added 'total_units_added' column\n";
    }

    if (!in_array('created_by', $salesColumns)) {
        $pdo->exec("ALTER TABLE sales ADD COLUMN created_by VARCHAR(100) DEFAULT NULL");
        echo "Added 'created_by' to sales\n";
    }

    if (!in_array('created_by', $utangColumns)) {
        $pdo->exec("ALTER TABLE utang ADD COLUMN created_by VARCHAR(100) DEFAULT NULL");
        echo "Added 'created_by' to utang\n";
    }

    if (!in_array('last_active', $userColumns)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN last_active DATETIME DEFAULT NULL");
        echo "Added 'last_active' to users\n";
    }

    if (!in_array('current_session_id', $userColumns)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN current_session_id VARCHAR(128) DEFAULT NULL");
        echo "Added 'current_session_id' to users\n";
    }

    if (!in_array('login_attempt_flag', $userColumns)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN login_attempt_flag TINYINT(1) NOT NULL DEFAULT 0");
        echo "Added 'login_attempt_flag' to users\n";
    }

    // New migrations for v2
    if (!in_array('notes', $salesColumns)) {
        $pdo->exec("ALTER TABLE sales ADD COLUMN notes TEXT");
        echo "Added 'notes' to sales\n";
    }

    if (!in_array('original_qty', $salesColumns)) {
        $pdo->exec("ALTER TABLE sales ADD COLUMN original_qty INT UNSIGNED NOT NULL DEFAULT 0");
        echo "Added 'original_qty' to sales\n";
    }

    if (!in_array('date_updated', $salesColumns)) {
        $pdo->exec("ALTER TABLE sales ADD COLUMN date_updated DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP");
        echo "Added 'date_updated' to sales\n";
    }

    if (!in_array('remaining_balance', $utangColumns)) {
        $pdo->exec("ALTER TABLE utang ADD COLUMN remaining_balance DECIMAL(10,2) NOT NULL DEFAULT 0");
        echo "Added 'remaining_balance' to utang\n";
        // Initialize remaining_balance from total for existing records
        $pdo->exec("UPDATE utang SET remaining_balance = total WHERE remaining_balance = 0");
        echo "Initialized remaining_balance values\n";
    }

    // Create utang_payments table if not exists
    if (!in_array('utang_payments', $tables)) {
        $pdo->exec("CREATE TABLE utang_payments (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            utang_id INT UNSIGNED NOT NULL,
            amount_paid DECIMAL(10,2) NOT NULL,
            remaining_balance DECIMAL(10,2) NOT NULL,
            paid_by VARCHAR(100) DEFAULT NULL,
            date_created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (utang_id) REFERENCES utang(id) ON DELETE CASCADE,
            INDEX idx_payment_utang (utang_id),
            INDEX idx_payment_date (date_created)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "Created 'utang_payments' table\n";
    }

    // Create inventory_checks table if not exists
    if (!in_array('inventory_checks', $tables)) {
        $pdo->exec("CREATE TABLE inventory_checks (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            product_id INT UNSIGNED NOT NULL,
            expected_qty INT UNSIGNED NOT NULL,
            actual_qty INT UNSIGNED NOT NULL,
            missing_qty INT NOT NULL,
            checked_by VARCHAR(100) NOT NULL,
            notes TEXT,
            date_created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
            INDEX idx_check_product (product_id),
            INDEX idx_check_date (date_created)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        echo "Created 'inventory_checks' table\n";
    }
    
    // Initialize values from existing stock
    $pdo->exec("UPDATE products SET initial_stock = stock_qty, total_units_added = stock_qty WHERE initial_stock = 0");
    echo "Initialized stock tracking values\n";
    
    echo "Migration completed successfully!";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
