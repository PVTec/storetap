<?php
require_once __DIR__ . '/layout.php';
requireLogin();
requireAdmin();

$action = $_POST['action'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = intval($_POST['user_id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $role = $_POST['role'] ?? 'staff';
    $password = $_POST['password'] ?? '';

    if ($action === 'create') {
        if ($username === '' || ($password === '') || !in_array($role, ['admin', 'staff'], true)) {
            flash('Please provide valid user credentials.', 'danger');
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare('INSERT INTO users (username, password, role) VALUES (:username, :password, :role)');
            $stmt->execute(['username' => $username, 'password' => $hash, 'role' => $role]);
            flash('User created successfully.', 'success');
        }
    }

    if ($action === 'update' && $userId > 0) {
        if ($username === '' || !in_array($role, ['admin', 'staff'], true)) {
            flash('Please provide valid username and role.', 'danger');
        } else {
            if ($password !== '') {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare('UPDATE users SET username = :username, password = :password, role = :role WHERE id = :id');
                $stmt->execute(['username' => $username, 'password' => $hash, 'role' => $role, 'id' => $userId]);
            } else {
                $stmt = $pdo->prepare('UPDATE users SET username = :username, role = :role WHERE id = :id');
                $stmt->execute(['username' => $username, 'role' => $role, 'id' => $userId]);
            }
            flash('User updated successfully.', 'success');
        }
    }

    if ($action === 'delete' && $userId > 0) {
        if ($userId === currentUser()['id']) {
            flash('You cannot delete your own account.', 'danger');
        } else {
            $stmt = $pdo->prepare('DELETE FROM users WHERE id = :id');
            $stmt->execute(['id' => $userId]);
            flash('User deleted successfully.', 'success');
        }
    }

    header('Location: manage_users.php');
    exit;
}

$editUser = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT id, username, role FROM users WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => intval($_GET['edit'])]);
    $editUser = $stmt->fetch();
}

$users = $pdo->query('SELECT id, username, role FROM users ORDER BY username ASC')->fetchAll();
$flash = consumeFlash();
page_header('Manage Users', 'users');
?>
<div class="page-header">
    <h2>Manage Users</h2>
    <p>Create and manage staff and admin access.</p>
</div>
<?php if ($flash): ?>
    <div class="alert alert-<?= sanitize($flash['type']) ?> mb-3" role="alert">
        <?= sanitize($flash['message']) ?>
    </div>
<?php endif; ?>
<div class="row g-3">
    <div class="col-lg-5">
        <div class="card p-4">
            <h4 class="mb-3"><?= $editUser ? 'Edit User' : 'Create User' ?></h4>
            <form method="post">
                <input type="hidden" name="user_id" value="<?= intval($editUser['id'] ?? 0) ?>">
                <input type="hidden" name="action" value="<?= $editUser ? 'update' : 'create' ?>">
                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" value="<?= sanitize($editUser['username'] ?? '') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password <?= $editUser ? '(leave blank to keep current)' : '' ?></label>
                    <input type="password" name="password" class="form-control" <?= $editUser ? '' : 'required' ?> autocomplete="new-password">
                </div>
                <div class="mb-3">
                    <label class="form-label">Role</label>
                    <select name="role" class="form-select" required>
                        <option value="staff" <?= ($editUser['role'] ?? '') === 'staff' ? 'selected' : '' ?>>Staff</option>
                        <option value="admin" <?= ($editUser['role'] ?? '') === 'admin' ? 'selected' : '' ?>>Admin</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary"><?= $editUser ? 'Update User' : 'Create User' ?></button>
                <?php if ($editUser): ?>
                    <a href="manage_users.php" class="btn btn-outline-secondary ms-2">Cancel</a>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="card p-3">
            <h5 class="mb-3 fw-bold">User Accounts</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Role</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= sanitize($user['username']) ?></td>
                                <td><?= ucfirst(sanitize($user['role'])) ?></td>
                                <td class="text-end">
                                    <a href="manage_users.php?edit=<?= intval($user['id']) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                    <?php if ($user['id'] !== currentUser()['id']): ?>
                                        <form method="post" class="d-inline-block" onsubmit="return confirm('Delete this user?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="user_id" value="<?= intval($user['id']) ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php page_footer();
