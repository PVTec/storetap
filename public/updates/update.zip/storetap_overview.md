# StoreTap v2.1.0 - The Ultimate POS & Inventory System
*Empower your small business with our fast, reliable, and beautifully designed management system.*

StoreTap v2.1.0 brings a complete suite of professional tools to help you manage your store effortlessly. Whether you're tracking daily cash sales, managing stock, or recording customer credits ("Utang"), StoreTap handles it all with a smooth, mobile-optimized experience that even works offline.

---

## ✨ Key Features & Modules

### 💰 Advanced Sales Module
Sell faster and smarter with a completely redesigned checkout experience:
- **Fast Sale Cart:** Queue multiple items for rapid processing.
- **Custom Pricing & Notes:** Adjust prices on the fly for special sales and add custom transaction notes.
- **Role-Based Visibility:** Ensure your staff only sees what they need to see, while admins get full control.
- **Mobile-Friendly Layout:** Checkout customers seamlessly from any device with an improved, touch-friendly card layout.

### ↩️ Dashboard & Undo Sales
Mistakes happen, but they shouldn't mess up your inventory:
- **Instant Undo:** Easily undo the last sale—stock is restored automatically!
- **Quick Action Cards:** Instantly perform Cash or Utang sales right from your dashboard.
- **Transaction-Safe:** Keeps your records completely accurate at all times.

### 📓 Complete 'Utang' (Credit) Management
Never lose track of what customers owe you:
- **Comprehensive Listing:** View all your utang records at a glance.
- **Flexible Payments:** Accept partial payments, track payment history, and automatically calculate remaining balances.
- **Mark as Paid:** Easily close out fully paid debts.

### 🏪 Smart Inventory System
Stay on top of your stock levels without the headache:
- **Check & Adjust:** Quickly update stock quantities and record the reason for any adjustments.
- **Original Stock Tracking:** Keep a permanent history of your inventory changes.
- **Low Stock Warnings:** Get alerted before you run out of your best sellers.

### 📊 Reports & Analytics
Understand your business performance instantly:
- **Period Filtering:** View sales and utang collections by specific date ranges.
- **Export-Ready Tables:** Easily export your data for external accounting.
- **Inventory Checks:** Specialized auditing tools available strictly for admins.

### 👥 User & Session Management
Keep your business secure with role-based access:
- **Real-Time Monitoring:** See exactly who is online and monitor active user sessions (Admin only).
- **Role Assignment:** Easily create, edit, or delete user accounts and assign Staff or Admin roles.
- **Permission-Based Features:** Restrict sensitive actions, ensuring staff can only process sales.

### 🎨 Premium Theme System (BETA)
Make StoreTap your own:
- **10 Premium Themes:** Choose from professionally designed color schemes (like Midnight Dark, Premium Pink, Ocean Blue, and more) at no extra cost.
- **Personalized:** Each user can set their own theme preference.
- **Midnight Mode:** A specialized sleek dark mode perfect for low-light environments.

---

## 🚀 Why Choose StoreTap v2.1.0?
The latest update introduces **Offline-First PWA capabilities**. If your internet connection drops, your store keeps running! Cache sales and utang transactions locally, and the system will silently sync in the background once you're back online. 

**Upgrade to StoreTap v2.1.0 today and take complete control of your store!**
