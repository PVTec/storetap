<?php
require_once __DIR__ . '/layout.php';
requireLogin();
requireAdmin();

$action = $_POST['action'] ?? '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['product_name'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $stock = intval($_POST['stock_qty'] ?? 0);
    $productId = intval($_POST['product_id'] ?? 0);

    if ($action === 'create') {
        if ($name === '' || $price < 0 || $stock < 0) {
            flash('Please provide valid product details.', 'danger');
        } else {
            $stmt = $pdo->prepare('INSERT INTO products (product_name, price, stock_qty) VALUES (:name, :price, :stock)');
            $stmt->execute(['name' => $name, 'price' => $price, 'stock' => $stock]);
            flash('Product added successfully.', 'success');
        }
    }

    if ($action === 'update' && $productId > 0) {
        if ($name === '' || $price < 0 || $stock < 0) {
            flash('Please provide valid product details.', 'danger');
        } else {
            $stmt = $pdo->prepare('UPDATE products SET product_name = :name, price = :price, stock_qty = :stock WHERE id = :id');
            $stmt->execute(['name' => $name, 'price' => $price, 'stock' => $stock, 'id' => $productId]);
            flash('Product updated successfully.', 'success');
        }
    }

    if ($action === 'delete' && $productId > 0) {
        $stmt = $pdo->prepare('DELETE FROM products WHERE id = :id');
        $stmt->execute(['id' => $productId]);
        flash('Product deleted.', 'success');
    }

    header('Location: product_manage.php');
    exit;
}

$editProduct = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = :id LIMIT 1');
    $stmt->execute(['id' => intval($_GET['edit'])]);
    $editProduct = $stmt->fetch();
}

$products = $pdo->query('SELECT * FROM products ORDER BY product_name ASC')->fetchAll();
$flash = consumeFlash();
page_header('Manage Products', 'products');
?>
<div class="page-header">
    <h2>Manage Products</h2>
    <p>Add, edit, or remove store products.</p>
</div>
<?php if ($flash): ?>
    <div class="alert alert-<?= sanitize($flash['type']) ?> mb-3" role="alert">
        <?= sanitize($flash['message']) ?>
    </div>
<?php endif; ?>
<div class="row g-3">
    <div class="col-lg-5">
        <div class="card p-4">
            <h5 class="mb-3 fw-bold"><?= $editProduct ? 'Edit Product' : 'Add Product' ?></h5>
            <form method="post">
                <input type="hidden" name="product_id" value="<?= intval($editProduct['id'] ?? 0) ?>">
                <input type="hidden" name="action" value="<?= $editProduct ? 'update' : 'create' ?>">
                <div class="mb-3">
                    <label class="form-label">Product Name</label>
                    <input type="text" name="product_name" class="form-control" value="<?= sanitize($editProduct['product_name'] ?? '') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Price</label>
                    <input type="number" name="price" step="0.01" min="0" class="form-control" value="<?= sanitize($editProduct['price'] ?? '0.00') ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Stock Quantity</label>
                    <input type="number" name="stock_qty" min="0" class="form-control" value="<?= sanitize($editProduct['stock_qty'] ?? '0') ?>" required>
                </div>
                <button type="submit" class="btn btn-primary"><?= $editProduct ? 'Update Product' : 'Add Product' ?></button>
                <?php if ($editProduct): ?>
                    <a href="product_manage.php" class="btn btn-outline-secondary ms-2">Cancel</a>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="card p-3">
            <h5 class="mb-3 fw-bold">Product List</h5>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th class="text-end">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><?= sanitize($product['product_name']) ?></td>
                                <td>₱ <?= number_format($product['price'], 2) ?></td>
                                <td><?= intval($product['stock_qty']) ?></td>
                                <td class="text-end">
                                    <a href="product_manage.php?edit=<?= intval($product['id']) ?>" class="btn btn-sm btn-outline-primary">Edit</a>
                                    <form method="post" class="d-inline-block" onsubmit="return confirm('Delete this product?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="product_id" value="<?= intval($product['id']) ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php page_footer();
