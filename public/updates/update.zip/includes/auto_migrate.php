<?php
// auto_migrate.php
// Automatically runs database migrations silently without breaking page layouts.

if (!isset($_SESSION['auto_migrated_v2'])) {
    try {
        // --- 1. Products Table ---
        $productColumns = $pdo->query("SHOW COLUMNS FROM products")->fetchAll(PDO::FETCH_COLUMN);
        
        if (!in_array('category', $productColumns)) {
            $pdo->exec("ALTER TABLE products ADD COLUMN category VARCHAR(100) DEFAULT 'Uncategorized' AFTER product_name");
            $pdo->exec("UPDATE products SET category = 'Beverages' WHERE product_name LIKE '%Water%' OR product_name LIKE '%Softdrink%'");
            $pdo->exec("UPDATE products SET category = 'Noodles / Hot Food' WHERE product_name LIKE '%Noodles%'");
            $pdo->exec("UPDATE products SET category = 'Pantry' WHERE product_name LIKE '%Rice%'");
        }

        if (!in_array('initial_stock', $productColumns)) {
            $pdo->exec("ALTER TABLE products ADD COLUMN initial_stock INT UNSIGNED NOT NULL DEFAULT 0");
        }
        
        if (!in_array('total_units_added', $productColumns)) {
            $pdo->exec("ALTER TABLE products ADD COLUMN total_units_added INT UNSIGNED NOT NULL DEFAULT 0");
            $pdo->exec("UPDATE products SET initial_stock = stock_qty, total_units_added = stock_qty WHERE initial_stock = 0");
        }

        // --- 2. Sales Table ---
        $salesColumns = $pdo->query("SHOW COLUMNS FROM sales")->fetchAll(PDO::FETCH_COLUMN);
        
        if (!in_array('created_by', $salesColumns)) {
            $pdo->exec("ALTER TABLE sales ADD COLUMN created_by VARCHAR(100) DEFAULT NULL");
        }
        if (!in_array('notes', $salesColumns)) {
            $pdo->exec("ALTER TABLE sales ADD COLUMN notes TEXT");
        }
        if (!in_array('original_qty', $salesColumns)) {
            $pdo->exec("ALTER TABLE sales ADD COLUMN original_qty INT UNSIGNED NOT NULL DEFAULT 0");
        }
        if (!in_array('date_updated', $salesColumns)) {
            $pdo->exec("ALTER TABLE sales ADD COLUMN date_updated DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP");
        }
        if (!in_array('price', $salesColumns)) {
            $pdo->exec("ALTER TABLE sales ADD COLUMN price DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER original_qty");
            $pdo->exec("UPDATE sales s JOIN products p ON s.product_id = p.id SET s.price = p.price WHERE s.price = 0");
        }

        // --- 3. Utang Table ---
        $utangColumns = $pdo->query("SHOW COLUMNS FROM utang")->fetchAll(PDO::FETCH_COLUMN);
        
        if (!in_array('created_by', $utangColumns)) {
            $pdo->exec("ALTER TABLE utang ADD COLUMN created_by VARCHAR(100) DEFAULT NULL");
        }
        if (!in_array('remaining_balance', $utangColumns)) {
            $pdo->exec("ALTER TABLE utang ADD COLUMN remaining_balance DECIMAL(10,2) NOT NULL DEFAULT 0");
            $pdo->exec("UPDATE utang SET remaining_balance = total WHERE remaining_balance = 0");
        }

        // --- 4. Users Table ---
        $userColumns = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
        
        if (!in_array('last_active', $userColumns)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN last_active DATETIME DEFAULT NULL");
        }
        if (!in_array('current_session_id', $userColumns)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN current_session_id VARCHAR(128) DEFAULT NULL");
        }
        if (!in_array('login_attempt_flag', $userColumns)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN login_attempt_flag TINYINT(1) NOT NULL DEFAULT 0");
        }

        // --- 5. New Tables ---
        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

        if (!in_array('utang_payments', $tables)) {
            $pdo->exec("CREATE TABLE utang_payments (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                utang_id INT UNSIGNED NOT NULL,
                amount_paid DECIMAL(10,2) NOT NULL,
                remaining_balance DECIMAL(10,2) NOT NULL,
                paid_by VARCHAR(100) DEFAULT NULL,
                date_created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (utang_id) REFERENCES utang(id) ON DELETE CASCADE,
                INDEX idx_payment_utang (utang_id),
                INDEX idx_payment_date (date_created)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }

        if (!in_array('inventory_checks', $tables)) {
            $pdo->exec("CREATE TABLE inventory_checks (
                id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                product_id INT UNSIGNED NOT NULL,
                expected_qty INT UNSIGNED NOT NULL,
                actual_qty INT UNSIGNED NOT NULL,
                missing_qty INT NOT NULL,
                checked_by VARCHAR(100) NOT NULL,
                notes TEXT,
                date_created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
                INDEX idx_check_product (product_id),
                INDEX idx_check_date (date_created)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }

        if (!in_array('license_config', $tables)) {
            $pdo->exec("
                CREATE TABLE license_config (
                    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    license_key VARCHAR(255) NOT NULL,
                    license_type ENUM('free', 'standard', 'pro') NOT NULL DEFAULT 'free',
                    offline_dashboard TINYINT(1) NOT NULL DEFAULT 0,
                    premium_themes TINYINT(1) NOT NULL DEFAULT 0,
                    expires_at DATETIME NOT NULL,
                    date_activated DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
            ");
            $expires = date('Y-m-d H:i:s', strtotime('+1 month'));
            $pdo->exec("INSERT INTO license_config (license_key, license_type, offline_dashboard, premium_themes, expires_at) VALUES ('FREE-TRIAL', 'free', 0, 0, '$expires')");
        }

        // Flag that migration has completed successfully for this session
        $_SESSION['auto_migrated_v2'] = true;
        
    } catch (PDOException $e) {
        // Silently log error, do not set the session flag so it will retry next page load
        error_log("StoreTap Auto-Migration Error: " . $e->getMessage());
    }
}
