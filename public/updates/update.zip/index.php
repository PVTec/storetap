<?php
require_once __DIR__ . '/init.php';

$page = $_GET['page'] ?? 'login';

if (!isLoggedIn() && $page !== 'login') {
    header('Location: index.php?page=login&cb=' . time());
    exit;
}

$routes = [
    'login' => ['controller' => 'AuthController', 'method' => 'login'],
    'logout' => ['controller' => 'AuthController', 'method' => 'logout'],
    'dashboard' => ['controller' => 'DashboardController', 'method' => 'index'],
    'product_manage' => ['controller' => 'ProductController', 'method' => 'manage'],
    'utang_records' => ['controller' => 'UtangController', 'method' => 'records'],
    'inventory' => ['controller' => 'InventoryController', 'method' => 'index'],
    'inventory_history' => ['controller' => 'InventoryHistoryController', 'method' => 'index'],
    'sales' => ['controller' => 'SalesController', 'method' => 'index'],
    'sales_report' => ['controller' => 'ReportController', 'method' => 'sales'],
    'manage_users' => ['controller' => 'UserController', 'method' => 'manage'],
    'settings' => ['controller' => 'SettingsController', 'method' => 'index'],
    'offline_dashboard' => ['controller' => 'OfflineDashboardController', 'method' => 'index'],
    'api_products' => ['controller' => 'OfflineDashboardController', 'method' => 'apiProducts'],
    'api_stats' => ['controller' => 'OfflineDashboardController', 'method' => 'apiStats'],
    'api_check_conflict' => ['controller' => 'AuthController', 'method' => 'checkConflict'],
    'license' => ['controller' => 'LicenseController', 'method' => 'index'],
    'update_check' => ['controller' => 'UpdateController', 'method' => 'check'],
    'update_download' => ['controller' => 'UpdateController', 'method' => 'download'],
    'update_extract' => ['controller' => 'UpdateController', 'method' => 'extract'],
];

if (isset($routes[$page])) {
    $controllerName = $routes[$page]['controller'];
    $method = $routes[$page]['method'];
    require_once __DIR__ . '/controllers/' . $controllerName . '.php';
    $controller = new $controllerName($pdo);
    $controller->$method();
} else {
    header('Location: index.php?page=dashboard&cb=' . time());
    exit;
}
