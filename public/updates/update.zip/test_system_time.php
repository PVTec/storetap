<?php
// Test script to verify system time is working correctly
require_once __DIR__ . '/init.php';

echo "Session ID: " . session_id() . "\n\n";

echo "Session manual_time_offset: " . ($_SESSION['manual_time_offset'] ?? 'NOT SET') . "\n";
echo "Session manual_time_offset (int): " . intval($_SESSION['manual_time_offset'] ?? 0) . " seconds\n\n";

echo "Real time (date()): " . date('Y-m-d H:i:s') . "\n";
echo "System time (getSystemTime): " . getSystemTime('Y-m-d H:i:s') . "\n\n";

echo "Real timestamp (time()): " . time() . "\n";
echo "System timestamp (getSystemTimestamp): " . getSystemTimestamp() . "\n\n";

echo "Timezone: " . date_default_timezone_get() . "\n";

// Test creating a sale record to see what time it gets
echo "\n--- Testing Sale Model ---\n";
require_once __DIR__ . '/models/Sale.php';
$sale = new Sale($pdo);
echo "Sale model loaded. The create() method uses getSystemTime('Y-m-d H:i:s') for date_created\n";
echo "Expected date_created value would be: " . getSystemTime('Y-m-d H:i:s') . "\n";
